
struct Stack;

Stack * init();
int pop(Stack *);
void push(Stack *, int);
bool isEmpty(Stack *);
void quit(Stack * &);
