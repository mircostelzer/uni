#include<iostream>
#include<fstream>
#include<cstring>
#include<cmath>
using namespace std;


// è possibile definire funzioni di supporto


int main(int argc, char * argv []) {
  
  // inserire qui il codice

  return 0;

}
