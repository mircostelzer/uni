using namespace std;
#include <iostream>

struct S {
  int value;
  S *next;
};

int main ()
{

  S x = {4 , NULL};

  return 0;
}
