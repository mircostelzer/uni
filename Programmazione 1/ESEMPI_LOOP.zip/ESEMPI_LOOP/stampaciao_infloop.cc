using namespace std;
#include <iostream>

int main ()
{
  int i=0;
  // cosa succede se metto i short?
  //short int i=0;
  while (i<10) {
    cout << "ciao" << endl;
    i--;
  }
  return 0;
}
