// FUNZIONE che converte Celsius -> Fahrenheit
float cel2fahre (float cel) 
{
  return cel*9.0/5.0 + 32.0; 
}

// FUNZIONE che converte Fahrenheit -> Celsius
float fahre2cel (float fahre) 
{
  return (fahre-32.0)*5.0/9.0; 
}
