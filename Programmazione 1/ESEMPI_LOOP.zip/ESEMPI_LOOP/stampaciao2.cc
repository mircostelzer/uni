using namespace std;
#include <iostream>

int main ()
{
  int i=10;

  while (i>0) {
    cout << "ciao" << endl;
    i--;
  }
  return 0;
}
