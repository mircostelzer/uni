//  Example 4.21, page 111
//  Schaum's Outline of Programming with C++ by John R. Hubbard
//  Copyright McGraw-Hill, 1996

using namespace std;
#include <iostream>

int maxx(int, int);

int maxx(int, int, int);

double maxx(double, double);

int main()
{
  cout << maxx(99,77) << " " << maxx(55,66,33) << " "
       << maxx(3.4,7.2) << endl;
  cout << maxx(44L,44L) << endl; // errore AMBIGUA
  // cout << maxx(3,3.1) << endl; // errore: AMBIGUA

  return 0;
}

int maxx(int x, int y)
{
  return (x > y ? x : y);
}

//  Returns the maxximum of the three given integers:
int maxx(int x, int y, int z)
{
  int m = (x > y ? x : y);
  return (z > m ? z : m);
}

//  Returns the maxximum of the two given real numbers:
double maxx(double x, double y, double z)
{
  return (x > y ? x : y);
}
