float cel2fahre (float cel);
float fahre2cel (float fahre);


