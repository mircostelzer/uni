#ifndef CALCOLATORE_RPN_H
#define CALCOLATORE_RPN_H

// #include "entry.h"
// #include "stack.h"

int calcolatore ();

#endif
