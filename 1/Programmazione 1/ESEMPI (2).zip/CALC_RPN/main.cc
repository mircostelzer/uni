// #include "entry.h"
// #include "stack.h"
#include "calcolatore_rpn.h"

int main ()
{
  calcolatore();
  return 0;
}
