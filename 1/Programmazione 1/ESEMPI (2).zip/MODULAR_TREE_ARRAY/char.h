#ifndef CHAR_H 
#define CHAR_H 


// So che suona ridicolo, ma e' per introdurre il concetto di modularita'...

typedef char chiave;

chiave chiaveDi(char v);
int confronta(chiave c,char v1) ;
void stampa(const char & v) ;

#endif
