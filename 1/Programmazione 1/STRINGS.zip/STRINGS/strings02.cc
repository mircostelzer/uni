using namespace std;
#include <iostream>

int main()
{
  char s[] = "Ciao";
  for (int i = 0; i < 5; i++)
    cout << "s[" << i << "] = '" << s[i] << "'\n";
  return 0;
}
