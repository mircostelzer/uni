
int conta['z' - 'a'] = {};
char c;
while(cin.get(c)) {
  if (c >= 'a' || c <= 'z') {
    conta[c-'a']++;
  } else if (c >= 'A' || c <= 'Z') {
    conta[c-'A']++;
  } else {
  }
}
