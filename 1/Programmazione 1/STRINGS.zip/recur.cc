

int strlen(char s[], int j = 0) {
  if (s[j] == `\0`) return 0;
  else return 1 + strlen(s, j+1);
}
