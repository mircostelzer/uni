#include <iostream>
#include <fstream>

// Inserire qui sotto la soluzione all'esercizio
