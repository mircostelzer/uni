#include <iostream>
#include <cstdlib>
#include <fstream>
using namespace std;

// MR: doveva chiamarsi Percentuale e non percentuale!
double percentuale(double N, double M)
{
    
    if(N==0)
    {
        return 0;
    }else{
        return (N/M)*100;
    }
}
int main(int argc, char* argv[])
{
    fstream input1, input2;
    input1.open(argv[1], ios::in);
    input2.open(argv[2], ios::in);
    if(input1.fail()|| input2.fail())
    {
        cout<<"errore nella lettura dei file\n";

    }else{
        double mot1,mot2;
        double mot2M=0;
        double misurazione=0;
        int perce;
        char A[10];
        char B[10];
        
        
        
            while(input1>>A && input2>>B && misurazione<10) // MR: dove specificato che ci fossero al massimo 10 misurazioni?
            {
                mot1=atoi(A); // MR: atoi definito in cstdlib, e non consentito
                mot2=atoi(B);
                if(mot2>mot1)
                {
                    mot2M++;
                }
                misurazione++;
            }
        input1.close();
        input2.close();
        input1.open(argv[1], ios::in);
        input2.open(argv[2], ios::in);
        // MR: manca controllo apertura del file!
            bool IsEmpty=(input1.get() && input1.eof()) || (input2.get() && input2.eof());
        // MR: bastava controllare se misurazione == 0!
        if(IsEmpty==true)
        {
            // MR: il messaggio di output richiesto era diverso!
            cout<<"un file e vuoto\n";
        }else{
            // MR: il messaggio di output richiesto era diverso!
                cout<<"il motore 2 ha superato il motore uno il"<< percentuale(mot2M, misurazione)<<" % di volte";

        }
    
    
    }
}
