#include <iostream>
#include <fstream>
using namespace std;


int Percentuale(int n, int totMis){
    return ((float)n / totMis) * 100;
}

int main(int argc, char * argv[]){

    if(argc != 3){
        cout << "Il numero di input e' errato..." << endl;
        exit(0);
    }

    fstream Input1, Input2;
    Input1.open(argv[1], ios::in);
    Input2.open(argv[2], ios::in);

    if(Input1.fail()){
        cout << "Errore nell'apertura del file di input n.2 ..." << endl;
        exit(0);
    }
    if(Input2.fail()){
        cout << "Errore nell'apertura del file di input n.2 ..." << endl;
        exit(0);
    }

    int timesOver = 0;
    int times = 0;
    char w1[5], w2[5];
    float temp1, temp2;

    while(Input1.getline(w1, 5)){
        Input2.getline(w2, 5); // MR: cosa succede se il file 2 ha piu' righe del file 1? Manca il controllo!
        // MR: atof non e' consensito! Si trova in cstdlib!
        temp1 = atof(w1);
        temp2 = atof(w2);

        timesOver += temp1 > temp2;
        times += 1;
    }

    if(times == 0){
        cout << "Il numero delle misurazioni e' uguale a zero, per cui non posso calcolare la percentuale" << endl;
        // MR: manca chiusura file!
        exit(0);
    }

    int perc = Percentuale(timesOver, times);

    cout << "La percentuale di misurazioni in cui la temperatura del motore1 ha superato quella del motore2 e' del " << perc <<"%." << endl;



    Input1.close();
    Input2.close();


    return 0;
}