#include <iostream>
#include <fstream>

// Inserire qui sotto la soluzione all'esercizio

using namespace std;

// MR: doveva chiamarsi Percentuale e non percentuale!
float percentuale(int times, int rows)
{

    float result = (100 / rows) * times;

    return result;
}

int main(int argc, char *argv[])
{

    if (argc != 3)
    {
        cout << "Inserire un numero valido di parametri \n";
        exit(1);
    }

    fstream motore1, motore2;

    motore1.open(argv[1], ios::in);

    if (motore1.fail())
    {
        cout << "Apertura file temp1 fallita \n";
        exit(1);
    }

    motore2.open(argv[2], ios::in);

    if (motore2.fail())
    {
        motore1.close();
        cout << "Apertura file temp2 fallita \n";
        exit(1);
    }

    int m1, m2, rows = 0, times = 0; // MR: non specificato che temperature sono interi!

    while (motore1 >> m1 && motore2 >> m2)
    {

        if (m1 != 0 && m2 != 0) // MR: non capisco la logica che mi sembra ridondante..
        {
            if (m1 > m2)
            {
                times++;
            }
        }

        if (m1 == 0 && m2 == 0 && rows == 0)
        {
            break;
        }

        rows++;
    }

    if (rows != 0)
    {
        float res = percentuale(times, rows);
        cout << "La percentuale di misurazioni in cui la temperatura del motore1 ha superato quella del motore2 e' del " << res << "% \n";
    }
    else
    {
        cout << "Il numero delle misurazioni e' uguale a zero, per cui non posso calcolare la percentuale \n";
    }

    motore1.close();
    motore2.close();
}