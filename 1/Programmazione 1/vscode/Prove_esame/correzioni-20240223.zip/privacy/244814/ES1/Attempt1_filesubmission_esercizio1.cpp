#include <iostream>
#include <fstream>
using namespace std;
// Inserire qui sotto la soluzione all'esercizio
// MR: doveva chiamarsi Percenetual non percentuale!
float percentuale(float numeroTotale,float numeroSuperamento);
int main(int argc,char*argv[]){
    if(argc!=3){
        cout<<"inserire numero corretto di argmenti"<< endl;
        exit(1);
    }
    fstream inputStream1,inputStream2;
    inputStream1.open(argv[1],ios::in);
    inputStream2.open(argv[2],ios::in);
    if (inputStream1.fail()||inputStream2.fail()) {
        cout<<"errore nell aptrire il file"<< endl;
        exit(1);
    }
    float temperatura1=-1,temperatura2=-1;
    float numeroSuperamento=0,numeroTotale=0;
    while((inputStream1>>temperatura1) && (inputStream2>>temperatura2)){
        if(temperatura2>temperatura1){
            numeroSuperamento++;
        }
        numeroTotale++;
        cout<<"1 "<<temperatura1<<" | 2 "<<temperatura2<<"|"<<numeroSuperamento<<"|"<<numeroTotale <<endl;
    }
    if(numeroTotale>0){;
        float perc =percentuale(numeroTotale,numeroSuperamento);
        cout<<"La percentuale di misurazioni in cui la temperatura del motore2"<<endl; // in quando dovrebbe uguale all esempio di dimostrazioe ma ci e stato spiegato che dovrebbe essere il contrario
        cout<<"ha superato quella del motore1 e' del "<<perc<<"%"<<endl;                //(il motore 2 invertià supera il motore 1)
    }else{
        cout<<"Il numero delle misurazioni e' uguale a zero,"<<endl;
        cout<<"per cui non posso calcolare la percentuale"<<endl;
    }
    inputStream1.close();
    inputStream2.close();

    return 0;
}

float percentuale(float numeroTotale,float numeroSuperamento){
    float percentuale=(numeroSuperamento/numeroTotale)*100;
    return percentuale;
}