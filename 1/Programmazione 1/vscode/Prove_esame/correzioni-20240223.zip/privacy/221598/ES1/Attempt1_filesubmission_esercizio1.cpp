#include<iostream>
#include<fstream>
using namespace std;

// MR: Percentuale deve ritornare un double, non un void!
void Percentuale(int volte, int misurazioni){
    // MR: in questo modo fa solo divisione tra interi e in questo caso per come scritta ritorna sempre 0.
    // MR: sarebbe stato meglio fare (volte * 100)/ misurazioni, o ancora meglio usare double!
    int percentuale_cercata = (volte/misurazioni)*100;
    // MR: la stampa doveva essere fatta esternamente
    cout << "La percentuale di misurazioni in cui la temperatura del motore1 ha superato quella del motore2 e' del " 
        << percentuale_cercata << "%" << endl;
}

int main(int argc, char * argv []) {
if (argc != 3) { // Controllo di numero dei argomenti
cerr << "Numero di argomenti passato scorretto" << endl;
exit(1);
}
fstream motore1; // Apertura di stream 1 file in modalità lettura
fstream motore2; // Apertura di stream 1 file in modalità lettura
motore1.open(argv[1], ios::in);
motore2.open(argv[2], ios::in);

// MR: qui il controllo doveva essere fatto su motore1.fail() || motore2.fail()
if (motore1.fail() && motore2.fail()) { //Controlliamo se apertura di entrambi i file è andata a buon ﬁne
cerr << "Errore di apertura!" << endl;
exit(1);
}
float temp1;
float temp2;
int volte = 0;
int misurazioni = 0;


if(!motore1.eof() && !motore2.eof()){

    motore1 >> temp1;
    motore2 >> temp2;


    while(!motore1.eof() && !motore2.eof()) {
    std::cout << "Temperatura motore 1: " << temp1 << " Temperatura motore 2: " << temp2 << std::endl;
    misurazioni += 1;
    
    if(temp1 > temp2){ // MR: questo controllo di variante 1, il check era inverso!
        volte += 1;
    }
    
    motore1 >> temp1;
    motore2 >> temp2;
    }

    
}
else{
    cout << "Il numero delle misurazioni e' uguale a zero, per cui non posso calcolare la percentuale" << endl;
}

// MR: questa funzione doveva essere chiamata solo se misurazioni != 0, altrimenti genera divisione per 0!
Percentuale(volte, misurazioni);

motore1.close();
motore2.close();
return 0;
}