#include <iostream>
#include <fstream>
using namespace std;


int main(int argc, char *argv[]) {
    if (argc != 4) // MR: gli argomenti erano 2 e non 3!
    {
        cout << "Usage: a.out <input1> <input2> <output>" << endl;
        return 1;
    }
    
    fstream input1, input2, output;
    input1.open(argv[1], ios::in);
    input2.open(argv[2], ios::in);
    // MR: la stampa era su stdout!!!
    output.open(argv[3], ios::out);

    if (input1.fail() ||input2.fail() ||  output.fail()) {
        cout << "Errore nell'apertura dei file";
        return 1;
    }

    double text1=0;
    double text2=0;
    double conta =0;
    double maggiore =0;
    
    
    while (!input1.eof() && !input2.eof())
    {
        input1>>text1;
        input2>>text2;
        if(text1>text2){
            maggiore++;
        }
        conta++;
    }
    
if (conta>0)
{
    // MR: doveva chiamare funzione Percentuale!!!!
    output<<((maggiore/conta)*100)<<endl;
}else{
    output << "Il numero delle misurazioni e' uguale a zero,  per cui non posso calcolare la percentuale"<<endl;
}


    
    input1.close();
    input2.close();
    output.close();

    return 0;
}

