#include<iostream>
#include<fstream>


using namespace std;

double Percentuale(int superamenti, int misurazioni){
    return (double)superamenti/misurazioni;
}

int main(int argv, char ** argc){
    
    //Controllo argomenti
    //-------------------------------------------------------------------------
    if(argv != 3){
        cerr << "Usage: ./a.out <misurazioniMotore1> <misurazioniMotore2>" << endl;
        exit(0);
    }
    //-------------------------------------------------------------------------

    //Apertura file
    //-------------------------------------------------------------------------
    ifstream motore1(argc[1]);
    ifstream motore2(argc[2]);
    if(motore1.fail()){
        cerr << "Errore apertura del file " << argc[1] << endl;
        exit(0);
    }
    if(motore2.fail()){
        cerr << "Errore apertura del file " << argc[2] << endl;
        exit(0);
    }
    //-------------------------------------------------------------------------
    
    //Lettura input da file
    //-------------------------------------------------------------------------
    char buffer[255];
    double misurazione1, misurazione2;
    int superamenti = 0, misurazioni = 0;
    while(motore1 >> buffer){
        misurazione1 = atoi(buffer); // MR: atoi definita in cstdlib e non consentita!
        motore2 >> buffer; // MR: cosa succede se il primo file contiene piu' elementi del secondo?? Manca controllo!
        misurazione2 = atoi(buffer);
        misurazioni++;
        if(misurazione2 > misurazione1)
            superamenti++;
    }
    if(misurazioni == 0)
        cout << "Il numero delle misurazioni e' uguale a zero, per cui non posso calcolare la percentuale" << endl;
    else
        cout << "La percentuale di misurazioni in cui la temperatura del motore2 ha superato quella del motore1 e' del "<< Percentuale(superamenti, misurazioni)*100 <<"%." << endl;
    //Chiusura file, eliminazione memoria allocata dinamicamente
    //-------------------------------------------------------------------------
    motore1.close();
    motore2.close();
    return 0;
    //-------------------------------------------------------------------------
}