#include <iostream>
#include <fstream>

using namespace std;
// Inserire qui sotto la soluzione all'esercizio
int Percentuale(int counterMisure, int counterTemp1);

int main(int argc, char *argv[])
{

    // inserire qui il codice
    if (argc != 3)
    {
        cout << "Argomenti richiesti non inseriti" << endl;
        return -1;
    }

    fstream input1, input2;
    input1.open(argv[1], ios::in);
    input2.open(argv[2], ios::in);

    if (input1.fail() || input2.fail())
    {
        cout << "Errore nell'apertura degli stream!" << endl;
        return -1;
    }

    int buffer1 = 0, buffer2 = 0; // MR: non specificato che fossero interi
    int counterMisure = 0, counterTemp1 = 0;

    while (input1 >> buffer1)
    {
        input2 >> buffer2; // MR: cosa succede se il secondo file ha meno righe del primo? Manca controllo su EOF!

        if(buffer1 > buffer2){
            counterTemp1++;
        }
        counterMisure++;
    }

    // MR: manca controllo che counterMisure sia maggiore di 0, e se 0 l' output e' sbagliato
    cout << "La percentuale di misurazioni in cui la temperatura del motore1 ha superato quella del motore2 e' " << Percentuale(counterMisure, counterTemp1) << "%" << endl;
    
    input1.close();
    input2.close();
    return 0;
}

int Percentuale(int counterMisure, int counterTemp1){

    return (counterTemp1*100)/counterMisure;
}