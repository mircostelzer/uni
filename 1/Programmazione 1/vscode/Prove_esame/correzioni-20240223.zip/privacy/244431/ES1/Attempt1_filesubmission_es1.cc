#include <iostream>
#include <fstream>

using namespace std;

// Inserire qui sotto la soluzione all'esercizio

int Percentuale(int sup, int tot);

int main(int argc, char* argv[]) {

    fstream temp1, temp2;
    if(argc != 3){
        cerr << "Usage: ./a.out <input_file> <output_file>" << endl;
        exit(0);
    }

    temp1.open(argv[1], ios::in);
     if(temp1.fail()){
        cerr << "Errore apertura file di input" << endl;
        exit(0);
    }
    temp2.open(argv[2], ios::in);
     if(temp2.fail()){
        cerr << "Errore apertura file di input" << endl;
        exit(0);
    }

    float t1, t2, totale, superamento;
    char te1[2];
    char te2[2];
    totale = 0;
    superamento = 0;

    while(temp1>>te1) {
        temp2>>te2; // MR: cosa succede se il secondo file ha meno righe del primo? Va in EOF e non controlla!
        // MR: cosa succede se i numeri sono piu' di 2 caratteri? Inoltre, sta facendo buffer overflow su te1 e te2! Infatti per leggere due caratteri, viene anche messo \0 per terminatore di stringa.
        // MR: chi garantisce che i numeri siano interi? Chi garantisce che 48 corrisponda al carattere '0'?
        t1 = ((((int)te1[0])%48)*10)+((int)te1[1])%48;
        t2 = ((((int)te2[0])%48)*10)+((int)te2[1])%48;
        if (t1>t2) {
            superamento++;
        }
        totale++;
    }

    // MR: cosa succede se totale = 0?
    cout << "La percentuale di misurazioni in cui la temperatura del motore1 ha superato quella del motore2 e' del " << Percentuale(superamento,totale) << "%." << endl;

    temp1.close();
    temp2.close();

    return 0;

}

int Percentuale(int sup, int tot) {
    //calcolo la percentuale sup : tot = x : 100

    float percento = (sup * 100) / tot;

    return percento;
}
