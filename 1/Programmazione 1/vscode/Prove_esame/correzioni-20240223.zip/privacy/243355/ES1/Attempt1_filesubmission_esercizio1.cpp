#include <iostream>
#include <fstream>
using namespace std;

float percentuale(int m_tot, int m_mag)
{
    float percentuale = float(m_mag)/m_tot;
    return percentuale * 100.0;
}

int main(int argc, char *argv[])
{
    if (argc != 3)
    {
        cout << "usage: ./esercizio1.out <temperatura1.txt> <temperatura2.txt>" << endl;
        return -1;
    }

    fstream temp1, temp2;
    temp1.open(argv[1], ios::in);
    temp2.open(argv[2], ios::in);

    if (temp1.fail() || temp2.fail())
    {
        cout << "error: failed to open the input streams " << endl;
        return -2;
    }

    float t1;
    float t2;
    int n = 0;
    int i = 0;
    for (; temp1 >> t1 && temp2 >> t2; i++)
    {
        if (t1 < t2)
        {
            n++;
        }
    }

    if (i == 0)
    {
        cout << "Il numero delle misurazioni e' uguale a zero," << endl
             << " per cui non posso calcolare la percentuale" << endl;
    }
    else
    {
        cout <<   "La percentuale di misurazioni in cui la temperatura del motore2" << endl
             << "ha superato quella del motore1 e' del " << percentuale(i, n) << "%. " << endl;
    }

    temp1.close();
    temp2.close();
    return 0;
}