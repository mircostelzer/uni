#include <iostream>
#include <fstream>

// Inserire qui sotto la soluzione all'esercizio
using namespace std;

// MR: doveva ritornare un double/float non un int!
int Percentuale(int misTot, int mis2gt1);

int main(int argc, char* argv[]){

    if(argc != 3){
        cerr << "Error usage " << argv[0] << ": <temp1> <temp2>"<<endl;
        exit(0);
    }

    int misTot = 0;
    int mis2gt1 = 0;


    fstream ftemp1,ftemp2;
    ftemp1.open(argv[1], ios:: in);
    ftemp2.open(argv[2], ios:: in);

    if(ftemp1.fail()){
        cerr << "errore apertura file 1";
        exit(1);
    }

    if(ftemp2.fail()){
        cerr << "errore apertura file 2";
        ftemp1.close();
        exit(2);
    }

    int mis1 = 0; // MR: non era specificato che fossero interi!
    int mis2 = 0;
    while(ftemp1 >> mis1){
        ftemp2 >> mis2; // MR: cosa succede se il primo file ha piu' elementi del secondo? Manca controllo!
        misTot++;
        if(mis2>mis1)mis2gt1++;
    }
    if (mis1 != 0 && (misTot != 0)) // MR: il controllo con mis1 NON necessario e errato!
        cout << "La percentuale di misurazioni in cui la temperatura del motore2 ha superato quella del motore1 e' del "<<Percentuale(misTot,mis2gt1)<< "%"<<endl;
    // MR: il messaggio di errore non e' corretto rispetto a quanto specificato nel testo
    else cout << "non è stato possibile misurare"<< endl;

    ftemp1.close();
    ftemp2.close();


    return 0;
}

int Percentuale(int misTot, int mis2gt1){
    return (mis2gt1*100)/misTot;
}