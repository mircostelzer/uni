using namespace std;

#include <iostream>
#include <fstream>

// MR: doveva chiamarsi Percentuale e non percentuale!
float percentuale(int sup,int tot){
    float a=(float)sup/(float)tot;
    float b=(a*100);

    return b;
}

int main (int argc, char * argv []){

    if(argc!=3){
        cout<<"Assenza di parametri"<<endl;
        return 0;
    }

    fstream input1, input2;
    input1.open(argv[1], ios::in);
    input2.open(argv[2],ios::in);

    if(input1&&input2){ // MR: il controllo e' input1.fail() e input2.fail()!
        int m1,m2; // MR: non specificato che fossero interi
        int tot=0,sup=0;

        while(input1>>m1&&input2>>m2){
            tot++;
            if(m1>m2)
                sup++;
        }
        cout<<tot<<endl;
        cout<<sup<<endl;

        if(tot==0){
            // MR: l'output richiesto era diverso!
            cout<<"Misurazioni assenti, impossibile effttuare il calcolo"<<endl;
        }else{
            // MR: l'output richiesto era diverso!
            cout<<"La percentuale e' : "<<percentuale(sup,tot)<<"%"<<endl;
        }

        input1.close();
        input2.close();
    
    }else{
        // MR: potrebbe non chiudere dei files aperti!
        cout<<"errore apertura file"<<endl;
        return 0;
    }


    return 0;
}
