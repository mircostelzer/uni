
#include <iostream>
#include <fstream>

// Inserire qui sotto la soluzione all'esercizio
using namespace std;

float Percentuale (float volte_1, float volte_2) {
    float ris;
   if (volte_2 == 0) {
        ris = 100;

    }
    if (volte_1 == 0) {
        ris = 0;

    }
    if (volte_1 != 0 && volte_2 != 0) {
        ris = (volte_1 / (volte_2 + volte_1)) * 100;
    }
    return ris;
}


int main (int argc, char** argv) {

    if (argc != 3) {
        cout<<"Utilizzo: './a.out' 'input_1' 'input_2'."<<endl;
        exit (0);
    }

    fstream myin1, myin2;

    float confronto = -456;

    myin1.open(argv[1], ios::in);

    if (myin1.fail()) {
        cout<<"Impossibile aprire il file "<<argv[1]<<"."<<endl;
        myin1.close();
        exit (0);
    }

    float temp1 = confronto;

    int conta_temp1 = -1;

    float volte_1 = 0;

    myin2.open(argv[2], ios::in);

    if (myin2.fail()) {
        cout<<"Impossibile aprire il file "<<argv[2]<<"."<<endl;
        myin1.close();
        myin2.close();
        exit (0);
    }

    float temp2 = confronto;

    int conta_temp2 = -1;

    float volte_2 = 0;


    while(!myin1.eof()) {

        myin1>>temp1;
        if (temp1 != confronto) {
            conta_temp1++;
        }
        myin2>>temp2; // MR: non controlla se myin2 e' finito!
        if (temp2 != confronto) {
            conta_temp2++;
        }
       
        if (temp1 > temp2) {
            volte_1++;
        }
        temp1 = 0;
        temp2 = 0;
    }


    cout<<volte_1<<endl;

    volte_2 = conta_temp2 - volte_1; // MR: modo complicato ma corretto!!

    cout<<volte_2<<endl;

    cout<<conta_temp2<<endl;

    if (conta_temp1 == 0 || conta_temp2 == 0) {
        cout<<"Il numero delle misurazioni e' uguale a zero, per cui non posso calcolare la percentuale."<<endl;
        myin1.close();
        myin2.close();
        exit (0);
    }

    float percento = Percentuale(volte_1, volte_2);

    cout<<percento<<endl;

    cout<<"La percentuale di misurazioni in cui la temperatura del motore1 ha superato quella del motore2 e' del "<<percento<<"%."<<endl;

    myin1.close();
    myin2.close();

    return 0;

}