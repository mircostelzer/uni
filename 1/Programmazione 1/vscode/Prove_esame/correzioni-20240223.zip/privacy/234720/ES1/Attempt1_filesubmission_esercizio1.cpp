#include <iostream>
#include <fstream>
using namespace std;

double Percentuale(double sup, double tot){
    double perc = 0;
    if(tot!=0){
        perc = (sup/tot)*100;
    }
    return perc;
}

int main(int argc, char* argv[]){
    if(argc != 3){
        cout << "Usage: ./a.out <input1> <input2>" << endl;
        exit(1);
    }
    fstream input1, input2;
    input1.open(argv[1], ios::in);
    input2.open(argv[2], ios::in);
    if(input1.fail() || input2.fail()){
        cout << "Errore in lettura" << endl;
        exit(1);
    }
    int i=0, j=0;
    int a1[256]; // MR: NON era specificato che ci fossero al massimo 256 elementi!
    int a2[256];
    int buffer1;
    int buffer2;
    while(input1 >> buffer1) { // MR: cosa succede se ci sono piu' di 256 elementi?
        a1[i] = buffer1;
        i++;
    }
    while(input2 >> buffer2) { // MR: cosa succede se ci sono piu' di 256 elementi?
        a1[j] = buffer2;
        j++;
    }
    double sup=0;
    double tot=0;
    for(int k=0; k<i; k++){
        if(a2[k]>a1[k]){ // MR: cosa succede se il primo file contiene piu' elementi del secondo?? Manca controllo!
            sup++;
        }
        tot++;
    }

    // MR: se tot == 0 non posso calcolare la percentuale! Vado in divisione per 0!
    // MR: Percentuale ritorna un double, non un int, quindi qui approssimazione!
    int ris = Percentuale(sup, tot);
    if(tot==0){
        cout << "Il numero delle misurazioni e' uguale a zero, per cui non posso calcolare la percentuale" << endl;
    }else{
        cout << "La percentuale di misurazioni in cui la temperatura del motore2 ha superato quella del motore1 e' del "<< ris << "%." << endl;

    }
    






    input1.close();
    input2.close();

    return 0;

}