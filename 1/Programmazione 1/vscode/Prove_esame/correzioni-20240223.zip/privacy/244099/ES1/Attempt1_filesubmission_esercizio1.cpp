#include <iostream>
#include <fstream>
using namespace std;
// Inserire qui sotto la soluzione all'esercizio

// MR: Doveva ritornare un float/double non un intero!
int Percentuale(int numMisurazioniMagg,int numMisurazioniTot);
int LetturaFile(int argc, char * argv[]);
void StampaRisultato(int percent);

int main(int argc, char * argv[]){
    
    int percentuale = LetturaFile(argc, argv);
    StampaRisultato(percentuale);

    return 0;
}

int Percentuale(int numMisurazioniMagg, int numMisurazioniTot){
    int output = -1;
    if (numMisurazioniMagg==0)
    {
        return output;
    }
    else
    {
        output=(numMisurazioniMagg*100)/numMisurazioniTot;
        return output;
    }
}

int LetturaFile(int argc, char * argv[]){
    fstream valoriTemp1, valoriTemp2;
    valoriTemp1.open(argv[1],ios::in);
    valoriTemp2.open(argv[2],ios::in);
    // MR: manca controllo apertura file!

    int counter = -1;
    int counterMagg = 0;
    //if file errati messaggio di errore
    //else
    while(!valoriTemp1.eof()){ // MR: questo flag messo solo se si legge, quindi legge qualcosa di troppo
        char v1[2]; // MR: non specificato che "interi" hanno meno di 1 carattere!
        
        //valoriTemp1>>v1;
        valoriTemp1.getline(v1,3); // MR: v1 ha dimensione 2, non 3! Inoltre getline in string e non consentita
        int val1 = atoi(v1); // MR: atoi definita in cstdlib e non consentita!
       

        char v2[2];
        //valoriTemp2>>v2;
        valoriTemp2.getline(v2,3);
        int val2 = atoi(v2);
        //cout<<" val 2: "<<val2<<" val 1: "<<val1<<"\n";
        counter+=1;
        if (val2>val1)
        {
            counterMagg+=1;
        }     
    }
    //cout<<"cont "<<counter<<"\n";
    // MR: manca controllo che counter != 0!
    int percent = Percentuale(counterMagg,counter);
    // MR: manca la stampa richiesta!
    valoriTemp1.close();
    valoriTemp2.close();
    return percent;
}

void StampaRisultato(int percentuale){
    if (percentuale==-1)
    {
        cout<<"Il numero delle misurazioni e' uguale a zero,\n"<<" per cui non posso calcolare la percentuale\n";
    }
    else{
        cout<<"La percentuale di misurazioni in cui la temperatura del motore2\n"<<"ha superato quella del motore2 e' del "<<percentuale<<"%.\n";
    }
    
}