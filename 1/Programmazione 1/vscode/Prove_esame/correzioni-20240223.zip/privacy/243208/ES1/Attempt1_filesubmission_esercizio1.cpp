#include <iostream>
#include <fstream>

using namespace std;

double Percentuale(int QuantiMaggiori, int misurazioni);

int main(int argc, char* argv[]){
    fstream motore1, output, motore2;
    
    if(argc != 4){ // MR: due argomenti non 3!!!
        cout << "Numero di file non valido" << endl;
        exit(0);
    }

    motore1.open(argv[1], ios::in);
    motore2.open(argv[2], ios::in);
    output.open(argv[3], ios::out);
   

    if (motore1.fail() || motore2.fail()) {
            cout << "Uno dei file di  input non esiste!" << endl;
            exit(1);
        }
    double uno=0, due=0;
    int QuantiMaggiori=0, misurazioni=0;
    while(motore1 >> uno){
        motore2 >> due; // MR: cosa succede se il secondo file ha meno righe del primo? Va in EOF e non controlla!
        misurazioni++;
        if(uno>due) QuantiMaggiori++;
    }

    double res = Percentuale(QuantiMaggiori, misurazioni);

    // MR: output su stdout non su file!!
    if(res!=-1){
        output << "La percentuale di misurazioni in cui la temperatura del motore1 supera quella del motore2 e' del " << res << "%." << endl;
    }
    else 
        output << "Nessuna misurazione effettuata" << endl;

    motore1.close();
    motore2.close();
    output.close();
return 0;
}

double Percentuale(int QuantiMaggiori, int misurazioni){
    if(misurazioni==0) return -1;

    else return (QuantiMaggiori*100)/misurazioni;
}
