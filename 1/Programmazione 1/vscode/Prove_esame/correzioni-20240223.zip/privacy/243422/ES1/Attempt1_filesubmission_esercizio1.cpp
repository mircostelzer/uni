#include <iostream>
#include <fstream>

// Inserire qui sotto la soluzione all'esercizio
double Percentuale(int, int);

using namespace std;
int main (int argc, char * argv[]){
    if(argc!=3){
        cout<<"sintassi errata. Sintassi corretta: ./esercizio1 <input1.txt> <input2.txt>"<<endl;
        exit(0);
    }
    fstream in1;
    fstream in2;
    in1.open(argv[1], ios::in);
    if(in1.fail()){
        cout<<"errore nell'apertura del file: "<<argv[1]<<endl;
        exit(0);
    }
    in2.open(argv[2], ios::in); //append= ("output.txt", ios::out|ios::app)
    if(in2.fail()){
        cout<<"errore nell'apertura del file: "<<argv[2]<<endl;
        in1.close();
        exit(0);
    }
    int dim=0, n=0;
    double t1, t2;
    while(in1>>t1){
        in2>>t2; // MR: cosa succede se il secondo file ha meno righe del primo? Va in EOF e non controlla!
        if(t1>t2){
            n++;
        }
        dim++;
    }
    if(dim==0){
        cout<<"Il numero delle misurazioni e' uguale a zero, per cui non posso calcolare la percentuale"<<endl;
    }
    else{
        cout<<"La percentuale di misurazioni in cui la temperatura del motore1 ha superato quella del motore2 e' del "<<Percentuale(n, dim)<<"%"<<endl;
    }


    in1.close();
    in2.close();
}

double Percentuale(int n , int tot){
    return((double) n/tot *100);
}