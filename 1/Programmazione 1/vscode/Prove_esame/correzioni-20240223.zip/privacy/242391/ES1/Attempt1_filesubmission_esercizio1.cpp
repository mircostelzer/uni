#include <iostream>
#include <fstream>

// Inserire qui sotto la soluzione all'esercizio
using namespace std;

float Percentuale(int total_mes, int sup);
bool open_ifstream(std::ifstream &ifs, const char* filename);

int main(int argc, char* argv[]) {
    if (argc != 3) {
        cerr << "usage: ./a.out [file1] [file2]" << endl;
        return 1;
    }

    ifstream file_mot1;
    ifstream file_mot2;

    if (!open_ifstream(file_mot1, argv[1])) return 1;
    if (!open_ifstream(file_mot2, argv[2])) return 1;
    
    float meas1, meas2;
    
    int sup_meas = 0;
    int total_meas = 0;

    while (file_mot1 >> meas1 && file_mot2 >> meas2) {
        total_meas++;
        if (meas2 > meas1) sup_meas++;
    }

    if (total_meas > 0) {
        cout << "La percentuale di misurazioni in cui la temperatura del motore1" << endl
        << "ha superato quella del motore2 e' del " << Percentuale(sup_meas, total_meas) << "%." << endl;
    } else {
        cout << "Il numero delle misurazioni e' uguale a zero," << endl
        << "per cui non posso calcolare la percentuale" << endl;
    }

    file_mot1.close();
    file_mot2.close();

    return 0;
}

float Percentuale(int sup_meas, int total_meas) {
    return (100.0f / (float)total_meas) * sup_meas;
}

bool open_ifstream(std::ifstream &ifs, const char* filename) {
    ifs.open(filename, std::ifstream::in);

    if (ifs.fail()) {
        std::cerr << "errore nell'apertura di " << filename << std::endl;
        return false;
    }

    return true;
}
