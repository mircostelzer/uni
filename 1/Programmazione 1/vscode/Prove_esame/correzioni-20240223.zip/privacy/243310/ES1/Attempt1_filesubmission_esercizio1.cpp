#include <iostream>
#include <fstream>

using namespace std;

float Percentuale(int superato,int numeroMisurazioni);

int main(int argc, char*argv[])
{
    if(argc != 3)
    {
        cout<<"Usage: ./a.out <intputMotore1> inputMotore2"<<endl;
        exit(1);
    }
    fstream inMotore1,inMotore2;
    inMotore1.open(argv[1],ios::in);
    if(inMotore1.fail())
    {
        cout<<"Errore nell'apertura del file di input del motore 2"<<endl;
        exit(1);
    }
    inMotore2.open(argv[2],ios::in);
    if(inMotore2.fail())
    {
        cout<<"Errore nell'apertura del file di input del motore 2"<<endl;
        exit(1);
    }

    float datoMotore1, datoMotore2;
    int numeroMisurazioni = 0;
    int superato = 0;
    while(inMotore1>>datoMotore1 && inMotore2>>datoMotore2)
    {
        numeroMisurazioni++;
        if(datoMotore1 < datoMotore2)
        {
            superato++;
        }
    }

    if(numeroMisurazioni == 0)
    {
        cout<<" Il numero delle misurazioni e' uguale a zero, per cui non posso calcolare la percentuale"<<endl;
    }
    else{
        cout<<"La percentuale di misurazioni in cui la temperatura del motore2 ha superato quella del motore1 e' del "<< Percentuale(superato,numeroMisurazioni)<<"%"<<endl;
    }
    inMotore1.close();
    inMotore2.close();
}

float Percentuale(int superato,int numeroMisurazioni)
{
    return ((float)superato/(float)numeroMisurazioni)*100.0;
}