#include <iostream>
#include <fstream>
using namespace std;

// Inserire qui sotto la soluzione all'esercizio

// MR: doveva chiamarsi Percentuale e non percentuale!
float percentuale(int count, int misTot){
    float percent;

    percent=(count*100)/misTot;
    return percent;
}

int main(int argc, char* argv[]){

    if(argc != 3){
        cout << "numero di poarametri incorretto" << endl;
        return 1;
    }

    fstream motore1;
    fstream motore2;

    motore1.open(argv[1], ios::in);
    if(motore1.fail()){
        cout << "errore in apertura file" << endl;
        return 1;
    }
    motore2.open(argv[2], ios::in);
    if(motore2.fail()){
        motore1.close();
        cout << "errore in apertura file" << endl;
        return 1;
    }

    float temp1;
    float temp2;
    int misTot=0;
    int count=0;
    float percent;
    while(motore1>>temp1){
        motore2 >> temp2; // MR: cosa succede se il secondo file ha meno righe del primo? Manca controllo su EOF!
        misTot++;
        if(temp1>temp2){
            count++;
        }
        motore2 >> temp2;
    }
    
    if(misTot==0){ // MR: l' output non e' conforme con quanto richiesto nel testo dell'esercizio
        cout<< "impossibile calcolare la percentuale" << endl;
    }else{
        percent = percentuale(count, misTot);
        cout << "la percentuale corrisponde a " << percent << endl;
    }

    motore1.close();
    motore2.close();
    return 0;
}