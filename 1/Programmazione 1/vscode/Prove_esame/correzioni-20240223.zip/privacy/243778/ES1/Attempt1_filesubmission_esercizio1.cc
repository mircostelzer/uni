#include <iostream>
#include <fstream>

using namespace std;

int Percentuale(int, int);

int main(int argc, char **argv){

    if(argc != 3){
        cerr << "Usage: ./a.out <temperatura1.txt> <temperatura2.txt>" << endl;
        exit(1);
    }

    fstream temp1, temp2;
    temp1.open(argv[1], ios::in);
    temp2.open(argv[2], ios::in);
    if(temp1.fail() || temp2.fail()){
        cerr << "Error in file opening" << endl;
        exit(2);
    }
    
    char t[5];
    int t_len = 0;
    while(!temp1.eof()){
        temp1 >> t;
        t_len++;
    }
    temp1.close();

    // MR: sta allocando un array dinamico sullo stack, e come detto ripetutamente non consentito!
    int t1[t_len]; // MR: dove specificato che sono interi?
    int i = 0;
    temp1.open(argv[1], ios::in);
    
    while(!temp1.eof()){
        temp1 >> t;
        // MR: atoi e' definito in cstdlib e quindi non consentito
        t1[i] = atoi(t);
        i++;
    }
    temp1.close();

    int t2[t_len];
    int j = 0;
    while(!temp2.eof()){ // MR: cosa succede se file 2 ha meno elementi? Manca controllo
        temp2 >> t;
        t2[j] = atoi(t);
        j++;
    }
    temp2.close();

    int counter = 0;
    for(int i = 0; i < t_len; i++){
        if(t1[i] > t2[i]){
            counter++;
        }
    }

    if(counter == 0){
        cout << "Il numero delle misurazioni e' uguale a zero, per cui non posso calcolare la percentuale" << endl;
    }else{
        int perc = Percentuale(counter, t_len);
        cout << " La percentuale di misurazioni in cui la temperatura del motore1 ha superato quella del motore2 e' del " << perc << "%." << endl;
    }


    return 0;
}

int Percentuale(int counter, int t_len){
    double perc = ((double) counter/t_len)*100;
    int p = perc;
    return p;
}
