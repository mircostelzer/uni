#include <iostream>
#include <fstream>
using namespace std;

// Inserire qui sotto la soluzione all'esercizio

int percentuale (int a, int b);

int main (int argc, char * argv[]) {
    if (argc!=3) {
        cerr << "Uso: ./a.out <temperatura1.txt> <temperatura2.txt>" << endl;
        exit(0);
    }

    int y;
    int x;
    float a = 1.00;
    float b = 1.00;
    float c;

    ifstream file1(argv[1]);

    if (!file1.is_open()) {
        cerr << "Impossibile aprire il file " << argv[1] << endl;
        exit(1);
    }

    ifstream file2(argv[2]);
    

    if (!file2.is_open()) {
        cerr << "Impossibile aprire il file " << argv[2] << endl;
        exit(1);
    }

    while (file1 >> y) {
        a++;
        // MR: cosi' non funziona! Il file2 viene letto solo una volta!
        // MR: doveva controllare riga per riga
        while (file2 >> x) {
            if (x > y) {
            b++;
            // MR: manca chiamata a Percentuale
            c = (a / b);
            cout << "La percentuale di misurazioni in cui la temperatura del motore1 ha superato quella del motore2 e' del " << (c * 100) << " %" << endl;
            }
        } 
    }
        
    file1.close();
    file2.close();

    return 0;
}
