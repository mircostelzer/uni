#include <iostream>
#include <fstream>
using namespace std;

int Percentuale(int n,int tot);
int main(int argc, char ** argv){
    if(argc!=3){
        cout<<"usage: "<<argv[0]<<" <file1> <file2>"<<endl;
        return -1;
    }
    fstream input1,input2;
    input1.open(argv[1],ios::in);
    input2.open(argv[2],ios::in);
    if(input1.fail() || input2.fail()){
        cout<<"errore con l'apertura del file"<<endl;
        return -2;
    }
    int t1,t2;// MR non era specificato che fossero interi
    int n=0,tot=0;
    while(input1>>t1 && input2>>t2){
        if(t1>t2){
            n++;
        }
        tot++;
    }
    if(tot!=0){
        cout<<"percentuale di misurazioni in cul la temperatura del motore 1 ha superato la temperatura del motore 2: "<<Percentuale(n,tot)<<"%"<<endl;
    }else{
        cout<<"il numero delle misuarzioni è uguale a zero, impossibile calcolare la percentuale"<<endl;
    }
    input1.close();
    input2.close();
    return 0;
}

int Percentuale(int n,int tot){
    int p=(n*100)/tot;
    return p;
}