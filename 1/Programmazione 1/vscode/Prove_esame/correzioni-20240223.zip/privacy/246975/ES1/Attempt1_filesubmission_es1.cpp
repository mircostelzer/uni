#include <iostream>
#include <fstream>

using namespace std;

// MR: doveva chiamarsi Percentuale non percentuale!
// MR: doveva ritornare un float/double e non un int!
// MR: doveva prendere in input due interi NON due array di interi!
int percentuale(int a[], int b[], int n){

int x, y, c, i=n;

   for(int j=0; j<i; j++){
      if(a[i]>b[i]){
         
         x++;
         i++;
      }else{
         y++;
         i++;
      }
   }

c = (y/x)*100;

return c;

}

int main(){

 ifstream in1("temperatura1.txt");
 ifstream in2("temperatura2.txt");

in1.open("temperatura1.txt");
in2.open("temperatura2.txt");

if(!in1.open() || !in2.open()){ 
   cout << "impossibile calcolare" << endl;
}else{

   int n=0, m=0;
   int a[n], b[m], c; // MR: the arrays have 0 dimension!
   string line1, line2; // MR: string non e' da usare come specificato diverse volte a lezione!

   while(getline(in1, line1)){ // MR: getline definita in <string> e non in <iostream> quindi non consentita!
   
      a[n] = (int) line1; // MR: here you're casting a string to an int, which is not allowed!
      n++;
   }

   while(getline(in2, line2)){
   
      b[m] = (int) line2;
      m++;
   }

   c = percentuale(a, b, n);

   cout << c << endl;

   in1.close();
   in2.close();
}

}