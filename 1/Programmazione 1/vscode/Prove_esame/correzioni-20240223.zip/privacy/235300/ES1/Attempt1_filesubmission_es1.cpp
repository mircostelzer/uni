#include <iostream>
#include <fstream>
#include <cstring>

using namespace std;

const int DIM_MAX = 256;

int percentuale(int t1Max, int righeTotali);
int verificaVuoto(char* filename);

int main(int argc, char* argv[]) {
    if (argc != 3){
        cout <<"errore nel numero di file";
        exit(1);
    }
    ifstream input1, input2;
    input1.open(argv[1], ios::in);
    if (input2.fail()) {
        cout << "L'apertura del file 'temperatura1.txt' è fallita" << endl;
        exit(1);
    }
    input2.open(argv[2], ios::in);
    if (input2.fail()) {
        cout << "L'apertura del file 'temperatura2.txt' è fallita" << endl;
        exit(1);
    }
    
    if (verificaVuoto(argv[1])){
        cout << "il file 'temperatura1.txt' è vuoto" << endl;
    } else if (verificaVuoto(argv[1])){
        cout << "il file 'temperatura1.txt' è vuoto" << endl;
    }else {
    
        char buffer1[DIM_MAX];
        char buffer2[DIM_MAX];
        // MR: non era specificato che t1 e t2 erano interi!
        int t1, t2;
        int righe = 0;
        int t1Max = 0;
        while(input1>>buffer1 && input2>>buffer2){
            // MR: atoi fa parte di cstdlib e quindi non e' consentito!
            if (atoi(buffer1) == 0 || atoi(buffer2) == 0){
                cout << "Questa parte di file non è numerica" << endl;
                return 0; 
            }else{
                t1 = atoi(buffer1);
                t2 = atoi(buffer2);
                if (t1 > t2){
                    t1Max++;
                }
                righe++;
            }
        }
        input1.close();
        input2.close();
        int res;
        // MR: in teoria era Percentuale!!! Manca controllo che righe sia diverso da 0!
        res = percentuale(t1Max, righe);
        cout << "La percentuale di misurazioni in cui la temperatura del motore ha superato quella del motore2 e' del " << res << "%." << endl;
        // MR: non rispecchia quanto specificato nel testo!, ovvero il messaggio nel caso i file siano vuoti!
    }
    
    return 0;
}

int verificaVuoto(char* filename){
    bool empty = true;
     char buffer[DIM_MAX];
    ifstream f(filename, ios::binary );
    while (f.getline(buffer, DIM_MAX)){
        empty = false;
    } 
    return empty;
}


int percentuale(int t1Max, int righeTotali){
    int res;
    res = (t1Max * 100)/righeTotali;
    return res;    
}