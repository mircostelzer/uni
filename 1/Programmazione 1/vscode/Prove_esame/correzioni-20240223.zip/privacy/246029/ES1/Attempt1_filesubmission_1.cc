#include <iostream>
#include <fstream>
using namespace std;

// MR: doveva chiamarsi Percentuale e non percentuale!
float percentuale(float n,float conta){
    float ris;
    ris=(conta/n)*100;
    return ris;

}


int main(int argc, char *argv[]){
    if(argc!=3){
        cout << "<file txt motore 1><file txt motore 2>" << endl;
        return 0;
    }

    ifstream input1;
    input1.open(argv[1]);
    // MR: manca controllo che il file sia aperto correttamente
    
    int n=0,buffer;
    while(!input1.fail() && input1 >> buffer){
        n++;
    }
    int val1[n],val2[n],i=0; // MR: cosa succede se file 2 ha meno elementi di file 1? Manca controllo su EOF!
    // MR: cosi' alloca sullo stack array di dimensione n, che potrebbe essere molto grande! E come detto ripetutamente non consentito!
    while(!input1.fail() && input1 >> buffer){
        val1[i]=buffer;
        i++;
    }

    i=0;
    ifstream input2;
    input1.open(argv[2]);
    // MR: manca controllo che il file sia aperto correttamente
    while(!input2.fail() && input2 >> buffer){
        val2[i]=buffer;
        i++;
    }
    int num1=0,num2=0;
    for(int i=0;i<n;i++){
        if(val1[i]==' '){
            num1++;
        }
        if(val2[i]==' '){
            num2++;
        }
    }
    if(num1==n){
        cout << "Il file 1 txt non contiene misurazioni" << endl;
        return -1;
    }
    if(num2==n){
        cout << "Il file 2 txt non contiene misurazioni" << endl;
        return -2;
    }

    int conta=0;
    for(int i=0;i<n;i++){
        if(val1[i]>val2[i]){
            conta++;
        }
        
    }
    // MR: i calcoli sono sbagliati!
    float perc=percentuale(n,conta);
    cout << "Il motore 1 ha un aumento del " << perc << "%" << endl;
    input1.close();
    input2.close();
}