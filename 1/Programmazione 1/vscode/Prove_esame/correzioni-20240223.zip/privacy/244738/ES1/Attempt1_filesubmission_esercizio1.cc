#include <iostream>
#include <fstream>

using namespace std;
int Percentuale(int t1_t2,int dim_files){
    return (t1_t2*100)/dim_files;
}
int main(int argc, char *argv[])
{
    if (argc != 3)
    {
        cout << "Usage: esercizio1 <temperatura1.txt>  <temperatura2.txt>" << endl;
        exit(1);
    }

    // Open input and output files
    ifstream temp1(argv[1]);
    ifstream temp2(argv[2]);

    // Check for file opening errors
    if (temp1.fail() || temp2.fail())
    {
        cerr << "Errore nell'apertura del file di IO" << endl;
        exit(EXIT_FAILURE);
    }
    int t1 = 0; // MR: non specificato che fossero interi!
    int t2 = 0;
    int dim_files = 0;
    int t1_t2 = 0;
    while(temp1 >> t1 && temp2 >> t2){
        dim_files++;
        if(t1 > t2){
            t1_t2++;
        }
    }
    if(dim_files == 0){
        cout << "Il numero delle misurazioni e' uguale a zero,  per cui non posso calcolare la percentuale" << endl;
    }else{
        cout << "La percentuale di misurazioni in cui la temperatura del motore1 ha superato quella del motore2 e' del " << Percentuale(t1_t2,dim_files) << "%"  << endl;
    }
    

    temp1.close();
    temp2.close();
    return 0;
}
