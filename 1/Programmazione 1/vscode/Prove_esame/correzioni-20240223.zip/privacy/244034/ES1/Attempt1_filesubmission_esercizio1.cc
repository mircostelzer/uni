using namespace std;
#include <iostream>
#include <fstream>

double Percentuale (double n_superamenti, int tot_temperature);


int main(int argc, char *argv[])
{
    if (argc!=3)
    {
        cout << "Invalid number of arguments" << endl;
        cout << "./a.out <temperatura_motore1> <temperatura_motore2>" << endl;
        exit(0);
    }
    fstream motore1_stream, motore2_stream;
    motore1_stream.open (argv[1], ios::in);
    if (motore1_stream.fail())
    {
        cout << "Error" << endl;
        exit(0);
    }
    motore2_stream.open (argv[2], ios::in);
    if (motore2_stream.fail())
    {
        cout << "Error" << endl;
        motore1_stream.close();
        exit(0);
    }
    //CODE HERE:
    int n_temperature=0;
    int n_superamenti=0;
    int current_temperature1=0; // MR: non specificato che fossero interi!
    int current_temperature2=0;
    while (motore1_stream >> current_temperature1 && motore2_stream >> current_temperature2)
    {
        n_temperature++;
        if (current_temperature2 > current_temperature1)
            n_superamenti++;
    }
    if (n_superamenti==0) // MR: doveva essere n_temperature! Potrebbe essere 0, ma numero temperature e' diverso da 0!
        cout << "Il numero delle misurazioni è uguale a zero, per cui non posso calcolare la percentuale" << endl;
    else
        cout << "La percentuale di misurazioni in cui la temperatura del motore 1 ha superato quella del motore 2 è del " << Percentuale (n_superamenti, n_temperature) << "%" << endl;
        //END OF CODE
    motore1_stream.close();
    motore2_stream.close();
    return 0;
}

double Percentuale (double n_superamenti, int tot_temperature)
{
    return (n_superamenti/tot_temperature)*100;
}