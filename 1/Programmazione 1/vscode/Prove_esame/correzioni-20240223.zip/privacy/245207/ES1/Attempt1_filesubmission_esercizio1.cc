#include <iostream>
#include <fstream>

// Inserire qui sotto la soluzione all'esercizio
using namespace std;
// MR: doveva chiamarsi Percentuale non percentuale!
double percentuale(int, int);

int main(int argc, char*argv[])
{
    if(argc!=3)
    {
        cerr<<"Devi inserire ./a.out temperatura1.txt temperatura2.txt"<<endl;
    }

    fstream myin1;
    fstream myin2;
    myin1.open(argv[1], ios::in);
    myin2.open(argv[2], ios::in);
    if(myin1.fail()||myin2.fail())
    {
        cerr<<"Errore apertura file input"<<endl;
        exit(1);
    }
    
    int temperatura1; // MR: non era specificato che fossero interi
    int temperatura2;
    int misurazioni=0;
    int x=0;
    while(myin1>>temperatura1 && myin2>>temperatura2)
    {
        if(temperatura2>temperatura1)
        {
            x++;
        }
        misurazioni++;
    }
    if(misurazioni==0)
    {
        cout<<"Il numero delle misurazioni e' uguale a zero, per cui non posso calcolare la percentuale"<<endl;
    }
    else{
       double p=percentuale(misurazioni, x) ;
       cout<<"La percentuale di misurazioni in cui la temperatura del motore2 ha superato quella del motore1 e' del "<<p<<"%"<<endl;
    }

    myin1.close();
    myin2.close();
    return 0;
}

double percentuale(int tot, int n)
{
    double x=(n*100)/tot;
    return x;
}
