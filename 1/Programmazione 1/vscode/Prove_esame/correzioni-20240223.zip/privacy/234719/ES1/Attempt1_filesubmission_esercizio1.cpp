#include <iostream>
#include <fstream>

using namespace std;
int Percentuale(int conta, int contaTot);

int main (int argc, char * argv[]) {
    // MR: non era specificato che t1 e t2 erano interi!
    int t1 = 0;
    int t2 = 0;
    int count = 0;
    int countTot = 0;
    fstream myint1,myint2;

    if(argc!=3){
        cout << "Non ci sono abbastanza file ! \n";
        exit(0);
    }
    myint1.open(argv[1],ios::in);
    myint2.open(argv[2],ios::in);
    if (myint1.fail() || myint2.fail()) {
        cout << "Errore nell'apertura dei file";
        return 1;
    }
    while(!myint1.eof() && !myint2.eof()){
        myint1 >> t1;
        myint2 >> t2;
        
        if(myint1.eof() && myint2.eof()){ // MR: se entrambi i file sono finiti, allora esci dal ciclo senza fare modifiche, infatti in tal caso la lettura non e' avvenuta e t1 e t2 non sono letti!
            if(t1>t2){
            count++;
            countTot++;
            }
            break;
        }
        else{
            countTot++;
            if(t1>t2){
            count++;
            }
        }
    }
    cout << count << " "<< countTot << endl;
    if(countTot == 0){
        cout << "Il numero delle misurazioni e' uguale a zero,per cui non posso calcolare la percentuale"<<endl;
    }
    else{
        cout << countTot << endl;
        float percentuale = Percentuale(count,countTot);
        cout << "La percentuale di misurazioni in cui la temperatura del motore1 ha superato quella del motore2 e' del "<< percentuale << "%"<< endl;
    }
    
    myint1.close();
    myint2.close();
    return 0;
    
}
int Percentuale(int conta, int contaTot){
    //cout << conta << " "<< contaTot << endl;
    float res = ((float)conta/contaTot)*100;
    //cout << res << endl;
    return res;

}


