#include <iostream>
#include <fstream>

// Inserire qui sotto la soluzione all'esercizio
using namespace std;

// MR: Percentuale deve ritornare un float non un int!
int Percentuale(int, int);

int main(int argc, char* argv[]){
    if(argc != 3) {
        cerr << "Usage: a.out <inputFile1> <inputFile2>";
        exit(1);
    }

    fstream in1, in2;
    in1.open(argv[1], ios::in);
    if(in1.fail()){
        cerr << "Errore nell'apertura del primo file di input" << endl;
        exit(1);
    }
    in2.open(argv[2], ios::in);
    if(in2.fail()){
        cerr << "Errore nell'apertura del secondo file di input" << endl;
        exit(1);
    }
    
    //Scrivi QUI

    float motore1;
    float motore2;
    int datiTot = 0;
    int superato = 0;
    
    while(in1 >> motore1) {
        datiTot++;
        in2 >> motore2; // MR: se il primo file ha piu' elementi del secondo cosa succede? Manca controllo!
        if(motore2 > motore1) {
            superato++;
        }
    }

    if(superato != 0) {
        cout << "La percentuale di misurazioni in cui la temperatura del motore2 ha superato quella del motore1 e' del " << Percentuale(datiTot, superato) << "%" << endl;
    } else {
        cout << "Il numero delle misurazioni e' uguale a zero, per cui non posso calcolare la percentuale" << endl;
    }
    
    
    in1.close();
    in2.close();

    return 0;
}

int Percentuale(int totali, int superati) {
    // MR: qui fa divisione intera, quindi potrebbe diventare 0 se totali e' maggiore di superati * 100, dando risultato sbagliato
    return ((superati * 100) / totali);
}