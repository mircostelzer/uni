#include <iostream>
#include <fstream>

// Inserire qui sotto la soluzione all'esercizio
using namespace std;

float Percentuale(float t1maggt2, float nMisure);

int main(int argc, char * argv[]) {

    if(argc != 3) {
        cout << "usage: .out temperatura1.txt temperatura2.txt" << endl;
        exit(1);
    }
    fstream temp1, temp2;
    temp1.open(argv[1], ios::in);
    temp2.open(argv[2], ios::in);

    if(temp1.fail() || temp2.fail()) {
        cout << "error opening files" << endl;
        temp1.close();
        temp2.close();    
        
        exit(1);
    }

    int t1magt2=0;
    int nMisure=0;
    float misuraT1 =0; 
    float misuraT2 =0;
    while(!temp1.eof()) { // MR: cosa succede se file 2 ha meno elementi? Manca controllo
    // MR: in questo modo legge una volta di piu', e controlla troppo tardi (al ciclo successivo) se EOF, sbagliando i conti
        temp1 >> misuraT1;
        temp2 >> misuraT2;
        //cout << misuraT1+misuraT2 << endl;;
        if(misuraT1 > misuraT2) {
            t1magt2++;
        }
        nMisure++;
    }

    cout << t1magt2 << ' ' << nMisure << endl;
    
    if(nMisure == 0) {
        cout << "Il numero delle misurazioni e' uguale a zero, " << endl << "per cui non posso calcolare la percentuale" << endl;
    } else {
        cout << "La percentuale di misurazioni in cui la temperatura del motore1" << endl << 
        "ha superato quella del motore2 e' del "<< (Percentuale(t1magt2, nMisure)*100) << "%." << endl;
    }



    temp1.close();
    temp2.close();


    return 0;
}


float Percentuale(float t1maggt2, float nMisure) {
    //cout << endl<< t1maggt2 << ' ' << nMisure << endl;
    float res=(t1maggt2/nMisure);
    return res;
}