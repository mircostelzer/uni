#include <iostream>
#include <fstream>

// Inserire qui sotto la soluzione all'esercizio
using namespace std;

float Percentuale(int counter, int total) {
    float res = 100*counter/total;
    return res;
}

int main(int argc, char **argv)
{
    if (argc != 3)
    {
        cerr << "Numero di parametri non corretto" << endl;
        exit(1);
    }
    fstream motore1, motore2;
    motore1.open(argv[1], ios::in);
    motore2.open(argv[2], ios::in);
    if (motore1.fail() || motore2.fail())
    {
        cerr << "Errore lettura file di input" << endl;
        exit(1);
    }
    //
    int counter = 0, total = 0;
    float v1, v2;
    while (motore1 >> v1 && motore2 >> v2) {
        if (v2 > v1) {
            counter++;
        }
        total++;
    }
    //
    if (total > 0) {
        float percentage = Percentuale(counter, total);
        cout << "La percentuale di misurazioni in cui la temperatura del motore2 ha superato quella del motore 1 è " << percentage << "%" << endl;
    } else {
        cout << "Il numero delle misurazioni e' uguale a zero, per cui non posso calcolare la percentuale" << endl;
    }
    //
    motore1.close();
    motore2.close();
    return 0;
}