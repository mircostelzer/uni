using namespace std;
#include <iostream>
#include <fstream>

double Percentuale(double mis1, double mistot);

// Inserire qui sotto la soluzione all'esercizio
int main(int argc, char * argv[]){
    if(argc!=3){
        cout<<"esercizio1.cpp Usage: <"<<argv[0]<<"> <temperatura1.txt> <temperatura2.txt>"<<endl;
        exit(1);
    }
    fstream in1, in2;
    in1.open(argv[1], ios::in);
    in2.open(argv[2], ios::in);
    if(in1.fail() || in2.fail()){
        cout<<"Errore nell'apertura di <"<<argv[1]<<"> o di <"<<argv[2]<<">. Il numero delle misurazioni e' uguale a zero, per cui non posso calcolare la percentuale."<<endl;
        exit(1);
    }
    char buff1[10], buff2[10];
    int buff1_size=0, buff2_size=0, pot=1, temp1=0, temp2=0;
    double misure_tot=0.0, misure_1=0.0;
    while(in1>>buff1 && in2>>buff2){
        // MR: non era specificato che fossero interi!
        for(int i=0; buff1[i]!='\0'; i++){
            buff1_size=i;
        }
        for(int i=0; buff2[i]!='\0'; i++){
            buff2_size=i;
        }
        for(int j=buff1_size; j>=0; j--){
            temp1=temp1+(((int)buff1[j]-'0')*pot);
            pot*=10;
        }
        pot=1;
        for(int j=buff2_size; j>=0; j--){
            temp2=temp2+(((int)buff2[j]-'0')*pot);
            pot*=10;
        }
        pot=1;
        if(temp1>temp2){
            misure_1+=1;
        }
        misure_tot+=1;
        temp1=0;
        temp2=0;
    }
    if(misure_tot==0.0){
        cout<<"Il numero delle misurazioni e' uguale a zero, per cui non posso calcolare la percentuale."<<endl;
    }else{
        cout<<"Il numero delle misurazioni in cui la temperatura del motore1 ha superato quella del motore2 e' del "<<Percentuale(misure_1, misure_tot)<<"%"<<endl;
    }
    in1.close();
    in2.close();

    return 0;
}

double Percentuale(double mis1, double mistot){
    double res=(mis1/mistot)*100;
    return res;
}