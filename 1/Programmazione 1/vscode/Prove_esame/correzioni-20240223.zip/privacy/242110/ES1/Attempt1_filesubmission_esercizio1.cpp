#include <iostream>
#include <fstream>

// Inserire qui sotto la soluzione all'esercizio
double Percentuale(int, int);

int main(int argc, char* argv[])
{
    if(argc!=3)
    {
        std::cout<<"./a.exe <input1> <input2>"<<std::endl;
        exit(1);
    }

    int sup=0, tot=0, tmp=10;
    double val1=0, val2=0;
    char buffer1[2], buffer2[2]; //supponendo che le temperature siano 
                                 //esprimibili con al max. 2 cifre
                                 // MR: allora doveva mettere 3 perche' il terminatore di stringa '\0'!
    std::fstream motore1, motore2;
    motore1.open(argv[1], std::ios::in);
    motore2.open(argv[2], std::ios::in);

    if (motore1.fail()) {
        std::cerr<<"Il file "<<argv[1]<<" non esiste."<<std::endl;
        exit(0);
    }

    if (motore2.fail()) {
        std::cerr<<"Il file "<<argv[2]<<" non esiste."<<std::endl;
        exit(0);
    }

    while(motore1>>buffer1&&motore2>>buffer2) // MR: va bene e non fa accesso a indici corretti se e solo se le cifre hanno un solo numero!
    {  
        tot++;

        for(int i=0; i<2; i++)
        {
            val1+=tmp*(buffer1[i]-'0');
            val2+=tmp*(buffer2[i]-'0');           
            tmp/=10;
        }

        if(val2>val1)
        {
            sup++;
        }

        val1=0;
        val2=0;
        tmp=10;
    }

    if(tot!=0)
    {
        double ris=Percentuale(sup, tot);
        std::cout<<"La percentuale di misurazioni in cui la temperatura del motore1 ha superato quella del motore2 e' del "<<ris<<"%."<<std::endl;
    }
    else
    {
        std::cout<<"Il numero delle misurazioni e' uguale a zero, per cui non posso calcolare la percentuale."<<std::endl;
    }

    motore1.close();
    motore2.close();

    return 0;
}

double Percentuale(int x, int y)
{   
    int perc=0; 
    double a=x, b=y;

    perc=a/b*100;
    
    return perc;
}