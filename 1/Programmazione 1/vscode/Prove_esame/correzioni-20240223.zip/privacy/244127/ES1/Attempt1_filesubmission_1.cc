#include <iostream>
#include <fstream>

// Inserire qui sotto la soluzione all'esercizio

using namespace std;

// MR: doveva ritornare un double/float non un int!
int Percentuale(int volte, int n_temp_maggiori);

int main(int argc, char* argv[]){
    if (argc != 3){
        cout << "Uso ./1.out <file_1> <file_2>" << endl;
        return 0;
    }



    fstream temp_1;
    fstream temp_2;
    temp_1.open(argv[1], ios::in);
    temp_2.open(argv[2], ios::in);
    if (temp_1.fail() || temp_2.fail()){
        cout << "Errore nell'apertura di uno o di entrambi i file" << endl;
        return 0;
    }



    int volte = 0;
    char f[30];
    while (temp_1>>f){
        volte++;
    }

    if (volte == 0){
        cout << "Il numero delle misurazioni è uguale a zero, per cui non posso calcolare la percentuale" << endl;
        return 0;
    }



    temp_1.close();
    temp_1.open(argv[1], ios::in);
    if (temp_1.fail()){
        cout << "Errore nell'apertura del file" << endl;
        return 0;}



    int t1[volte];
    int t2[volte];
    int z = 0;
    char g[30];
    char h[30];
    while (temp_1>>g){ // MR: uso di atoi non consentito perche' in cstdlib!
        t1[z] = atoi(g);
        z++;
    }
    z = 0;
    while (temp_2>>h){ // MR: cosa succede se file 2 ha piu' elementi di file 1? Manca controllo!
        t2[z] = atoi(h);
        z++;
    }



    int n_temp_maggiori = 0; //le volte che le temperature del secondo motore hanno superato quello del primo
    for (int i = 0; i < volte; i++){
        if (t1[i] > t2[i]){ // MR: controllo per v1 e non per v2!
            n_temp_maggiori++;
        }
    }


    int perc = Percentuale(volte, n_temp_maggiori);
    cout << "La percentuale di misurazioni in cui la temperatura del motore1 ha superato quella del motore2 è del " << perc << "%" << endl;


    temp_1.close();
    temp_2.close();
    return 0;
}

int Percentuale (int volte, int n_temp_maggiori){
    float p = (n_temp_maggiori * 100) / volte;
    return p;
}