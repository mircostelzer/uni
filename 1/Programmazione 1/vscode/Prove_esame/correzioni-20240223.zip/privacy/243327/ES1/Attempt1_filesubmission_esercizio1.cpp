#include <iostream>
#include <fstream>  


using namespace std;

double Percentuale(double motore1maggiore, double misurazioni);

int main(int argc, char* argv[]) 
{
    if(argc < 4) 
    {  // MR: il testo specificava che output doveva essere su stdout e non su file!!!
        cout << "Errore --> ./a.out <input1> <input2> <input3>" << endl; 
        exit(1);
    }

    fstream in1, in2, out;

    in1.open(argv[1], ios::in);

    if (in1.fail())
    {
        cout << "Errore --> Si è verificato un errore nell'apertura del file: " << argv[1] << endl; 
        exit(1);
    }

    in2.open(argv[2], ios::in);

    if (in2.fail())
    {
        cout << "Errore --> Si è verificato un errore nell'apertura del file: " << argv[2] << endl; 
        in1.close();
        exit(1);
    }


    out.open(argv[3], ios::out);

    if (out.fail())
    {
        cout << "Errore --> Si è verificato un errore nell'apertura del file: " << argv[3] << endl; 
        in1.close();
        in2.close();
        exit(1);
    }

    double temp1 = 0, temp2 = 0;
    int mis = 0, mag = 0;
    
    while(in1>>temp1 && in2>>temp2){

        mis++;

        if(temp1>temp2){
            mag++;
        }

    }

    if(mis>0){
        out<<"La percentuale di misurazioni in cui la temperatura del motore1 ha superato quella del motore2 e' del "<<Percentuale(mag, mis)<<"%."<<endl;
    }else{
        out<<"  Il numero delle misurazioni e' uguale a zero, per cui non posso calcolare la percentuale"<<endl;
    }
    
    in1.close();
    in2.close();
    out.close();
    return 0;
}

double Percentuale(double motore1maggiore, double misurazioni){
    double res = (motore1maggiore/misurazioni)*100;
    return res;
}