#include <fstream>
#include <iostream>

using namespace std;

float Percentuale(int t1maggt2, int totTemps);

int main(int argc, char *argv[]){

    if(argc != 3){
        cout << "Utilizzo: " << argv[0] << " <file_temp1> <file_temp2>" << endl;
    }

    fstream temp1;
    temp1.open(argv[1], ios::in);
    
    if(temp1.fail()){
        cout << "Errore nell'apertura di " << argv[1] << endl;
        exit(1);
    }

    fstream temp2;float Percentuale(int t1maggt2, int totTemps);
    temp2.open(argv[2], ios::in);
    
    if(temp2.fail()){
        cout << "Errore nell'apertura di" << argv[2] << endl;
        temp1.close();
        exit(2);
    }

    float t1, t2;
    int t1maggt2 = 0;
    int totTemps = 0;
    while(temp1 >> t1 && temp2 >> t2){
        totTemps++;
        if(t1 > t2) t1maggt2++;
    }

    if(totTemps==0){
        cout << "Impossibile calcolare la percentuale, i file sono vuoti." << endl;
    } else {

        float perc = Percentuale(t1maggt2, totTemps);
        cout << "La percentuale di misurazioni in cui la temperatura del motore1 ha superato quella del motore2 e' del " << perc << "%" << endl;

    }

    temp1.close();
    temp2.close();

}


float Percentuale(int t1maggt2, int totTemps){
    return ((t1maggt2*100)/totTemps);
}