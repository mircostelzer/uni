#include <iostream>
#include <fstream>

// Inserire qui sotto la soluzione all'esercizio

using namespace std;

// MR: doveva chiamarsi Percentuale e non percentuale!
int percentuale(int n_sup, int n_volte);

int main(int argc, char* argv[]) {
    if (argc != 3) {
        cout << "Usage: leggere <./a.out> <input_file> " << endl;
        return -1;
    }
    fstream input, input2;
    input.open(argv[1], ios::in);
    if (input.fail()){
        cout << "Il file dato in input " << argv[1] << " non esiste!" << endl;
    }

    input2.open(argv[2], ios::in);
    if (input.fail()){
        cout << "Il file dato in input " << argv[1] << " non esiste!" << endl;
    }

    char buffer[256];
    char buffer2[256];
    int n_sup = 0;
    int n_volte = 0;
    int n_volte2 = 0;
    int i = 0;

    // MR: cosi' non funziona! Deve leggere il file e non contare le righe!
    while(input.getline(buffer,256)) { // MR: getline definita in string e non consentita!
        n_volte++;
    }

    while(input2.getline(buffer2,256)){
        n_volte2++;
    }


    if(n_volte == 0 || n_volte2 == 0){
        cout << "il numero delle misurazioni è uguale a 0, per questo non posso calcolare la percentuale" << endl;
    }

    cout << endl;
    input.close();
    input2.close();
    return 0; // MR: il programma di fatto indipendentemente termina qui!

    cout << "La percentuale di misurazioni in cui la temperatura del motore 1 supera quella del motore 2 è: " << percentuale(n_sup, n_volte) << endl;
}

int percentuale(int n_sup, int n_volte){
    int perc = 0;
    perc = (n_sup/n_volte)*100;
    return perc;
}