#include <iostream>
#include <fstream>

using namespace std;

float Percentuale(int superato, int misurazioni)
{
    return ((float)superato/misurazioni) * 100;
}

int main(int argn, char **args)
{
    bool vuoto = true; //per controllare se i file sono vuoti
    if(argn != 3)
    {
        cout << "uso corretto: ./a.out temperatura1.txt temperatura2.txt\n";
        return 0;
    }
    fstream temp1, temp2;
    temp1.open(args[1], ios::in);
    temp2.open(args[2], ios::in);
    if(temp1.fail())
    {
        cout << "problemi nell'aprire file temperatura1.txt\n";
        return 0;
    }
    if(temp2.fail())
    {
        cout << "problemi nell'aprire file temperatura2.txt\n";
        return 0;
    }
    string t1, t2; // MR: string non e' tra i tipi consentiti come ripetuttamente specificato a lezione!
    int i = 0, j = 0;
    while(getline(temp1, t1) && getline(temp2, t2)) 
    {
        vuoto = false;
        //cout << t1 << " " << t2 << endl;
        j++;
        if (t1 > t2) // MR: qui confronta stringhe non valori interi/double!
            i++;
    }
    //cout << i << j
    if(vuoto)
        cout << "Il numero delle misurazioni e' uguale a zero, per cui non posso calcolare la percentuale\n";
    else
        cout << "La percentuale di misurazioni in cui la temperatura del motore1 ha superato quella del motore2 e' del " << Percentuale(i, j) << "%.\n";
    temp1.close();
    temp2.close();
}