#include <iostream>
#include <fstream>

// Inserire qui sotto la soluzione all'esercizio

using namespace std;

float Percentuale(int sup, int tot);

int main(int argc, char** argv){

    if (argc != 3) {
    cerr << "Usage: ./a.out <motore1.txt> <motore2.txt>" << endl;
    exit(1);
    }

    fstream motore1, motore2;
    motore1.open(argv[1], ios::in);
    motore2.open(argv[2], ios::in);

    if (motore1.fail() || motore2.fail()) {
        cerr << "Errore nell'apertura dei file" << endl;
        cout << "Il numero delle misurazioni e' uguale a zero,\nper cui non posso calcolare la percentuale" << endl;
        exit(1);
    }

    int misurazioni = 0;
    int maggiore = 0;

    int temp1 = 0;
    int temp2 = 0;

    while (!motore1.eof() || !motore2.eof()) // MR: eof diventa vero solo dopo una letturea.. quindi potrebbe leggere valori sbagliati.
    { // MR: legge una volta di troppo e valori sbagliati...
        motore2 >> temp2;
        motore1 >> temp1;
        if (temp2 > temp1) maggiore+=1;
        misurazioni++;
    }
    motore1.close();
    motore2.close();
    double res = Percentuale(maggiore, misurazioni);
    if (res != 0)
        cout << "La percentuale di misurazioni in cui la temperatura del motore2\nha superato quella del motore1 e' del " << res << "%" << endl;
    else 
        cout << "Il numero delle misurazioni e' uguale a zero,\nper cui non posso calcolare la percentuale" << endl;
    return 0;
}

float Percentuale(int sup, int tot){
    float perc = (sup*100)/tot;
    return perc;
}