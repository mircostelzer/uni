#include <iostream>
#include <fstream>

using namespace std;

// MR: doveva chiamarsi Percentuale e non percentuale!
double percentuale(double numero_volte, double numero_misurazioni);

// Inserire qui sotto la soluzione all'esercizio
int main(int argc, char const *argv[])
{
    // Controllo se gli argomenti sono corretti
    if (argc != 3)
    {
        cout << "Usage: esercizio1 <motore_1> <motore_2>" << endl;
        exit(1);
    }

    fstream motore_1, motore_2;
    motore_1.open(argv[1], ios::in);
    motore_2.open(argv[2], ios::in);

    // Controllo di essere riuscito ad aprire i file correttamente
    if (motore_1.fail() || motore_2.fail())
    {
        cout << "Errore nell'apertura dei file" << endl;
        exit(1);
    }
    
    double numero_volte = 0; 
    double numero_misurazioni = 0; 

    int buffer_1; // MR: non specificato che temperature sono interi!
    int buffer_2; 

    // lettura in contemporanea di entrambi i file
    // verificando le condizioni imposte all'interno della 
    // consegna
    while (motore_1 >> buffer_1 && motore_2 >> buffer_2) 
    {
        if (buffer_1 > buffer_2)
        {
            numero_volte++; 
        }
        numero_misurazioni++;
    }
    
    double percentuale_motore = percentuale(numero_volte,numero_misurazioni);

    // stampa della percentuale con la formattazione richiesta
    if (numero_misurazioni != 0)
    {
        cout << "La percentuale di misurazioni in cui la temperatura del motore1 ha superato quella del motore2 e' del: " << percentuale_motore*100 << "%" << endl;
    }else{
        cout << "Il numero delle misurazioni e' uguale a zero, per cui non posso calcolare la percentuale" << endl;
    }
    

    // chiusura degli stream
    motore_1.close(); 
    motore_2.close();

    return 0;
}


double percentuale(double numero_volte, double numero_misurazioni){
    double ris = 0.0; 
    if (numero_misurazioni != 0)
    {
        ris = numero_volte/numero_misurazioni;
    }
    return ris;
}