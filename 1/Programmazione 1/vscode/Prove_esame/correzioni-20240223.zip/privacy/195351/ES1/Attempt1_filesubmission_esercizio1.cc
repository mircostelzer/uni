#include <iostream>
#include <fstream>

using namespace std;

int main(int argc, char* argv[])
{
    fstream input1,input2;
    if (argc!=3) {
        cerr << "Usage: ./a.out <temperature1> <temperature2> \n";
        exit(0);
    }
    input1.open(argv[1],ios::in);
    if (input1.fail()) {
        cerr << "Il file " << argv[1] << " non esiste\n";
        exit(0);
    }
    input2.open(argv[2],ios::in);
    if (input2.fail()) {
        cerr << "Il file " << argv[2] << " non esiste\n";
        exit(0);
    }
  
  // MR: Da nessuna parte era specificato che le misurazioni erano 10

  float temperatura1[10]={0};
  float temperatura2[10]={0};
  /////////////////////////////////////
  int i=0;
  int arrSize=0;
  char buffer[256];
  while(input1>>buffer)
  {
    // MR: se ci sono piu' di 10 misurazioni scrive out pf bound degli array!
    // MR: poteva fare a meno di usare atof, in quanto definito in cstdlib e quindi non consentita
    temperatura1[i]=atof(buffer);
    arrSize++; 
    i++;
  }
  ///////////////////////////////////
  int j=0;
  input2 >> buffer;
  while(!input2.eof())
  {
    // MR: se ci sono piu' di 10 misurazioni scrive out pf bound degli array!
    // MR: poteva fare a meno di usare atof, in quanto definito in cstdlib e quindi non consentita
    temperatura2[j]=atof(buffer);
    input2 >> buffer;
    j++;
  }
  /////////////////////////////////////
  int count=0;
  // MR: cosa succede se temperatura1 e temperatura2 hanno lunghezze diverse?, 
  // MR: in particolare se temperatura2 ha meno elementi di temperatura1?
  for (int k=0;k<arrSize;k++){
    if(temperatura1[k]>temperatura2[k]){
        count++;
    }
  }
  if(count==0){
    cout<<"Il numero delle misurazioni e' uguale a zero, per cui non posso calcolare la percentuale"<<endl;
  }
  else{
    cout<<"La percentuale di misurazioni in cui la temperatura del motore1 ha superato quella del motore2 e' del "<< (float(count)/float(arrSize))*100.00 <<"%"<<endl;
  }


  input1.close();
  input2.close();

  return 0;
}