#include <iostream>
#include <fstream>
using namespace std;

// Inserire qui sotto la soluzione all'esercizio

float Percentuale(float superato, float totale);

int main(int argc, char * argv[]){

    //Controllo che il numero degli argomenti sia quello richiesto
    if(argc != 3){
        cout << "Argomenti errati!" << endl;
        exit(EXIT_FAILURE);
    }

    //Apro i due file in input
    ifstream in1;
    ifstream in2;
    in1.open(argv[1], ios::in);
    in2.open(argv[2], ios::in);

    if(in1.fail() || in2.fail()){
        cout << "Errore nell'aprire uno dei file" << endl;
        exit(EXIT_FAILURE);
    }

    int temp1, temp2;
    float superato = 0, totale = 0;

    //conto le occorrenze finchè uno dei due non finisce i valori
    while(in1>>temp1 && in2>>temp2){
        totale++;
        if(temp2>temp1){
            superato++;
        }
    }

    //Se ci sono misurazioni calcolo la percentuale e la stampo, se non ci sono stampo in output l'errore
    if(totale != 0){
        float perc = Percentuale(superato, totale);
        cout << "La percentuale di misurazioni in cui la temperatura del motore2" << endl
            << "ha superato quella del motore1 è del: " << perc << "%."<<endl;
    }else{
        cout << "Il numero delle misurazione e' uguale a zero," << endl
            << "per cui non posso calcolare la percentuale" << endl;
    }

    return 0;
}

float Percentuale(float superato, float totale){
    float perc = (superato/totale)*100;

    return perc;
}