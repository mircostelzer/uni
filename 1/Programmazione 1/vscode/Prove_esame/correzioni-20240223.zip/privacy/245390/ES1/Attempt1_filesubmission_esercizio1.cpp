#include <iostream>
#include <fstream>

// Inserire qui sotto la soluzione all'esercizio
using namespace std;
double Percentuale(int misurazioni,int superato);
int main(int argc,char* argv[])
{
    if(argc!=3)
    {
        cout << "argomenti errati";
        return 0;
    }
    fstream motore1,motore2;
    motore1.open(argv[1],ios::in);
    motore2.open(argv[2],ios::in);

    if(motore1.fail() || motore2.fail())
    {
        return 0;
    }
    int m1; // MR: non era specificato che fossero interi
    int m2;
    int misurazioni=0;
    int superato=0;
    while(motore1>>m1 && motore2>>m2)
    {
        if(m2>m1)
        {
            superato++;
        }
        misurazioni++;
    }
    // MR: manca controllo misurazioni != 0 e stampa relativa1
    cout<< "La percentuale di misurazioni in cui la temperatura del motore1 ha superato quella del motore2 e del " << Percentuale(misurazioni,superato)<<"%";
    motore1.close();
    motore2.close();
}

double Percentuale(int misurazioni,int superato)
{
    if(misurazioni==0)
    {  // MR: la stampa doveva essere fuori dalla funzione!
        cout<<"Impossibile calcolare la percentuale";
        return 0;
    }
    double percento;
    percento=(double)(superato*100)/misurazioni;
    return percento;
}
