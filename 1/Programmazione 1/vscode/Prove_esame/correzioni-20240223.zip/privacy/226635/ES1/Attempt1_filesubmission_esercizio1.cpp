#include <iostream>
#include <fstream>

double Percentuale(double superiore, double misurazioni);

int main(int argc, char * argv []) {
  
  if(argc != 3){
    // MR: e' C o C++? Se C++ allora usare std::out!!
    printf("Usage %s <inputFile1> <inputFile2>\n", argv[0]);
    exit(0);
  }

  std::fstream fin1, fin2;

  fin1.open(argv[1], std::ios::in);
  fin2.open(argv[2], std::ios::in);

  if (fin1.fail() || fin2.fail()) {
      std::cout << "Errore nell'apertura dei file";
      exit(1);
  }
  // MR: non era specificato che le temperature erano interi!
  int t1=0, t2=0, superiore=0, misurazioni=0;

  while(fin1>>t1 && fin2>>t2){
    misurazioni++;
    if(t1>t2){
        superiore++;
    }
  }

  if(misurazioni == 0){
    std::cout << "Il numero delle misurazioni e' uguale a zero, per cui non posso calcolare la percentuale" << std::endl;
  }
  else{
    std::cout << "La percentuale di misurazioni in cui la temperatura del motore1 ha superato quella del motore2 e' del " << Percentuale(superiore, misurazioni) << "%." << std::endl;
  }

  fin1.close();
  fin2.close();

  return 0;

}

double Percentuale(double superiore, double misurazioni){
    return (superiore/misurazioni)*100.0;
}