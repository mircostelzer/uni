#include <iostream>
#include <fstream>

using namespace std;

// MR: Doveva chiamarsi Percentuale e non percentuale!
double percentuale(int &tot, int &maggiore);

int main(int argc, char **argv){
    if(argc == 3){
        fstream m1, m2;
        m1.open(argv[1], ios::in); 
        m2.open(argv[2], ios::in);

        if(m1.fail() && m2.fail()){
            cout << "Non è stato possibile aprire i file" << endl;
        }

        int tot = 0;
        int maggiore = 0; //conta le volte in cui motore2 > motore1

        char temp1[16];
        char temp2[16];

        while(m1 >> temp1 && m2 >> temp2){
            // MR: atof definito in cstdlib e non consentito!
            if(atof(temp2) > atof(temp1)) maggiore++;
            tot++;
        }

        if(tot > 0){
            cout << "La percentuale di misurazioni in cui la temperatura del motore2 ha superato quella del motore1 e' del " << percentuale(tot, maggiore) << "%" << endl;
        }
        else{
            cout << "Il numero delle misurazioni e' uguale a zero, per cui non posso calcolare la percentuale" << endl;
        }

        m1.close();
        m2.close();
    }
	
    return 0;
}

double percentuale(int &tot, int &maggiore){
    double perc = maggiore / (double)tot * 100;
    return perc;
}