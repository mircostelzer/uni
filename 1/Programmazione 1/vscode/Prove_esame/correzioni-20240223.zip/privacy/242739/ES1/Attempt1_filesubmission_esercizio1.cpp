#include <iostream>
#include <fstream>

using namespace std;

double Percentuale(int countM1GreaterThanM2, int totalCount) {
    return ((double)countM1GreaterThanM2 / (double)totalCount)*100;
}

int main(int argc, char** argv) {
    // Lettura dei due file da command line
    if (argc != 3) {
        cout << "Usage: " << argv[0] << " <path/file_motore_1> <path/file_motore_2>" << endl;
        exit(1);
    }

    ifstream inm1(argv[1]);
    ifstream inm2(argv[2]);

    // Controllo di apertura del primo file
    if (!inm1.is_open()) {
        cout << "Error opening file 1" << endl;
        inm1.close();
        inm2.close();
        exit(1);
    }

    // Controllo di apertura del secondo file
    if (!inm2.is_open()) {
        cout << "Error opening file 2" << endl;
        inm1.close();
        inm2.close();
        exit(1);
    }

    // Lettura delle temperature dai due file
    int count = 0;
    int countm1 = 0;
    double temp1 = 0.0;
    double temp2 = 0.0;
    while (inm1 >> temp1 && inm2 >> temp2) {
        //cout << temp1 << " " << temp2 << endl;
        if (temp1 > temp2) {
            countm1++;
        }
        count++;
    }

    if (count == 0) {
        cout << "Il numero delle misurazioni e' uguale a zero,\nper cui non posso calcolare la percentuale" << endl;
    } else {
        cout << "La percentuale di misurazioni in cui la temperatura del motore1\nha superato quella del motore2 e' del " << Percentuale(countm1, count) << "%." << endl;
    }

    // Chiudiamo i file di input
    inm1.close();
    inm2.close();

    return 0;
}