#include <iostream>
#include <cstdlib>

// Non modificare questa parte sotto del codice
typedef struct Stack {
    int data;
    struct Stack * next;
} Stack;

struct Stack * initStack() {
    return nullptr;
}

Stack *stackOperator(Stack *pStack);

bool isEmpty(struct Stack * s) {
    return (s == nullptr);
}

void push(struct Stack * &s, int value) {
    struct Stack * newElement = new Stack;
    newElement->data = value;
    newElement->next = s;
    s = newElement;
}

int top(struct Stack * s) {
    if (isEmpty(s)) {
        std::cerr << "Error: stack is empty" << std::endl;
        exit(1);
    }
    return s->data;
}

int pop(struct Stack * &s) {
    if (isEmpty(s)) {
        std::cerr << "Error: stack is empty" << std::endl;
        exit(1);
    }
    int value = s->data;
    struct Stack * temp = s;
    s = s->next;
    delete temp;
    return value;
}

void deleteStack(struct Stack * &s) {
    while (!isEmpty(s)) {
        pop(s);
    }
}

void printStack(struct Stack * s, const char * message = "Stack: ") {
    if (isEmpty(s)) {
        std::cout << "Stack is empty" << std::endl;
    } else {
        std::cout << message;
        struct Stack * temp = s;
        while (temp != nullptr) {
            std::cout << temp->data << " ";
            temp = temp->next;
        }
        std::cout << std::endl;
    }
}
// Non modificare questa parte sopra del codice

// Inserire qui sotto la dichiarazione della funzione stackOperator
Stack *stackOperator(Stack *pStack);
// Inserire qui sopra la dichiarazione della funzione stackOperator

int main() {
    struct Stack *s, *result;
    unsigned int seed = (unsigned int)time(NULL);
    // seed = 60000
    seed = 1697033220;
    srand(seed);

    s = initStack();
    for (int i = 0; i < 5; i++) {
        if (i != 2) push(s, 5-i);
    }
    printStack(s, "Original before: ");
    result = stackOperator(s);
    printStack(result, "Result StackOperator: ");
    printStack(s, "Original after: ");
    deleteStack(s);
    deleteStack(result);

    s = initStack();
    for (int i = 0; i < 10; i++) {
        push(s, rand() % 100);
    }
    printStack(s, "Original before: ");
    result = stackOperator(s);
    printStack(result, "Result StackOperator: ");
    printStack(s, "Original after: ");
    deleteStack(s);
    deleteStack(result);

    return 0;
}

// Inserire qui sotto la definizione della funzione stackOperator
void RecursiveOperatorStackAux(Stack *& S, int & count) {
    if (isEmpty(S))
        return;

    int val = top(S);
    count++;
    pop(S);

    RecursiveOperatorStackAux(S, count);
    push(S, val);
}

Stack *stackOperator(Stack * s) {
    int count = 0;
    RecursiveOperatorStackAux(s, count);
    //std::cout << count << std::endl;

    struct Stack * t;
    t = initStack();

    int lastSum = 0;
    int size = count;
    while (size > 0) {
        for (int i = 0; i < size-1; ++i) { // MR: non capisco la logica di questo ciclo
            int temp = top(s);
            if (i == count-size) {
                lastSum += temp;
            }
            pop(s);
            push(t, temp);
        }

        int last = top(s);
        //pop(s);
        //push(s);
        // MR: la somma e ricostruzione sono errate ed arbitrariamente complicate, non riesco a capire la logica!
        for (int i = 0; i < size-1; ++i) { // MR: non capisco la logica di questo ciclo, se deve estrarrre tutti gli elementi della lista originale lo fa in modo errato!
            int temp = top(t);
            pop(t);
            push(s, temp);
        }

        //lastSum += last;

        push(t, lastSum);
        push(t, last);

        size--;
    }


    return t;
}
// Inserire qui sopra la definizione della funzione stackOperator
