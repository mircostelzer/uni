#include <iostream>
#include <fstream>


using namespace std;
// Inserire qui sotto la soluzione all'esercizio
float Percentuale(int m1_higher, int n_misurazioni){
    return ((float) m1_higher/ n_misurazioni)*100;
}

int main(int argc, char* argv[]){

    if(argc < 2){
        cerr << "numero di argomenti non valido" << endl;
        cout << "la sintassi è: ./a.out <nome_file_mot_1> <nome_file_mot_2>" << endl;
    }

    fstream in_motore_1, in_motore_2;                                            
    in_motore_1.open(argv[1],ios::in);                                   
    in_motore_2.open(argv[2],ios::in); 

    if(in_motore_1.fail() ){
        cerr << "numero di argomenti non valido" << endl;
    }
    // MR: manca il controllo su in_motore_2.fail()

    char str_mot_1 [1024];
    char str_mot_2 [1024];
    
    int n_misurazioni = 0;
    int m1_higher = 0;

    float m1 = 0;
    float m2 = 0;

    while(!in_motore_1.eof()){
        in_motore_1.getline(str_mot_1, 1024); // MR: getline fa parte di string
        in_motore_2.getline(str_mot_2, 1024);
        
        m1 = atof(str_mot_1); // MR: atof fa parte di cstdlib non consentito
        m2 = atof(str_mot_2);
        
        if(m1 > m2 ){
            m1_higher++;
        }

        if(m1 != 0 && m2 != 0){ // MR: perche' controllo non anche sopra quando confronta m1 e m2?
            n_misurazioni++;    
        }
    }


    if(n_misurazioni == 0){
        cout << "Il numero delle misurazioni e' uguale a zero, per cui non posso calcolare la percentuale" << endl;
        exit(0);
    }

    // MR: l'outout non e' conforme a quanto richiesto
    float percentuale = Percentuale(m1_higher, n_misurazioni);

    cout << "il motore 1 ha superato motore 2 di " << percentuale << "%" << endl;

    in_motore_1.close();
    in_motore_2.close();

    return 0;
}