#include <iostream>
#include <fstream>

using namespace std;

// MR: doveva ritornare un double/float non un int!
int Percentuale(int a, int b){
    return (double)a/(double)b*(double)100;
}

int main(int argc, char **argv)
{
    if (argc < 3)
    {
        cerr << "Usage: ./a.out temperatura1.txt temperatura2.txt" << endl;
        exit(0);
    }

    fstream input1, input2;

    input1.open(argv[1], ios::in);
    input2.open(argv[2], ios::in); // ios::app

    if (input1.fail())
    {
        cout << "cant open temperatura1.txt" << endl;
        exit(0);
    }

    if (input2.fail())
    {
        cout << "cant open temperatura2.txt" << endl;
        exit(0);
    }

    double temp1=0, temp2=0;
    int t2maggioret1=0, tot=0;
    while (input1>>temp1 && input2>>temp2)
    {
        tot++;
        if(temp2>temp1){
            t2maggioret1++;
        }
    }

    if(tot>0){
        cout<<"La percentuale di misurazioni in cui la temperatura del motore2\n"
              "ha superato quella del motore1 e' del "<<Percentuale(t2maggioret1, tot)<<"%."<<endl;
    }else{
        cout<<"Il numero delle misurazioni e' uguale a zero,\n"
              "per cui non posso calcolare la percentuale\n";
    }



    input1.close();
    input2.close();
}