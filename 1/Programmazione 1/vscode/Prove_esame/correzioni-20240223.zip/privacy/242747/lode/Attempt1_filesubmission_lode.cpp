#include <iostream>
#include <ctime>
#include <cstdlib>

void print_array(int arr[], int size, int N, bool modulo = false) {
    for (int i = 0; i < size; i++) {
        std::cout << (modulo ? arr[i] % N : arr[i]) << " ";
    }
    std::cout << std::endl;
}

void swap(int & a, int & b) {
    int tmp = a;
    a = b;
    b = tmp;
}

// scrivere la dichiarazione della funzione calcola qui sotto
void calcola(int *arr, int size, int N);

// scrivere la dichiarazione della funzione calcola qui sopra


int main() {
    int N;
    const int size = 10;
    int * arr = new int [size];
    unsigned int seed = time(0);
    // commentare riga sotto per comportamento randomico
    seed = 1708114916;
    std::cout << "Seed: " << seed << std::endl;
    srand(seed);
    N = rand() % 100;
    for (int i = 0; i < size; i++) {
        arr[i] = rand() % 1000;
    }
    std::cout << "N = " << N << std::endl;
    std::cout << "Array unordered: " << std::endl;
    print_array(arr, size, N);
    std::cout << "Array unordered (modulo): " << std::endl;
    print_array(arr, size, N, true);
    calcola(arr, size, N);
    std::cout << "Array ordered: " << std::endl;
    print_array(arr, size, N);
    std::cout << "Array ordered (modulo): " << std::endl;
    print_array(arr, size, N, true);
    delete [] arr;
    return 0;
}

// scrivere la definizione della funzione calcola qui sotto
// Osservazione: l'ordinamento si puo' farlo in O(N) che e' minore di O((N - 2)log n)
// dimostrazione: Se creiamo una matrice mat[N][n] (si puo' ottimizzare in memoria facendo una lista)
// in mat[i] ci salviamo un array dove l'elemento v appartiene a mat[i] <==> mat[i] % N == i
// Per ordinarlo basta scorrere le liste in maniera crescente --> la time complexity e' data dallo scorrere ogni i, che sarebbe la classe di resto
// e scorrere i singoli elementi di ogni riga della matrice 
// In tutto abbiamo N classi di resto (0 a N - 1)
// gli elementi che andiamo a scorrere in tutto sono n visto che abbiamo un array di n elementi
// quindi alla fine abbiamo O(N + n) = O(N)

// altrimenti si puo' optare per una merge sort facendo un "ovveride" del compare to

using namespace std;
void calcola(int *arr, int size, int N) {
    int mat[N][size];
    int dim[N];

    for (int i = 0; i < N; ++i) {
        dim[i] = 0;
    }    

    for (int i = 0; i < size; ++i) {
        int resto = arr[i] % N;
        mat[resto][dim[resto]] = i;
        ++dim[resto];
    }

    // unisco il tutto
    int j = 0;
    // MR: non era richiesto di modificare i valori di arr, solo di ordinarlo!
    for (int resto = 0; resto < N; ++resto) {
        for (int i = 0; i < dim[resto]; ++i) { // sum degli dim[resto] forall resto = n = size
            arr[j++] = resto;
        }
    }
}

// scrivere la definizione della funzione calcola qui sopra
