#include <iostream>
#include <fstream>

using namespace std;

double Percentuale(int cnt, int tot) {
    return (double(cnt) / tot) * 100;
}

int main(int argc, char const *argv[]) {
    if (argc != 3) {
        cout << "Devi passare due argomenti" << endl;
        return 1;
    }

    fstream read1(argv[1], ios::in);
    fstream read2(argv[2], ios::in);

    if (read1.fail() || read2.fail()) {
        cout << "Errore nell'apertura dei file" << endl;
        return 1;
    }

    double num1, num2;
    bool ok = true;
    int cnt = 0, tot = 0;
    while (read1 >> num1 && read2 >> num2) { // leggo i valori
        if (num1 > num2) {
            cnt++;
        }
        ++tot;
    }

    // coprire il caso in cui il file e' vuoto --> crea problemi nella divisione
    if (tot == 0) {
        cout << "Il numero delle misurazioni e' uguale a zero, per cui non posso calcolare la percentuale" << endl;
    } else {
        cout << "La percentuale di misurazioni in cui la temperatura del motore1 ha superato quella del motore2 e' del " << Percentuale(cnt, tot) << "%" << endl;
    }
    return 0;
}
