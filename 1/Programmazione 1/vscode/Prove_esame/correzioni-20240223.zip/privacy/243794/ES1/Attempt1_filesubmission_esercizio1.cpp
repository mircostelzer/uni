
#include <iostream>
#include <fstream>

// Inserire qui sotto la soluzione all'esercizio
using namespace std;

float Percentuale(int volteMaggiore,int nMisurazioni){
    if(nMisurazioni <= 0){
        cout<<"Il numero di misurazioni non puo' essere neagtivo o zero"<<endl;
        return -1;
    }else{
        return ((volteMaggiore*1.0)/nMisurazioni)*100;
    }
}

int main(int argc,char* argv[]){
    if(argc != 3){
        cout<<"Numero di apramentri insufficienti "<<endl;
        exit(1);
    }
    ifstream motore1;
    ifstream motore2;
    motore1.open(argv[1]);
    motore2.open(argv[2]);
    int tmp1,tmp2; // MR: non e' specificato che le temperature sono interi!
    int maggiori = 0;
    int conta = 0;
    if(!motore1.is_open() || !motore2.is_open()){
        cout<<"I file non si sono aperti"<<endl;
    }else{
    while(!motore1.eof() && !motore2.eof() && !motore1.fail() && !motore2.fail()){ // MR: in questo modo legge una volta di troppo, perche' i flag sono messi solo dopo lettura.
        motore1>>tmp1;
        motore2>>tmp2;
        cout<<tmp1<<endl;
        cout<<tmp2<<endl;
        conta++;
        if(tmp1 > tmp2){
            maggiori++;
        }
    }
    if(conta == 0){
        cout<<"Il numero delle misurazioni e' uguale a zero,"<<endl;
        cout<<"per cui non posso calcolare la percentuale"<<endl;
    }else{
        float percentuale;
        percentuale = Percentuale(maggiori,conta);
        cout<<"La percentuale di misurazioni in cui la temperatura del motore1"<<endl;
        cout<<"ha superato quella del motore2 e' del "<<percentuale<<"%."<<endl;
    }

    }
    motore1.close();
    motore2.close();
    return 0;
}