#include <iostream>
#include <fstream>
using namespace std;

float Percentuale(int count, int total);

int convertToInt(char a[1000]){
    int i = 0;
    int num = 0;
    while (a[i] != 0)
    {
        num =  (a[i] - '0')  + (num * 10);
        i++;
    }
    return num;;
}

int main(int argc,char * argv[]) {
    fstream temperature1, temperature2;
    temperature1.open(argv[1],ios::in);
    temperature2.open(argv[2],ios::in);

    if(argc!=3) {
        cerr << "Usage: ./a.out 1stfile.txt 2ndfile.txt" << endl;
        exit(1);
    }
    if(temperature1.fail()) {
        cout << "Impossibile aprire " << argv[1] << endl;
        exit(1);
    }
    if(temperature2.fail()) {
        cout << "Impossibile aprire " << argv[2] << endl;
        exit(1);
    }

    char b1[3]; // MR: NON ERA SPECIFICATO CHE CI FOSSERO SOLO 2 CIFRE e CHE FOSSERO INTERI!
    char b2[3];
    int total = 0.0;
    int count = 0.0;

    while(temperature1 >> b1 && temperature2 >> b2) { // MR: se temperatura e' piu' lunga di 2 cifre cosa succede?
        total++;
        if(convertToInt(b1) < convertToInt(b2)) {
            count++;
        }
    }

   
    if(total == 0) {
        cout << "Il numero delle misurazioni e' uguale a zero, per cui non posso calcolare la percentuale" << endl;
    } else {
    cout << "La percentuale di misurazioni in cui la temperatura del motore2 ha superato quella del motore1 e' del " << Percentuale(count,total) << "%." << endl;
    }


    
    



    temperature1.close();
    temperature2.close();
    return 0;
}

float Percentuale(int count, int total) {
    if(total == 0) {
        return 0;
    } else {
        float res = 0;
        res = ((float)count / (float)total);
        res *= 100;
        return res;
    }
}