#include <iostream>
#include <fstream>  

using namespace std;

int Percentuale(int n, int dim);

int main(int argc, char* argv[]) 
{
    if(argc < 3) 
    {
        cout << "Errore --> ./a.out <input1> <input2>" << endl; 
        exit(1);
    }

    fstream in, in2;

    in.open(argv[1], ios::in);

    if (in.fail())
    {
        cout << "Errore --> Si è verificato un errore nell'apertura del file: " << argv[1] << endl; 
        exit(1);
    }

    in2.open(argv[2], ios::in);

    if (in2.fail())
    {
        cout << "Errore --> Si è verificato un errore nell'apertura del file: " << argv[2] << endl; 
        exit(1);
    }
    
    int valore1 = 0;
    int valore2 = 0;

    int cont = 0;
    int numeroMaggiore = 0;

    while(in >> valore1)
    {
        in2 >> valore2; // MR: cosa succede se il secondo file ha meno righe del primo? Va in EOF e non controlla!
        if (valore1 > valore2)
        {
            numeroMaggiore++;
        }
        cont++;
    }
    
    // MR: outptut su stdout NON su file!
    fstream out;

    out.open("Output.txt", ios::out);

    if (out.fail())
    {
        cout << "Errore --> Si è verificato un errore nell'apertura del file: " << "Output.txt" << endl; 
        exit(1);
    }

    if(cont == 0)
    {
        out << "Non posso calcolare la percentuale perchè non ci sono valori" << endl;
    }
    else
    {
        out << "La percentuale di misurazioni in cui la temperatura del motore1 ha superato quella del motore2 e' del " << Percentuale(numeroMaggiore, cont) << " %" << endl;
    }

    in.close();
    in2.close();
    out.close();
    return 0;
}

int Percentuale(int n, int dim)
{   
    if (dim != 0)
    {
        return 100/dim * n;
    }
    return 0;
}