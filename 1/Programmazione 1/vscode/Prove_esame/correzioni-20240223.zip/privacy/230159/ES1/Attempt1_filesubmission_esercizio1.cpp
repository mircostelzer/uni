#include <iostream>
#include <fstream>

using namespace std;

float Percentuale (int volte, int tot){
    // MR: volte era meglio convertirlo in float, altrimenti la divisione sara' tra interi!
    float result = (volte*100)/tot;
    return result;

}

int main(int argc, char * argv []) {

  // Controllo che gli argomenti ci siano tutti
  if (argc != 3) {
    cout << "Usage: ./a.out <file1> <file2>" << endl;
    exit(1);
  }

  // Apro gli stream di lettura e scrittura
  fstream input1, input2;
  input1.open(argv[1], ios::in);
  input2.open(argv[2], ios::in);

  // Controllo che gli stream siano stati aperti correttamente
  if (input1.fail() || input2.fail()) {
    cout << "Errore nell'apertura degli stream!" << endl;
    input1.close();
    input2.close();
  }

  int num; // MR: non specificato che i numeri fossero interi!
  int num2;
  int volte = 0;
  int tot = 0;

  while (input1 >> num && input2 >> num2){
    if (num < num2){
        volte++;
    }
    tot ++;
  }

  if (tot != 0){
    cout << "La percentuale di misurazioni in cui la temperatura del motore2 ha superato quella del motore1 è del " << Percentuale(volte , tot) <<"% \n";
  } else {
    cout << "Il numero delle misurazioni è uguale a zero, per cui non posso calcolare la percentuale" << endl;
    }
  return 0;
}
