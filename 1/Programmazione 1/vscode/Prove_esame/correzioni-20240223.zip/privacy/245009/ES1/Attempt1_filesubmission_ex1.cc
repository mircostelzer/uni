#include <iostream>
#include <fstream>

using namespace std;

// MR: doveva ritornare un float e non un int!
int percentuale(int max, int tot);

int main(int argc, char const *argv[])
{
    if (argc != 3)
    {
        cout << "Usage: exercise1.out <input> <output>" << endl;
        exit(1);
    }

    // Apro gli stream di lettura e scrittura
    fstream input1, input2;
    input1.open(argv[1], ios::in);
    input2.open(argv[2], ios::in);

    // Controllo che gli stream siano stati aperti correttamente
    if (input1.fail() || input2.fail())
    {
        cout << "Errore nell'apertura degli stream!" << endl;
    }

    char buffer[10];
    int max = 0;
    int tot = 0;

    while (input1 >> buffer)
    {
        int t1 = stoi(buffer); // MR: definita in string e non consentita
        input2 >> buffer; // MR: cosa succede se il primo file contiene piu' elementi del primo?? Manca controllo!
        int t2 = stoi(buffer);

        if (t2 > t1)
        {
            max++;
        }
        tot++;
    }

    int ris = percentuale(max, tot);

    if (ris != -1)
    {
        cout << "La percentuale di misurazioni in cui la temperatura del motore1 ha superato quella del motore2 e' del" << ris << "%.";
    }
    else
    {
        cout << "Il numero delle misurazioni e' uguale a zero, per cui non posso calcolare la percentuale.";
    }

    cout << endl;

    input1.close();
    input2.close();

    return 0;
}

int percentuale(int max, int tot)
{
    if (max != 0)
    {
        return (max * 100) / tot;
    }

    return -1;
}
