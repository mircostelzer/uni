#include <iostream>
#include <fstream>
using namespace std;

float Percentuale(float temp1, float tot);

// Inserire qui sotto la soluzione all'esercizio
int main(int argc, char * argv[])
{
    if(argc!=3)
    {
        cout << "Errore nell'inserimento dei file";
        exit(0);
    }
    fstream temp1, temp2;
    temp1.open(argv[1], ios::in);
    temp2.open(argv[2], ios::in);
    if(temp1.fail() || temp2.fail())
    {
        cout << "Errore nell'apertura dei file";
        exit(0);
    }
    int misura1=0;
    int misura2=0;
    float max2=0;
    float tot=0;
    while(temp1>>misura1, temp2>>misura2)
    {
    //temp2>>misura2;
        if(misura2>misura1)
        {
            max2++;
        }
        tot++;
    }
    
    cout << max2 << " " << tot << endl;
    if(max2==0) // MR: se tot == 0, altrimenti fa divisione per 0!
    {
        cout << "Il numero delle misurazioni e' uguale a zero, per cui non posso calcolare la percentuale" << endl;
    }
    else
    {
        float result=Percentuale(max2, tot);
        cout << "La percentuale di volte in cui la temp del motore 2 ha superato quella del motore 1 è: "<<result << "%" <<endl;

    }
    temp1.close();
    temp2.close();
    return 0;
}

float Percentuale(float temp1, float tot)
{
    float res=(temp1/tot)*100;
    return res;
}