#include <iostream>
#include <fstream>
using namespace std;

// MR: doveva ritornare un float o un double!
int Percentuale(int n_v, int n);

int main(int argc, char* argv[]){

    fstream t1, t2;
    if(argc!=3){
        return -1;
    }
    t1.open(argv[1], ios::in);
    t2.open(argv[2], ios::in);
    if(t1.fail() || t2.fail()){
        return -2;
    }
    int temp1,temp2, len = 0, cont = 0; // MR: non era specificato che i numeri fossero interi!
    while(t1>>temp1){
        t2>>temp2; // MR: cosa succede se il secondo file contiene meno elementi del primo?? Manca controllo!


        if(temp1<temp2){
            cont++;
        }
        len++;
    }
    // MR: manca controllo che len != 0!!! Quindi in questo caso va in division by 0!
    int p = Percentuale(cont,len);
    if(p==0){ // MR: il controllo e' su len non su p!
        cout<<"Il numero delle misurazioni e' uguale a zero, per cui non posso calcolare la percentuale\n";
    }else{
        cout<<"La percentuale di misurazioni in cui la temperatura del motore1  ha superato quella del motore2 e' del "<<p<<"%.\n";
    }

    t1.close();t2.close();

    return 0;
}

int Percentuale(int n_v, int n){
    return (n_v*100)/n;
}