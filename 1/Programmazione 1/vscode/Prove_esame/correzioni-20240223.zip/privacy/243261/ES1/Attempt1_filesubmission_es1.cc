#include <iostream>
#include <fstream>

using namespace std;

// MR: la funzione doveva ritornare un float o un double!
void Percentuale(int c, int t) {
    // MR: se t == 0 fa divisione per 0!
    double res=(double)c/t;
    res=res*100.0;
    // MR: la stampa doveva essere fatta fuori dalla funzione!
    if (t>0) {
        cout << "La percentuale di misurazioni in cui la temperatura del motore2 ha superato quella del motore1 e dello " << res << "%." << endl;
    } else {
        cout << "Il numero delle misurazioni e uguale a zero, per cui non posso calcolare la percentuale." << endl;
    }
}  

int main(int argc, char * argv []) {
    fstream in1, in2;

    if (argc != 3) {
        cout << "Usage: ./a.out <temperatura1> <temperatura2>" << endl;
        exit(1);
    }

    in1.open(argv[1], ios::in);
    in2.open(argv[2], ios::in);

    if (in1.fail() || in2.fail()) {
        cout << "Errore nella apertura di uno dei due file:"
            << argv[1]  << " - " << argv[2] << endl;
        in1.close();
        in2.close();
        exit(1);
    }
    double testo1;
    double testo2;
    int c=0;
    int t=0;
    while (in1>>testo1) {
        in2 >>testo2; // MR: cosa succede se primo file ha piu' elementi del secondo? Manca controllo!
        double motore1=(double)testo1;
        double motore2=(double)testo2;
        if (motore2>motore1) {
            c++;
        }
        t++;
    }
    Percentuale(c, t);

    in1.close();
    in2.close();
    return 0;
}