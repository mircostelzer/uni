#include <iostream>
#include <fstream>

using namespace std;

// MR: doveva chiamarsi Percentuale e non percentuale!
int percentuale(int count, int tot){
    
    return count * 100 / tot;
}
// Inserire qui sotto la soluzione all'esercizio
int main (int argc, char * argv[]){
    
    if(argc != 3){
        cout << "Usage: " << argv[0] << " [file1] " << "[file2]" << endl;
        return 0;
    }

    fstream temperatura1;
    fstream temperatura2;

    temperatura1.open(argv[1], ios::in);
    temperatura2.open(argv[2], ios::in);

    if(temperatura1.fail() || temperatura2.fail()){
        cout << "Errore nell'apertura dei file" << endl;
        return 0;
    }

    int motore1, motore2; // MR: non specificato che temperature sono interi!
    int count = 0, tot = 0;

    while(temperatura1 >> motore1){
        temperatura2 >> motore2; // MR: cosa succede se il secondo file ha meno righe del primo? Manca controllo su EOF!
        if(motore1 > motore2){
            count++;
        }
        tot++;
    }
    // MR: manca controllo su tot==0 e stampa relativa!
    cout << "La percentuale di misurazioni in cui la temperatura del motore1 ha superato quella del motore2 e' del " << percentuale(count, tot) <<"%" << endl;

    temperatura1.close();
    temperatura2.close();
    return 0;
}