#include <iostream>
#include <fstream>

// Inserire qui sotto la soluzione all'esercizio

using namespace std;

// MR: la funzione doveva chiamarsi Percentuale non percentuale!
float percentuale(float measurements, float occurrency) {
    return (occurrency / measurements) * 100;
}


int main(int argc, char * argv []) {

  if (argc != 3) {
    cout << "Usage: exercise1.out <input1> <input2>" << endl;
    exit(1);
  }

  fstream input1, input2;
  input1.open(argv[1], ios::in);
  input2.open(argv[2], ios::in);

  if ( input1.fail() || input2.fail()) {
    cout << "Errore nell'apertura di uno o entrambi gli stream!" << endl;
  }


  int total_measurement = 0;
  int searchedCondition = 0;

  char buffer1[10];
  char buffer2[10];

  while (input1 >> buffer1) {
    input2 >> buffer2;

    ++total_measurement;
    // MR: atof definito in cstdlib, e quindi non consentito!
    float temp1 = atof(buffer1);
    float temp2 = atof(buffer2);

    if (temp1 > temp2) {
        ++searchedCondition;
    }
  }

  if (total_measurement == 0) {
    cout << "Il numero delle misurazioni e' uguale a zero," << endl << "per cui non posso calcolare la percentuale" << endl;
  } else {
    cout << "La percentuale di misurazioni in cui la temperatura del motore1" << endl << "ha superato quella del motore2 e' del " 
       << percentuale(total_measurement, searchedCondition) 
       << "%" << endl;
  }

  input1.close();
  input2.close();

  return 0;

}