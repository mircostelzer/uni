#include <iostream>
#include <fstream>

// Inserire qui sotto la soluzione all'esercizio
using namespace std;

int percentuale(int superato, int tentativi);

int main(int argc, char * argv[]){
    if(argc != 3){
        cout<<"Errore: numero parametri errato"<<endl;
        exit(1);
    }

    // char *filename1 = argv[1];
    // char *filename2 = argv[2];

    fstream inputFile1;
    inputFile1.open(argv[1], ios::in);

    if ( inputFile1.fail() ) {
        cout << "Errore nell'apertura degli stream!" << endl;
    }
    
    fstream inputFile2;
    inputFile2.open(argv[2], ios::in);

    if ( inputFile2.fail() ) {
        cout << "Errore nell'apertura degli stream!" << endl;
    }

    const int maxLineLength = 256;
    char line[maxLineLength];
    char line2[maxLineLength];

    int counter = 0;
    int superato = 0;

    if(sizeof(inputFile1) == 0 ||sizeof(inputFile2) == 0){
        // MR: se specifico file vuoto, non entra in questo if! Deve controllare il contenuto del file!
        // MR: va avanti e si genera floating point exception!
        cout<<"Non sono presenti misurazioni"<<endl;
        inputFile1.close();
        inputFile2.close();
        return 2;
    }

    while (inputFile1.getline(line, maxLineLength)) {
        inputFile2.getline(line2, maxLineLength); // MR: cosa succede se il secondo file ha meno righe del primo? Va in EOF e non controlla!
        // MR: uso di atoi non consentito, e' in cstdlib!
        int t1 = atoi(line);
        int t2 = atoi(line2);
        if(t1>t2){
            superato++;
        }
        
        counter++;
    }
    
    int perc = percentuale(superato, counter);
    // MR: l'output non e' conforme a quanto specificato nel testo!
    cout<<"Il motore 1 ha superato il motore 2 il " << perc <<"% di volte" <<endl;
    


    inputFile1.close();
    inputFile2.close();

    return 0;
}

int percentuale(int superato, int tentativi){
    superato *= 100;
    int percentuale = superato/tentativi;
    return percentuale;
};