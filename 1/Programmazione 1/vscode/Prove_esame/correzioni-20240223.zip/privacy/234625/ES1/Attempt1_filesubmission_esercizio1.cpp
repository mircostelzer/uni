#include <iostream>
#include <fstream>
using namespace std;

// Inserire qui sotto la soluzione all'esercizio
// MR: uso di variabili globali NON permessa!
int a;
int b;
int c;
int e;
int n;
int n_tot_1;
int n_tot_2;
int n_tot;
int percentuale_tot;

int main(int argc, char * argv []){

    if(argc != 3){
        cout << "Usage: esercizio1 temperatura1.txt temperatura2.txt" << endl;
        exit(1);
    }

    fstream input1, input2;
    input1.open(argv[1], ios::in);
    input2.open(argv[2], ios::in);

    if (input1.fail() || input2.fail()){
        cout << "Non sono riuscito ad aprire uno dei file" << argv[1] << " " << argv[2] << endl;
        input1.close();
        input2.close();
        exit(1);
    }
    
    while(!input1.eof()){                   
        n_tot_1++;
    }

    while(!input2.eof()){                   
        n_tot_2++;
    }

    n_tot_1=n_tot_1-1;
    n_tot_2=n_tot_2-1;
    
    if(n_tot_1 = 0){ // MR: e se invece e' n_tot_2?
        cout << "Il numero delle misurazioni e' uguale a zero," << endl << "per cui non posso calcolare la percentuale";
    }else{
        n_tot = n_tot_2;
    while(n<=n_tot, n++){
        // MR: a e b sono underfined
        input1.getline(a,n,'\n'); // MR: getline e' definito in string e quindi non consentito!
        input2.getline(b,n,'\n');
        c = c + percentuale(a, b);
    }


    percentuale_tot = (c/n_tot)*100;
    cout << "La percentuale di misurazioni in cui la temperatura del motore1" << endl << "ha superato quella del motore2 e' del " << percentuale_tot << "%.";

    input1.close();
    input2.close();
    return 0;
}
}

int percentuale(int a, int b) {
    int d;
    if(b>a)
    d=1;
    else
    d=0;
    return d;
}