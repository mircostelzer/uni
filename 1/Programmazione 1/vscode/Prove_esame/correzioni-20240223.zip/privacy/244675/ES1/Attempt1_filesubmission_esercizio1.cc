#include <iostream>
#include <fstream>

// Inserire qui sotto la soluzione all'esercizio
using namespace std;
double Percentuale(int verified, int tot);
int main(int argc, char *argv[])
{
    // apertura files
    if (argc != 3)
    {
        cout << "Errore: Forma: ./a.out <temp1> <temp2> \n";
        return -1;
    }
    fstream temp1, temp2;
    temp1.open(argv[1], ios::in);
    if (temp1.fail())
    {
        cout << "Errore: Apertura input " << argv[1] << " \n";
        return -2;
    }
    temp2.open(argv[2], ios::in);
    if (temp2.fail())
    {
        temp2.close();
        cout << "Errore: Apertura input " << argv[2] << " \n";
        return -3;
    }

    // calcolo

    int verified = 0, tot = 0;
    char engine1[4];
    char engine2[4];
    while (temp1 >> engine1 && temp2 >> engine2)
    {   // MR: atoi e' definito in cstlib, e quindi non consentito!
        if(atoi(engine1) > atoi(engine2))
            verified++;
        tot++;
    }

    if(tot)
    {  
        cout << "La percentuale di misurazioni in cui la temperatura del motore1\nha superato quella del motore2 e\' del " << Percentuale(verified,tot) << "%\n";
    } else 
    {
        cout << "Il numero delle misurazioni e' uguale a zero,\nper cui non posso calcolare la percentuale\n";
    }

    // chiusura files
    temp1.close();
    temp2.close();
    return 0;
}

double Percentuale(int verified, int tot)
{
    return verified * 100.0 / tot;
}
