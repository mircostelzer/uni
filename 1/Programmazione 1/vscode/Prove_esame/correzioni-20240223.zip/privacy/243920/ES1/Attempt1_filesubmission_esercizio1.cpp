#include <iostream>
#include <fstream>

// Inserire qui sotto la soluzione all'esercizio
using namespace std;

// MR: doveva ritornare double/float non void!
void Percentuale(float, float);

int main(int argc, char* argv[]){
    fstream temp1;
    fstream temp2;
    int t1;
    int t2;
    float n2 = 0;
    float n_tot = 0;

    temp1.open(argv[1]);
    temp2.open(argv[2]);

    if(temp1.is_open() && temp2.is_open()){
        while(temp1.good() && temp2.good()){
            if(temp1.peek() != EOF && temp2.peek() != EOF){
                // MR: il controllo avviene con un ciclo di ritardo, falsando il risultato!
                // MR: i flag vengono messi dfopo prima lettura
                temp1 >> t1;
                temp2 >> t2;
                if(t2 > t1){
                    n2 += 1;
                }
                n_tot += 1;
            }
        }
    }
    temp1.close();
    temp2.close();
    
    Percentuale(n2, n_tot);
}

// MR: non rispecchia quanto richiesto nel testo!
void Percentuale(float n2, float n_tot){
    if(n_tot != 0){
        cout << "La percentuale di misurazioni in cui la temperatura del motore2 ha superato quella del motore1 è del " << (n2/n_tot)*100 << "%." << endl;
    }
    else{
        cout << "Il numero delle misurazioni è uguale a zero, per cui non posso calcolare la percentuale" << endl;
    }
}