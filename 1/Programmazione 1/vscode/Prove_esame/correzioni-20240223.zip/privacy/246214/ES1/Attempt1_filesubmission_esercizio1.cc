#include <iostream>
#include <fstream>

// Inserire qui sotto la soluzione all'esercizio

using namespace std;

float aux (int *t1, int t1_size, int *t2);
// MR: doveva chiamarsi Percentuale e non percentuale!
float percentuale (float conta, int numMisurazioni); 

int main(int argc, char* argv[]) {

    if (argc != 3) {
        cout << "Usage: leggere <./a.out> <input_file_1> <input_file_2> " << endl;
        return -1;
    }

    fstream temp1, temp2;
    temp1.open(argv[1], ios::in);
    temp2.open(argv[2], ios::in);

    if (temp1.fail()){
        cout << "Il file dato in input " << argv[1] << "non esiste!" << endl;
    }
    if (temp2.fail()){
        cout << "Il file dato in input " << argv[2] << "non esiste!" << endl;
    }
    // MR: manca uscita in caso di errore in apertura!

    int tmp;
    
    // popolazione aaray t1
    int t1 [20]; // MR: da nessuna parte era specificato che c'erano al massimo 20 misurazioni!
    int t1_size = 0;
    while(temp1 >> tmp) {
        t1[t1_size] = tmp; // MR: manca controllo che t1_size non superi 20!
        t1_size++;            
    }

    // popolazione aaray t2
    int t2 [20]; // MR: da nessuna parte era specificato che c'erano al massimo 20 misurazioni!
    int t2_size = 0;
    while(temp2 >> tmp) { // MR: manca controllo che t2_size non superi 20!
        t2[t2_size] = tmp; 
        t2_size++;            
    }

    if (t1_size > 0) {
        cout << "La percentuale di misurazioni in cui la temperatura del motore1\nha superato quella del motore2 e' del " 
        << percentuale(aux(t1, t1_size, t2), t1_size) << "%\n";
    } else {
        cout << " Il numero delle misurazioni e' uguale a zero,\nper cui non posso calcolare la percentuale" << endl;
    }
        
    temp1.close();
    temp2.close();
    return 0;
}

float aux (int *t1, int t1_size, int *t2) {
    float conta = 0;
    for (int i = 0; i<t1_size; i++) { // MR: cosa succede se i due file hanno dimensioni diverse?
        if (t1[i] > t2[i]) {
            conta++;
        }
    }
    return conta;
}
// Tale funzione riceva come parametri il numero di volte in cui la temperatura del motore1 ha superato 
// quella del motore2 e il numero totale di misurazioni effettuate, e ritorni la percentuale cercata;
float percentuale (float conta, int numMisurazioni) {
    float ris = (conta/numMisurazioni)*100;
    return ris;
}

