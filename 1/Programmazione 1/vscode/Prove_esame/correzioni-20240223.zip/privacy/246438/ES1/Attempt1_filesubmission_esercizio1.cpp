#include <iostream>
#include <fstream>

// Inserire qui sotto la soluzione all'esercizio
using namespace std;

// MR: doveva ritornare un double/float e non un int!
int Percentuale(int magg, int num)
{
    if (num > 0)
        return (magg * 100)/num;
    else
        return -1;
}

int str_to_int(char *arr) {
    int i = 0;
    int val = 0; 
    int r;
    int flag;
    
    flag = 1;
    
    while(arr[i] != '\0'){
     
        r = arr[i] - '0';
        val = val * 10 + r;
        i++;
    }
    
    val = val * flag;
    
    return val;
        
}

int main(int argc, char* argv[])
{
    if(argc < 3)
    {
        cout << "inserire parametri corretti" << endl;
        return -1;
    }

    ifstream temp1, temp2;
    temp1.open(argv[1]);
    temp2.open(argv[2]);
    if(temp1.fail() || temp2.fail())
    {
        cout << "errore apertura file" << endl;
        return -1;
    }

    char buffer1[3];
    char buffer2[3]; // MR: mai specificato che fossero interi con meno di 2 cifre!
    int counter_magg = 0;
    int counter = 0;

    while(temp1 >> buffer1)
    {
        temp2 >> buffer2; // MR: cosa succede se il secondo file ha meno righe del primo? Manca controllo su EOF!
        // MR: cosa succede se il numero ha piu' di 2 cifre? Manca controllo!
        int tmp1 = str_to_int(buffer1); 
        int tmp2 = str_to_int(buffer2);

        if(tmp1 > tmp2)
            counter_magg++;

        counter++;
    }

    int perc = Percentuale(counter_magg, counter);     
    if(perc > 0)
    {
        cout << "La percentuale di misurazioni in cui la temperatura del motore1 ha superato quella del motore2 e' del: " << Percentuale(counter_magg, counter) << "%." << endl;
    }
    else
    {
        cout << "Il numero delle misurazioni e' uguale a zero, per cui non posso calcolare la percentuale" << endl;
    }

    temp1.close();
    temp2.close();
    return 0;
}