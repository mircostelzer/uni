#include <iostream>
#include <fstream>

// Inserire qui sotto la soluzione all'esercizio
using namespace std;

// MR: doveva chiamarsi Percentuale e non percentuale!
float percentuale(int m1supm2, int nmisurazioni) {
    float valore = 0;
    if(nmisurazioni == 0) {
        cout << "Nessuna misurazione" << endl;
    } else {
        valore = (float) m1supm2 / (float) nmisurazioni;
    }

    return valore;
}

int main(int argc, char** argv) {
    
    if(argc != 3) {
        cout << "Usage: ./a.out <file1> <file2>" << endl;
        return 1;
    }

    fstream input1;
    fstream input2;
    fstream output;

    input1.open(argv[1], ios::in);
    input2.open(argv[2], ios::in);
    // MR: non era specificato il nome del file di output! Doveva stampare su stdout!!
    output.open("percentuale.txt", ios::out);

    if(input1.fail() || input2.fail() || output.fail()) {
        cout << "Errore nell'apertura del file" << endl;
        return 1;
    }

    int len = 0;
    int val1; // MR: non specificato che fossero interi!
    int val2;

    while(input1 >> val1) {
        len++;
    }
    input1.clear();
    input1.seekg(0, ios::beg);

    int misure1[len];
    int misure2[len];
    int m1supm2 = 0;

    for(int i = 0; i < len; i++) {
        input1 >> val1;
        input2 >> val2; // MR: cosa succede se il secondo file ha meno righe del primo? Va in EOF e non controlla!
        if(val1 > val2) {
            m1supm2++;
        }
    }

    float perc = percentuale(m1supm2, len);

    if(len == 0) {
        output << "Il numero delle misurazioni e' uguale a zero, per cui non posso calcolare la percentuale";
    } else {
        output << "La percentuale di misurazioni in cui la temperatura ha superato quella del motore 2 è del " << (perc*100) << "%";
    }

    input1.close();
    input2.close();
    output.close();

    
    return 0;
}
