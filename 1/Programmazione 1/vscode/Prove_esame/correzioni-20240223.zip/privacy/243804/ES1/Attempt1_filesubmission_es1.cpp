#include <iostream>
#include <fstream>

using namespace std;
// Inserire qui sotto la soluzione all'esercizio

float Percentuale(int occorrenze, int totale)
{
    float valore = (float)occorrenze / totale * 100;
    return valore;
}

int main(int argc, char **argv)
{
    if (argc != 3)
    {
        fprintf(stdout, "Errore\n");
        fflush(stdout);
        exit(1);
    }

    std::ifstream iFile1(argv[1]);
    if (!iFile1.is_open())
    {
        fprintf(stdout, "Errore\n");
        fflush(stdout);
        exit(1);
    }

    std::ifstream iFile2(argv[2]);

    if (!iFile2.is_open())
    {
        fprintf(stdout, "Errore\n");
        fflush(stdout);
        exit(1);
    }

    int line1 = {}; // MR: non e' specificato che le temperature sono interi!
    int line2 = {};

    int row = 0;
    int occorrenze = 0;
    while (iFile1 >> line1)
    {
        iFile2 >> line2; // MR: cosa succede se il secondo file ha meno righe del primo? Va in EOF e non controlla!
        if (line1 > line2)
        {
            occorrenze++;
        }
        row++;
    }

    if (row == 0)
    {
        cout << "Il numero delle misurazioni e' uguale a zero,per cui non posso calcolare la percentuale";
    }
    else
    {
        float valore = Percentuale(occorrenze, row);
        cout << "La percentuale di misurazioni in cui la temperatura del motore1 ha superato quella del motore2 e' del " << valore << "% " << endl;
    }

    iFile1.close();
    iFile2.close();

    return 0;
}
