#include <iostream>
#include <fstream>
using namespace std;

// MR: doveva ritorna un double/float non un int!
int Percentuale(int supera, int tot) {
    int res;

    if (tot <= 0) {
        res = -1;
    }
    else {
        double perc = (double)supera / (double)tot * 100;
        res = (int)perc;
    }

    return res;
}

int main(int argc, char **argv)
{
    if (argc != 3) {
        cout << "Usage: a.out <input> <output>\n";
        exit (1);
    }

    fstream fin1, fin2;
    fin1.open(argv[1], ios::in);
    if (fin1.fail()) {
        cout << "Errore nell'apertura di un file di input\n";
        exit (1); 
    }

    fin2.open(argv[2], ios::in);
    if (fin2.fail()) {
        fin1.close();
        cout << "Errore nell'apertura di un file di input\n";
        exit (1);
    }

    int t1; // MR: non specificato che fosse un intero
    int t2;
    int counter = 0;
    int supera = 0;

    while (!fin1.eof() && !fin2.eof()) { // MR: legge una linea di troppo che altera i risultati preche' eof solo dopo lettura!
        fin1 >> t1;
        fin2 >> t2;
        if (t2 > t1) {
            supera++;
        }

        counter++;
    }

    int percentuale = Percentuale(supera, counter);
    if (percentuale == -1) {
        cout << "Il numero delle misurazioni e' uguale a zero, per cui non posso calcolare la percentuale\n";
    }
    else {
        cout << "La percentuale di misurazioni in cui la temperatura del motore1 ha superato quella del motore2 e' del " << percentuale << "%\n";
    }


    fin1.close();
    fin2.close();

    return 0;
}