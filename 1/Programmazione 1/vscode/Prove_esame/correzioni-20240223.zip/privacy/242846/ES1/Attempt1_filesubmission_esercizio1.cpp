#include <iostream>
#include <fstream>

using namespace std;

float Percentuale(int supera, int righe);

int main(int argc, char**argv){
    if(argc==3){
        fstream mot1,mot2;
        mot1.open(argv[1],ios::in);
        mot2.open(argv[2],ios::in);
        if(mot1.fail()||mot2.fail()){
            cout << "Il numero delle misurazioni e' uguale a zero, per cui non posso calcolare la percentuale" << endl;
            mot1.close();
            mot2.close();
            exit(0); 
        } else {
            float mis1=0,mis2=0,ris=0;
            int supera=0,righe=0;
            while(mot1 >> mis1 && mot2 >> mis2){
                righe++;
                if(mis1>mis2){
                    supera++;
                }
            }
            if(righe>0){
                ris=Percentuale(supera,righe);
                cout << "La percentuale di misurazioni in cui la temperatura del motore1 ha superato quella del motore2 e' del " << ris << "%." << endl;
            } else cout << "Il numero delle misurazioni e' uguale a zero, per cui non posso calcolare la percentuale" << endl; 
            mot1.close();
            mot2.close();
        }
    } else {
        cout << "comando CLI non corretto" << endl;
        exit(0);
    }
}

float Percentuale(int supera, int righe){
    float res=0;
    res=float(supera)/float(righe)*100.0;
    return res;
}
