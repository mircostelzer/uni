#include <iostream>
#include <fstream>

// Inserire qui sotto la soluzione all'esercizio
using namespace std;

double Percentuale(int total, int c){
    return (100.0*c)/total;
}

int main(int argc, char * argv[]){
    if(argc!=3)
        cerr << "Numero di parametri inseriti invalido." << endl, exit(0);
    
    fstream temp1, temp2;
    temp1.open(argv[1], ios::in), temp2.open(argv[2], ios::in);

    if(!temp1 || !temp2)
        cerr << "File inseriti invalidi, ricontrollare i valori dati." << endl, temp1.close(), temp2.close(), exit(0);

    double t1, t2;
    int total=0, c=0;
    
    while(temp1 >> t1, temp2 >> t2){
        total++;
        if(t1>t2)
            c++;
    }

    if(total!=0)
        cout << "La percentuale di misurazioni in cui la temperatura del motore1 ha superato quella del motore2 e' del " << Percentuale(total, c) << "%." << endl;
    else
        cout << "Il numero delle misurazioni e' uguale a zero, per cui non posso calcolare la percentuale" << endl;

    temp1.close(), temp2.close();
    return 0;
}