#include <iostream>
#include <fstream>

using namespace std;

// MR: doveva chiamarsi Percentuale e non percentuale
double percentuale(int mag1, int mag2, double tot){
    double res = (mag1/tot)*100;
    return res;
}

// Inserire qui sotto la soluzione all'esercizio
int main(int argc, char * argv []){
    fstream myin1, myin2;
    myin1.open(argv[1],ios::in); //lettura
    myin2.open(argv[2],ios::in); //lettura 

    // MR: manca controllo che apertura abbia avuto successo!

    // MR: dove specificato che numeri sono interi e hanno max due cifre?
    char temp1[2];
    char temp2[2];

    int* temperatura1 = new int [10];
    int* temperatura2 = new int [10];

    int i=0, mag1=0, mag2=0; //variabili contatori per quale valore è maggiore e i per il ciclo
    double res; //risultato del calcolo della percentuale

    while(!myin1.eof() && !myin1.fail() && !myin2.fail()){
        //lettura valori e cast a int
        myin1 >> temp1; // MR: cosi' legge solo due caratteri, non due cifre! e va out of bound in quanto ci sono due caratteri e non tre! e array ha dimensione 2, quindi la stringa ha dimensione 3 (terminatore)
        // MR: assunzione sbagliata che 48 corrisponda a '0', come specificato diverse volte a lezione!
        temperatura1[i] = ((int)temp1[0] - 48) * 10 + (int)temp1[1] - 48;

        myin2 >> temp2; // MR: cosa succede se il secondo file ha meno righe del primo? Va in EOF e non controlla!
        temperatura2[i] = ((int)temp2[0] - 48) * 10 + (int)temp2[1] - 48;

        //controllo quale motore ha il valore maggiore
        if(temperatura1[i]>temperatura2[i]){
            mag1++;
        }else{
            mag2++;
        }

        i++;
    }

    //calcolo della percentuale
    res = percentuale(mag1, mag2, (mag1+mag2));

    //output
    if((mag1+mag2)!=0){
        cout << "La percentuale di misurazioni in cui la temperatura del motore1 ha superato quella del motore2 e' del " << res << "%." << endl;
    }else{
        cout << "Il numero delle misurazioni e' uguale a zero, per cui non posso calcolare la percentuale" << endl;
    }

    myin1.close();
    myin2.close();
    return 0;
}