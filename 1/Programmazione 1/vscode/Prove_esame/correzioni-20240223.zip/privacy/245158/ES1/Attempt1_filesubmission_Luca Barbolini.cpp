#include <iostream>
#include <cmath>
#include <fstream>

using namespace std;

// Inserire qui sotto la soluzione all'esercizio
// MR: doveva ritornare un float/double non void!
void Percentuale(float x, float y);

int main(int argc, char * argv[]){

        // Controllo degli argomenti
        if (argc != 3){
            cout << "Usage: Error" << endl;
            return -1;
        }

        fstream input1, input2;
        input1.open(argv[1], ios :: in);
        input2.open(argv[2], ios :: in);

        if(input1.fail()){
            cout<<"Il file dato in input "<<argv[1]<<" non esiste!"<<endl;
        }
        if(input2.fail()){
            cout<<"Il file dato in input "<<argv[2]<<" non esiste!"<<endl;
        }

        float a,b;
        float num =0, tot =0;

        while(input1 >> a && input2 >> b){
            if(a>b){ // MR: soluzione v1 e non v2
                num++;
            }
            tot++;
        }
        Percentuale(num, tot);
        input1.close();
        input2.close();
        return 0; 
    }

    void Percentuale(float x, float y){
        // MR: non doveva fare stampa interna!
        if(y == 0){
            cout<<"Il numero delle misurazioni e' uguale a zero, per cui non posso calcolare la percentuale"<<endl;
        }
        else{
            float per;
            per = (x/y)*100;
            cout<<"La percentuale di misurazioni in cui la temperatura del motore1 ha superato quella del motore2 e' del " <<per<<"%."<<endl;
        }
    }