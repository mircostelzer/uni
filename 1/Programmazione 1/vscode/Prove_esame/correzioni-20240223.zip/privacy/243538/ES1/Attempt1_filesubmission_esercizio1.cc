#include <iostream>
#include <fstream>
using namespace std;



double Percentuale(double count,double tot);






int main(int argc, char *argv[]) {
    if (argc != 3) {
        cerr << "Usage: " << argv[0] << " <input_file1> <input_file2>" << endl;
        exit(1);
    }
    fstream m1, m2;
    m1.open(argv[1], ios::in);
    if (m1.fail()) {
        cerr << "Could not open file " << argv[1] << endl;
        exit(1);
    }

    m2.open(argv[2], ios::in);
    if (m2.fail()) {
        m1.close();
        cerr << "Could not open file " << argv[2] << endl;
        exit(1);
    }


    int temp1, temp2;
    double count = 0;
    double tot = 0;
    while(!m1.eof()){ // MR: in questo modo conta un elemento in piu', infatti cosi' come scritto, se m1 va in EOF, non viene controllato prima di fare il confronto!, ma lo verifico solo al ciclo successivo, contando sbagliato!
        m1 >> temp1; // MR: cosa succede si i due file hanno lunghezze diverse? Non controllato!
        m2 >> temp2;
        if(temp1 > temp2){
            count++;
        }
        tot++;
    }
    std::cout << tot << std::endl;



    if(tot != 0){
        cout << "La percentuale di misurazioni in cui la temperatura del motore1 ha superato quella del motore2 e' del " << Percentuale(count,tot) << "%.";  
    }
    else{
        cout << "  Il numero delle misurazioni e' uguale a zero, per cui non posso calcolare la percentuale";
    }
    

    m1.close();
    m2.close();
    return 0;
}



double Percentuale(double count,double tot){
    double res = count/tot;
    res *= 100;
    return res;
}