#include <iostream>
#include <fstream>

// Inserire qui sotto la soluzione all'esercizio
using namespace std;

// MR: si doveva chiamare Percentuale non percentuale!
float percentuale(float, float);

int main (int argc, char ** argv){

    int temp1, temp2, differenza=0, totale=0; // MR: non e' specificato che le temperature sono interi!
    fstream motore1, motore2;
    if(argc!=3){
        cerr << "Numero di file errato";
        return 1;

    }
    motore1.open(argv[1], ios::in);
    motore2.open(argv[2], ios::in);
    
    if(motore1.fail()){
        cerr << "Errore nella apertura di uno o entrambi i file";
        return 1;
    }
    // MR: manca controllo su motore2.fail()

    while(motore1>>temp1){
        motore2>>temp2; // MR: cosa succede se il secondo file ha meno righe del primo? Manca controllo su EOF!
        if(temp1>temp2){
            differenza++;
        }
        totale++;
    }
    if(totale==0){
        cout << "impossibile calcolare" << endl;
    }else{
    float res = percentuale(differenza, totale);

    cout << "La percentuale di tempo nella quale la temperatura del motore 1 e' superiore a quella del motore 2 e' del:  " << res << "%" << endl;
    }
    motore1.close();
    motore2.close();
    return 0;
}
float percentuale(float differenza, float totale){
    
float res=differenza/totale*100;
return res;

}