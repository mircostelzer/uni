#include <iostream>
#include <fstream>
using namespace std;

// MR: Percentuale non percentuale! Inoltre doveva ritornare un float o un double!
int percentuale(int winnercount, int totcount);
int pow(int num, int esp);

int main(int argc, char *argv[]){


    fstream input1, input2;

    if(argc != 3){
        cout << "Numero di argomenti errato";
        return 1;
    }

    input1.open(argv[1], ios::in);
    input2.open(argv[2], ios::in);


    if(input1.fail()){
        cout << "Impossibile aprire il primo file";
    } else if(input2.fail()){
        cout << "Impossibile aprire il secondo file";
    } else if(input1.eof() || input2.eof()){
        // MR: eof messo solo se fatta almeno una lettura!
        cout << "Il numero delle misurazioni e' uguale a zero, per cui non posso calcolare la percentuale" << endl;
    } else {

        string frase1 = ""; // MR: string NON consentito!
        int len_frase1 = 0;
        int num1 = 0;
        string frase2 = "";
        int len_frase2 = 0;
        int num2 = 0;


        
        int input2winner = 0;
        int tot_lines = 0;


        while(getline(input1, frase1)){ // MR: getline e' definito in string e quindi non consentito!

            getline(input2, frase2); // MR: cosa succede se il primo file contiene piu' elementi del secondo?? Manca controllo!


            tot_lines ++;

            len_frase1 = 0;
            len_frase2 = 0;

            num1 = 0;
            num2 = 0;
            
            for(int i = 0; frase1[i] != '\0'; i++){
                len_frase1 ++;
            }
            

            for(int i = 0; frase2[i] != '\0'; i++){
                len_frase2 ++;
            }
            

            for(int i = len_frase1-1; i >= 0; i--){
                // MR: non era specificato che le temperature fossero intere! Non corretto assumere che 48 corrisponda a 0
                num1 += ((int) frase1[i] - 48) * pow(10,len_frase1 - i - 1);
            }

            for(int i = len_frase2-1; i >= 0; i--){
                num2 += ((int) frase2[i] - 48) * pow(10,len_frase2 - i - 1);
            }

            if(num2 > num1){
                input2winner ++;
            }

        }

        if(tot_lines == 0){

            cout << "Il numero delle misurazioni e' uguale a zero, per cui non posso calcolare la percentuale" << endl;

            return 2;
        }

        int risultato = percentuale(input2winner, tot_lines);

        cout << "La percentuale di misurazioni in cui la temperatura del motore1 ha superato quella del motore2 e' del " << risultato << "%." << endl;

        input1.close();
        input2.close();
    }




    return 0;
}


int percentuale(int winnercount, int totcount){

    int res = 0;
    // MR; qui divisione tra interi, e se winnercount * 100 minore di totcount il risultato e' 0, ma non lo dovrebbe essere!
    res = (winnercount * 100) / totcount;

    return res;

}

int pow(int num, int esp){

    int res = 1;

    for(int i = 0; i < esp; i++){
        res *= num;
    }

    return res;
}
