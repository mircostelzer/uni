#include <iostream>
#include <fstream>
// Inserire qui sotto la soluzione all'esercizio
using namespace std;
const int n1 = 5;

float Percentuale(float superato, float misurazioni);

int main(int argc, char * argv[]){
    fstream temp1,temp2;

    if(argc != 3){
        cout << "numero degli argomenti non valido" << endl;
        exit(1);
    }

    // apre i file
    temp1.open(argv[1], ios::in);
    temp2.open(argv[2], ios::in);

    // controlla che si aprano correttamente
    if(temp1.fail() || temp2.fail()){
        cout << "file non aperti correttamente" << endl;
        exit(1);
    }

    char in1[n1];
    char in2[n1];
    int count1 = 0, i = 0;

    // algoritmo
    while(temp1 >> in1 && temp2 >> in2){
        // MR: atoi e' definito in cstlib, e quindi non consentito!
        if(atoi(in1) > atoi(in2))
            count1++;

        i++;
    }

    if(i == 0){
        cout << "nessuna misurazione effettuata, impossibile calcolare" << endl;
        exit(1);
    }
    // MR: output non conforme con quanto richiesto nel testo dell'esercizio
    cout << Percentuale((count1) + 0.0, i + 0.0) << "%" << endl;
    return 0;
}

float Percentuale(float superato, float misurazioni){
    int p = 100 / (misurazioni / superato);
    return p > 0 ? p : 0;
}