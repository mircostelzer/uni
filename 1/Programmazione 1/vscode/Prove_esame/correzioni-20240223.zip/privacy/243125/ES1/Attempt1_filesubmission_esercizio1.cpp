#include <iostream>
#include <fstream>
using namespace std;


// è possibile definire proprie funzioni

double Percentuale(double magg_temp_mot1, double tot_mis){
  double a = magg_temp_mot1 / tot_mis;
  return a * 100;
}


int main(int argc, char * argv []) {
  
  fstream myin1, myin2;
  myin1.open(argv[1], ios::in);
  myin2.open(argv[2], ios::in);

  if (myin1.fail() || myin2.fail())
  {
    cerr << "Errore .fail" << endl;
    exit(0);
  }
  if (argc != 3)
  {
    cerr << "Errore, uso: ./a.out temperatura1.txt temperatura2.txt" << endl;
    exit(0);
  }

  float buffer1 = 0.0; 
  float buffer2 = 0.0;
  double max1 = 0;
  double tot = 0;

  while (myin1 >> buffer1 && myin2 >> buffer2)
  {
    if (buffer1 > buffer2)
    {
      max1++;
      tot++;
    } else if (buffer1 <= buffer2)
    {
      tot++; 
    }
  }

  double percent = Percentuale(max1, tot);

  if (tot == 0)
  {
    cout << "Nessuna misurazione effettuata" << endl;
  } else {
    cout << "La percentuale di misurazioni in cui la temperatura 1 ha superato quella del motore 2 è del " 
      << percent << "%." << endl;
  }
  
  myin1.close(); myin2.close();
  return 0;
}
