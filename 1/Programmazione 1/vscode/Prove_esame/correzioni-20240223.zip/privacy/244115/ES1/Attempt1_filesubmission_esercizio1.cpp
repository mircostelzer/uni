#include <iostream>
#include <fstream>
using namespace std;

// Inserire qui sotto la soluzione all'esercizio

// MR: doveva chiamarsi Percentuale e ritornare un double/float non un int!
int percentuale(int sup2, int misurazioni);

int main(int argc, char* argv[])
{
    if(argc!=3)
    {
        cout<<"Usage: ./a.out <temperatura1.txt> <temperatura2.txt>";
        exit(0);
    }

    fstream temperatura1, temperatura2;
    temperatura1.open(argv[1],ios::in);
    temperatura2.open(argv[2],ios::in);

    if(temperatura1.fail())
    {
        cout<<"Impossibile aprire il file "<<argv[1];
        exit(0);
    }
    if(temperatura2.fail())
    {
        cout<<"Impossibile aprire il file"<<argv[2];
        exit(0);
    }

    int contatore=0, sup2=0;
    char tmp1[4], tmp2[4]; // MR: non specificato che numero cifre fosse 3! e che fossero interi!
    float temp1, temp2;
    //while(!temperatura2.eof() && !temperatura1.eof())
    while(temperatura1>>tmp1 && temperatura2>>tmp2)
    {
        //temperatura1>>tmp1;
        temp1=atof(tmp1); // MR: definita in cstlib e non consentita!
        //temperatura2>>tmp2;
        temp2=atof(tmp2);

        if(temp2>temp1)
        {
            sup2++;
        }
        contatore++;
    }

    if(contatore==0)
    {
        cout<<"Non sono state effettuate misurazioni"; // MR: output non conforme a quanto richiesto!
    }else cout<<"La percentuale di misurazioni in cui la temperatura del motore2 ha superato quella del motore1 e' del "<<percentuale(sup2,contatore)<<"%";

    cout<<endl;
    temperatura1.close();
    temperatura2.close();
}

int percentuale(int sup2, int misurazioni)
{
    return ((sup2*100)/misurazioni);
}