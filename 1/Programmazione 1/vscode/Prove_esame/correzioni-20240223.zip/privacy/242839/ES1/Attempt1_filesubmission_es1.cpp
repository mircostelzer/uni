#include <iostream>
#include <fstream>
using namespace std;
// Inserire qui sotto la soluzione all'esercizio
// MR: Percentuale deve ritornare un float non un int!
int Percentuale(int, int);
int main(int argc, char *argv[])
{
    if (argc != 3)
    {
        cerr << "Usage: ./a.out  <inputfile>  <inputfile2> " << endl;
        exit(0);
    }

    fstream myinput, myinput2;
    myinput.open(argv[1], ios::in);
    myinput2.open(argv[2], ios::in);

    if (myinput.fail())
    {
        myinput2.close();
        cerr << "Input file non aperto correttamente " << endl;
        exit(1);
    }

    if (myinput2.fail())
    {
        myinput.close();
        cerr << "Inputfile2 non aperto correttamente " << endl;
        exit(2);
    }
    int numero_righe1 = 0;

    char leggi[21];
    while (myinput.getline(leggi, 21)) // MR: non consentito perche' definito in string
    {
        numero_righe1++; // per sapere il numero di righe nel file per allocazione dinamica leggo solo un file perchè hanno stesso numero righe
    }

    myinput.close();
    myinput2.close();
    int *arrayTemp1 = new int[numero_righe1]; // MR: non specificato che siano interi
    // MR: cosa succede se secondo file ha piu' elementi del primo? Manca controllo!
    int *arrayTemp2 = new int[numero_righe1];
    int leggo1;
    int leggo2;
    int i = 0;
    int j = 0;
    // MR: ha chiuso sopra entrambi i file, quindi come fa a leggere?
    while (myinput >> leggo1) // riempio gli array dinamici con le temperature
    {
        arrayTemp1[i] = leggo1;
        i++;
    }
    while (myinput2 >> leggo2) // Se secondo file ha piu' elementi del primo cosa succede? Manca controllo!
    {
        arrayTemp2[j] = leggo2;
        j++;
    }
    // MR: gia' chiusi sopra!
    myinput.close();
    myinput2.close(); // ho array riempiti faccio confronto
    int numero_volteT2_maggT1 = 0;
    int somma_Percentuali = 0;
    for (int i = 0; i < numero_righe1; i++)
    {
        if (arrayTemp2[i] > arrayTemp1[i])
        {
            numero_volteT2_maggT1++;
        }
        somma_Percentuali += Percentuale(numero_volteT2_maggT1 ,numero_righe1);
    }

    // MR: mancano le stampe richieste!


    delete[] arrayTemp2;
    delete[] arrayTemp1;
    return 0;
}

int Percentuale(int temp2_maggiore_temp1, int totale_misurazioni) // passo numero volte e  numero Righe
{
    // calcola le differenze tra indici array T2-T1/T1 * 100 e fai somma+= somma +percentuale
    // MR: e' vuota!
}
