#include <iostream>
#include <fstream>

using namespace std;

fstream motore1;
fstream motore2;

// MR: doveva chiamarsi Percentuale!!!
double percentuale(double c,int misurazioni)
{
    double pc;
    if(misurazioni == 0)
    {
        cout<<"File Vuoto"<<endl;
        return 0;
    }
    else
    {
        pc = c/misurazioni;
        return pc*100;
    }
}

int main(int argc, char * argv[])
{

    // MR: dove e' scritto che ci sono al massimo 5 misurazioni?
    double salva1[5],salva2[5], x;
    double count = 0; 
    int i=0;
    if(argc != 3)
    {
        cout<<"ERRORE - INSERIRE 2 FILE"<<endl;
    }

    motore1.open(argv[1],ios::in); 
    motore2.open(argv[2],ios::in);
    // MR: come ampiamento detto MANCA controllo apertura file!!!

    // MR: cosa succcede se il file contiene piu' di 5 valori? Eccede dimensione array e scrive out of bound!
    while(motore1 >> x)
	{
		salva1[i]=x;
        i++;
	}
    if(i == 0) // MR: NO, il file potrebbe essere stato aperto correttamente e non contenere valori!
    {
        cout<<"Errore nell'apertura del file"<<endl;
    }
    x = 0;
    i = 0;
    while(motore2 >> x)
	{
		salva2[i]=x;
        i++;
	}
	for(int f=0;f<5;f++)
    {
        if(salva1[f]>salva2[f])
        {
            count++;
        }
    }
    // MR: non rispecchia output previsto nel testo dell'esercizio
    cout<<"Percentuale di misurazioni superiori: "<<percentuale(count,i)<<"%"<<endl;;
    motore1.close();
    motore2.close();

    return 0;
}