#include <iostream>
#include <fstream>
#include <cstring>


using namespace std;




int main(int nArg,char * arg[]){
     if (nArg != 3)
    {
        cout << "Usage: ./a.out <motore1> <motore2> \n";
        exit(1);
    }
    fstream m1,m2;
    m1.open(arg[1],ios::in);
    m2.open(arg[2],ios::in);

    if (m1.fail() || m2.fail())
    {
        cout << "Errore nell' apertura dei file \n";
        exit(2);
    }
    
    double t1=-1;
    double t2=-1;

    int nSuperamento=0;
    int nTemp=0;

    while (m1 >> t1)
    {
        m2 >> t2; // MR: cosa succede se file 2 ha meno elementi del file 1?? Manca controllo!
        if (t1>t2)
        {
            nSuperamento++;
        }
        nTemp++;
    }

    if (nTemp!=0)
    {
        // MR: doveva implementare e chiamare una funzione Percentuale!
        double media=(double)nSuperamento/nTemp;
        cout << "La percentuale di misurazioni in cui la temperatura del motore1 ha superato quella del motore2 e' del " << media*100 << "%" << endl;
    }else{
        cout << " Il numero delle misurazioni e' uguale a zero, per cui non posso calcolare la percentuale" << endl;
    }
    
    
    m1.close();
    m2.close();
}