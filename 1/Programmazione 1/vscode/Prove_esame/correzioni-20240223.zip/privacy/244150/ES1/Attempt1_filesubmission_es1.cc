#include <iostream>
#include <fstream>

using namespace std;

int pow(int i, int exp){
    if(i == 1) return 1;
    if(exp == 0) return 1;
    return i * pow(i, exp-1);
}

int strlen(char str[]){
    int i = 0;
    for(i; str[i]!='\0'; i++);
    return i;
}

double strToDouble(char arr[]){
    int len = strlen(arr);
    int i = 0;
    int dot = 0;
    double res = 0;

    for(i; arr[i]!='\0'; i++){
        if(arr[i]!='.'){
            
            res += (arr[i] - 48) * pow(10, len - i - 1);
            
            
        } else {
            dot = i;
        }
        
    }
    

    
    if(dot != 0) {
        int pos = (int) res % pow(10, dot);
        res = (res - pos)/ 10;
        res += pos;
        res = res / pow(10,len - 1 - dot);
    }

    return res;
}

double percentuale(int sup, int tot){
    if(tot == 0) return -1;
    cout<<sup<<tot<<endl;
    return ((double) sup / (double) tot) * 100; 
    
}

int main(int argc, char * argv []) {

    if(argc != 3){
        cout<<"errore, numero di argomenti scorretto"<<endl;
        exit(0);
    }

    fstream in, in2;
    in.open(argv[1], ios::in);
    in2.open(argv[2], ios::in);
    
    if(in.fail() || in2.fail()){
        cout<<"errore apertura file, riprovare"<<endl;
        exit(0);
    }

    char motore1[256], motore2[256];
    int sup = 0;
    int times = 0;

    // MR: poteva leggere direttamente in double senza conversione...
    while(in>>motore1 && in2>>motore2){   
        double m1 = strToDouble(motore1);
        double m2 = strToDouble(motore2);
        times++;

        if(m2>m1) sup++;
    }

    int perc = percentuale(sup, times);

    if(perc != -1) cout<<"a percentuale di misurazioni in cui la temperatura del motore2 ha superato quella del motore1 e' del "<<perc<<"%"<<endl;
    else cout<<"Il numero delle misurazioni e' uguale a zero, per cui non posso calcolare la percentuale"<<endl;

    in.close();
    in2.close();
    return 0;
}
