#include <iostream>
#include <fstream>
using namespace std;

double Percentuale(int count_mot1_magg, int counter_temp_totali){
    return (double(count_mot1_magg)/double(counter_temp_totali))*100;
}

int main(int argc, char* argv[]){
    if(argc != 3){
        cerr<<"Error: ./a.out <file_motore1> <file_motore2>"<<endl;
        return -1;
    }

    fstream mot1, mot2;
    mot1.open(argv[1], ios::in);
    if(mot1.fail()){
        cerr<<"Error during file opening"<<endl;
        return -2;
    }
    mot2.open(argv[2], ios::in);
    if(mot2.fail()){
        cerr<<"Error during file opening"<<endl;
        mot1.close();
        return -2;
    }

    char motor1[11];
    char motor2[11];
    int counter_temp_totali=0;
    int count_mot1_magg=0;

    while(mot1>>motor1){
        mot2>>motor2;
        // MR: atoi e' definito in cstdlib e quindi non consentito
        // MR: non specificato che t1 e t2 fossero interi!
        int first_number=atoi(motor1);
        int second_number=atoi(motor2);
        counter_temp_totali+=1;
        if(first_number>second_number){
            count_mot1_magg+=1;
        }
    }

    if(counter_temp_totali>0){
        cout<<"La percentuale di misurazioni in cui la temperatura del motore1 ha superato quella del motore2 e' del "<<Percentuale(count_mot1_magg, counter_temp_totali)<<"%."<<endl;
    }else{
        cout<<"Il numero delle misurazioni e' uguale a zero, per cui non posso calcolare la percentuale"<<endl;
    }

    mot1.close();
    mot2.close();
    return 0;
}