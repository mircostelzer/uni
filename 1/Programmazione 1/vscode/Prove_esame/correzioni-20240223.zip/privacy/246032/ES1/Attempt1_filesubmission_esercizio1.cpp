#include <iostream>
#include <fstream>
using namespace std;

// MR: doveva chiamarsi Percentuale e non percentuale!
int percentuale(int volte, int tot);

// Inserire qui sotto la soluzione all'esercizio
int main(int argc, char* argv[]){
    if(argc != 3){
        cerr << "Usage: ./a.out <fileInput.txt> <fileInput2.txt>\n";
        return -1;
    }

    fstream myin1, myin2;
    myin1.open(argv[1], ios::in);
    myin2.open(argv[2], ios::in);

    if(myin1.fail() || myin2.fail()){
        cerr << "errore\n";
        return -2;
    }

    int temperatura1[100], temperatura2[100];
    int val1, val2, k = 0; // MR: non specificato che temperature sono interi!
    int nVolte = 0;

    while(!myin1.eof()){
        myin1 >> val1;
        myin2 >> val2; // MR: cosa succede se il secondo file ha meno elementi del primo? Manca controllo su EOF!
        if(val1 > val2)
            nVolte++;
        k++;
    }
 
    //cout << nVolte << " " << k <<endl; se c'è \n dopo l'ultimo numero si sballa il risultato

    if(k > 0)
        cout << "La percentuale di misurazioni in cui la temperatura del motore1\n ha superato quella del motore2 e' del " << percentuale(nVolte, k) << "%.\n";
    else
        cout << "Il numero delle misurazioni e' uguale a zero,\n per cui non posso calcolare la percentuale\n";
 

    myin1.close();
    myin2.close();
}

int percentuale(int volte, int tot){
    return (volte*100)/tot;
}