#include <iostream>
#include <fstream>

// Inserire qui sotto la soluzione all'esercizio

// MR: doveva chiamarsi Percentuale!
int calc_perc(float num_temp, float mot1G){
	return (mot1G/num_temp)*100;
}

int main(int argc, char* argv[]){
	if(argc < 3){
	  std::cout << "usage: a.out <input.file1> <input.file2>" << std::endl;
	  return -1;
	}

	std::ifstream motore1;
	std::ifstream motore2;
	motore1.open(argv[1],std::ios::in);
	motore2.open(argv[2],std::ios::in);
	if(!motore1.is_open() && !motore2.is_open()){
		std::cout << "some error has occurred while opening the file" << std::endl;
		return -1;
	}

	char buf1[4],buf2[4];
	float num_temp = 0, mot1G = 0;

	while(motore1 >> buf1 && motore2 >> buf2){
		// MR: atoi definito in cstdlib, non consentito!
		int mot1 = std::atoi(buf1); // MR: non era specificato che temperatura fosse un intero
		int mot2 = std::atoi(buf2);

		num_temp++;
		if(mot1 > mot2){
			mot1G++;
		}
	}

	int perc = calc_perc(num_temp,mot1G);

	if(perc > 0){
		std::cout << "La percentuale di misurazioni in cui la temperatura del motore1"
	       		<< " ha superato quella del motore2 e' del " << perc << "%." << std::endl;
	}else{
		std::cout << "Il numero delle misurazioni e' uguale a zero,"
			<< "per cui non posso calcolare la percentuale" << std::endl;
	}
}
