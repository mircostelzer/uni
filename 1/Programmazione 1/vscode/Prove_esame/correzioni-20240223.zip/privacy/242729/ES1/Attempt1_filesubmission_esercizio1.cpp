#include <iostream>
#include <fstream>

using namespace std;

// Inserire qui sotto la soluzione all'esercizio

int percentuale(int nSup, int nTot);

int main(int argc, char * argv[]){
    fstream motore1, motore2;

    if(argc != 3){
        cout << "./esercizio1.out <temperatura1.txt> <temperatura2.txt>"<<endl;
        return 0;
    }

    // MR: doveva aprire argv[1] e non "temperatura1.txt"!!!
    // MR: doveva aprire argv[2] e non "temperatura2.txt"!!!
    motore1.open("temperatura1.txt", ios::in);
    motore2.open("temperatura2.txt", ios::in);

    if(motore1.fail() || motore2.fail()){
        cout << "errore nell'apertura dei file"<<endl;
        return 0;
    }

    int nSup=0; int nTot=0;
    int tmp1=0; int tmp2=0;
    char tmot1, tmot2;
    int mol=10;
    motore1 >> tmot1;
    motore2 >> tmot2;

    // MR: assunzione errata che le temperature in ogni file abbiano stessa lunghezza in termini di caratteri!
    // MR: cosa succede se t1 = 10 e t2 = 200? La seconda temperatura NON viene letta correttamente.
    // MR: Inoltre nn specificato che le temperature sono interi!
    while(!motore1.eof() && !motore2.eof()){

            if(tmot1 <= '9' && tmot1 >= '0' && mol<=10){
                tmp1+=tmot1*mol;
            }
            motore1 >> tmot1;

            if(tmot2 <= '9' && tmot2 >= '0' && mol<=10){
                tmp2+=tmot2*mol;
            }
            motore2 >> tmot2;

            mol/=10;
        
        if(mol<1){
            if(tmp1 > tmp2){
                nSup++;
            }
            tmp1 = 0;
            tmp2 = 0;
            nTot++;
            mol=10;
        }
    }

    // cout << nSup << " " << nTot << endl;

    motore1.close();
    motore2.close();
    if(nTot!=0){
        cout << "la percentuale di misurazioni in cui il motore 1 ha superato il motore 2 in temperatura e' " << percentuale(nSup,nTot) <<"%"<<endl;
    }else{
        cout << "il numero delle misurazioni e uguale a 0, per cui non ci sono dati a sufficenza" << endl;
    }

    return 0;

}
// MR: doveva chiamarsi Percentuale!
int percentuale(int nSup, int nTot){
    return ((float)nSup/(float)nTot)*100;
}