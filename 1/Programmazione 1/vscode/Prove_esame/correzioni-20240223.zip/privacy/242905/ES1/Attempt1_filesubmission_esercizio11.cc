#include <iostream>
#include <fstream>

// Inserire qui sotto la soluzione all'esercizio

int percentuale (int num1, int num2);

using namespace std;

int main(int argc, char * argv []) {
  
    if (argc != 3) {
        cout << "Errore inserimento file da linea di comando" << endl;
        exit(0);
        }

    fstream input, second;

    input.open(argv[1], ios::in);
    second.open(argv[2], ios::in);

    if(input.fail() || second.fail()) {
        cout << "Errore apertura dei file" << endl;
    }

    int num1, num2; // MR: non specificato che temperature fossero interi!
    int sup = 0; //volte in cui la t del motore1 supera motore2
    int count = 0; //conta quante temperature sono state registrate
    while (input >> num1) {
        second >> num2; // MR: cosa succede se il secondo file ha meno righe del primo? Va in EOF e non controlla!

        if (num1 > num2) {
            sup++;
            count++;
        } else count++;
    }


    if (count == 0) {
        cout << "Il numero delle misurazioni e' uguale a zero, per cui non posso calcolare la percentuale " << endl;
    } else {
        cout << "La percentuale di misurazioni in cui la temperatura del motore1 ha superato quella del motore2 e' del " << percentuale(sup, count) << "%" << endl;
    }

    input.close();
    second.close();

    return 0;
}


int percentuale (int sup, int tot) {
    int percent;
    percent = (sup*100)/tot;
    return percent;
}

