#include <iostream>
#include <fstream>

using namespace std;

// Inserire qui sotto la soluzione all'esercizio

// MR: doveva chiamarsi Percentuale e non percentuale!
double percentuale (int , int );
int    strlen      (const char *word);

int main(int argc, char** argv) {

  if (argc != 3) {
    cerr << "use: <file1> <file2>" << endl;
    exit(1);
  }

  fstream input1, 
          input2;

  input1.open(argv[1], ios::in);
  if (!input1.is_open()) {
    cerr << "error file1" << endl; 
    exit(0);
  }
      
  input2.open(argv[2], ios::in); 
  if (!input2.is_open()) {
    cerr << "error file2" << endl;
    exit(0);
  }  

  char line1[20],
       line2[20]; 
  int  count  = 0, //misurazioni / 2
       count2 = 0, //numero di volte che file1 supera file2
       c      = 0; 

  while(input1.getline(line1, 20)) // MR: getline definita in string e non consentita!
    count ++;

  input1.close();
  input2.close();
  input1.open(argv[1], ios::in);
  input2.open(argv[2], ios::in); 

  while(input1.getline(line1, 20) && input2.getline(line2, 20)) {
    double cifra1 = atoi(line1), // MR: atoi definita in cstdlib e non consentita!
           cifra2 = atoi(line2);
    if(cifra1 > cifra2)
      count2 ++;
    c ++;
  }

  if (count == 0) { //controllo se il file è vuoto
    cerr << "Non ci sono misurazione nei file" << endl;
    input1.close();
    input2.close();
    exit(-1);
  }

  cout << "Percentuale calcolata: " << 2*percentuale(count2, count*2) <<"%" << endl;

  input1.close();
  input2.close();
  return 0;
}

double percentuale (int count, int misurazioni) {

  int x = (count*100) / misurazioni;

  return (double)x;
}

int strlen(const char *word) {

  if(*word != '\0')
    return 1 + strlen(word+1);
  return 0;
}