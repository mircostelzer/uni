#include <iostream>
#include <fstream>

// Inserire qui sotto la soluzione all'esercizio

using namespace std;

float Percentuale(int n_superiori, int tot);

int main(int argc, char* argv[]){
    if(argc!=3){
        cerr << "Numero di parametri errato.";
        exit(1);
    }

    fstream input1, input2;
    input1.open(argv[1], ios::in);
    if(input1.fail()){
        cerr << "Errore nell'apertura del primo file." << endl;
        exit(1);
    }
    input2.open(argv[2], ios::in);
    if(input2.fail()){
        cerr << "Errore nell'apertura del secondo file." << endl;
        input1.close();
        exit(1);
    }
    
    int n_superiori=0, tot=0;
    float temp1, temp2;

    while(input1>>temp1){
        input2>>temp2; // MR: cosa succede se primo file ha piu' elementi del secondo? Manca controllo!
        tot++;
        if(temp1>temp2){ // MR: controllo di v1 e non v2!
            n_superiori++;
        }
    }
    
    if(tot>0){
        float percentuale = Percentuale(n_superiori, tot);
        cout << "La percentuale di misurazioni in cui la temperatura del motore1 ha superato quella del motore2 e' del " << percentuale << "%." << endl;
    } else{
        cout << "Il numero delle misurazioni e' uguale a zero, per cui non posso calcolare la percentuale" << endl;
    }

    input1.close();
    input2.close();
    return 0;
}

float Percentuale(int n_superiori, int tot){
    float res;
    res=(n_superiori*100)/tot;
    return res;
}