#include <iostream>
#include <cstdlib>
using namespace std;

// Non modificare questa parte sotto del codice
typedef struct Stack {
    int data;
    struct Stack * next;
} Stack;

struct Stack * initStack() {
    return nullptr;
}

bool isEmpty(struct Stack * s) {
    return (s == nullptr);
}

void push(struct Stack * &s, int value) {
    struct Stack * newElement = new Stack;
    newElement->data = value;
    newElement->next = s;
    s = newElement;
}

int top(struct Stack * s) {
    if (isEmpty(s)) {
        std::cerr << "Error: stack is empty" << std::endl;
        exit(1);
    }
    return s->data;
}

int pop(struct Stack * &s) {
    if (isEmpty(s)) {
        std::cerr << "Error: stack is empty" << std::endl;
        exit(1);
    }
    int value = s->data;
    struct Stack * temp = s;
    s = s->next;
    delete temp;
    return value;
}

void deleteStack(struct Stack * &s) {
    while (!isEmpty(s)) {
        pop(s);
    }
}

void printStack(struct Stack * s, const char * message = "Stack: ") {
    if (isEmpty(s)) {
        std::cout << "Stack is empty" << std::endl;
    } else {
        std::cout << message;
        struct Stack * temp = s;
        while (temp != nullptr) {
            std::cout << temp->data << " ";
            temp = temp->next;
        }
        std::cout << std::endl;
    }
}
// Non modificare questa parte sopra del codice

void gira(Stack *& stk){
  int elem = 0;
  if(!isEmpty(stk)){
    elem = top(stk);
    pop(stk);
    gira(stk);
  }

  push(stk, elem);
}

void helper(Stack *&s, int pre, Stack *&res, bool ult){
  int ultimo = 0;
  ult =0;
  if(!isEmpty(s)){
    // MR: lo costruisce rovesciato, ma corretto!
    //cout << "in" << endl;
    ultimo = top(s);
    ult = 1;
    int elem = pre -ultimo;
    push(res, ultimo);
    push(res, elem);

    pre = elem;
    pop(s);
    helper(s, pre, res, ult);
  }
  //cout << "ult " << ultimo << endl;
  if(ult == 1)
    push(s, ultimo);
}

Stack * stackOperator(Stack *&s){
  Stack *res = initStack();
  helper(s, 0, res, 0);
  //gira(res);
  //pop(s);

  return res;
}

/*Stack * stackOperator(Stack *s){
  Stack *res = initStack();
  int pre =0;
  while(!isEmpty(s)){
    int ultimo = top(s);
    cout << ultimo << endl;
    pop(s);
  }

  return NULL;
}*/

int main() {
    struct Stack *s, *result;
    unsigned int seed = (unsigned int)time(NULL);
    // seed = 60000
    seed = 1697033220;
    srand(seed);

    s = initStack();
    for (int i = 0; i < 5; i++) {
        if (i != 2) push(s, 5-i);
    }
    printStack(s, "Original before: ");
    result = stackOperator(s);
    printStack(result, "Result StackOperator: ");
    printStack(s, "Original after: ");
    deleteStack(s);
    deleteStack(result);

    s = initStack();
    for (int i = 0; i < 10; i++) {
        push(s, rand() % 100);
    }
    printStack(s, "Original before: ");
    result = stackOperator(s);
    printStack(result, "Result StackOperator: ");
    printStack(s, "Original after: ");
    deleteStack(s);
    deleteStack(result);

    return 0;
}

// Inserire qui sotto la definizione della funzione stackOperator

// Inserire qui sopra la definizione della funzione stackOperator