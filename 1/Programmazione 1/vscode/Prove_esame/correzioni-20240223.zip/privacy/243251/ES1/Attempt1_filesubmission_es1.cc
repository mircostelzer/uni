#include <iostream>
#include <fstream>
using namespace std;

float percentuale(int ct, int t1ct){
  float ris =0;
  if(ct >0)
    ris = float(t1ct)/ct*100;
  return ris;
}

int main(int argc, char * argv [])
{
  if (argc != 3)
  {
    cout << "Usage: esercizio1 <input_file> <output_file>" << endl;
    exit(1);
  }

  fstream tp1, tp2;
  tp1.open(argv[1], ios::in);
  tp2.open(argv[2], ios::in);

  if (tp1.fail() || tp2.fail())
  {
    cout << "Non sono riuscito ad aprire uno dei file "<< argv[1]  << " " << argv[2] << endl;
    tp1.close();
    tp2.close();
    exit(1);
  }

  int temp1; // MR: non specificato che fossero interi!
  int temp2;
  int ct =0;
  int t1ct=0;

  while(tp1 >> temp1){
    tp2 >> temp2; // MR: cosa succede se il secondo file ha meno righe del primo? Va in EOF e non controlla!
    //cout << temp1 << " temp 2 " << temp2 << endl;
    if(temp1 > temp2){
      t1ct++;
    }
    ct++;
  }

  //cout << t1ct << endl;
  // MR: doveva chiamarsi Percentuale!
  float ris = percentuale(ct, t1ct);
  //cout << ris << endl;
  if(ct >0){
    cout << "La percentuale di misurazioni in cui la temperatura del motore1ha superato quella del motore2 e' del " << ris << "%." << endl;
  }else{
    cout << "Il numero delle misurazioni e' uguale a zero, per cui non posso calcolare la percentuale"<<endl;
  }
  
  tp1.close();
  tp2.close();

  return 0;
}

