#include <iostream>
#include <fstream>

// Inserire qui sotto la soluzione all'esercizio
using namespace std;

double Percentuale(int m, int n);

int main(int argc, char * argv []) {

  // Controllo che gli argomenti ci siano tutti
  if (argc != 3) {
    cout << "Usage: exercise1.out <input>" << endl;
    exit(1);
  }

  // Apro gli stream di lettura e scrittura
  fstream input1,input2;
  input1.open(argv[1], ios::in);
  input2.open(argv[2], ios::in);

  // Controllo che gli stream siano stati aperti correttamente
  if ( input1.fail() ) {
    cout << "Errore nell'apertura degli stream!" << endl;
  }
  if ( input2.fail() ) {
    cout << "Errore nell'apertura degli stream!" << endl;
  }

  int count = 0;
  int nmisure = 0;
  char buf1[256];
  char buf2[256];

  while (!input1.eof() || !input2.eof())
  {

    input1 >> buf1;
    input2 >> buf2;
    int i = 0;
    bool x = true;
    while ((buf1[i] != '\0' || buf1[i] != '\0') && x)
    {

      if (buf1[i] - '0' > buf2[i] - '0')
      {
        // MR: cosi' incrementa count ogni volta che condizione vera, per ogni carattere del numero.
        // Cosa succede se hanno lunghezze diverse?
        count++;
      }
      else if (buf1[i] - '0' < buf2[i] - '0')
      {

        x = false;
      }

      i++;
    }
    // MR: count e' da incrementare se e solo se x e' vero, cioe' se buf1 e' maggiore di buf2
    // MR: funziona solo se buf1 e buf2 hanno la stessa lunghezza, altrimenti potrebbe dirmi che t1 e' maggiore di t2 anche se non vero, se per caso t2 ha una cifra in piu'.
    nmisure++;
  }
  if (nmisure != 0)
  {
    // MR: count non conta quante volte t1 maggiore di t2, ma quante volte la cifra i di t1 e' maggiore di quella di t2.
    double p = Percentuale(count, nmisure);

    cout << "La percentuale di misurazioni in cui la temperatura del motore1 ha superato quella del motore2 e' del" << p << "%" << endl;
  }
  else
  {
    cout << "Il numero delle misurazioni e' uguale a zero,  per cui non posso calcolare la percentuale marco" << endl;
  }

  input1.close();
  input2.close();

  return 0;

}

double Percentuale(int m, int n){

double perc=0;
perc=(m*100/n);

return perc;

}