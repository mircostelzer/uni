
#include <iostream>
#include <fstream>

// MR: doveva chiamarsi Percentuale non percentuale!
double percentuale(int supm1,int mistot)
{
    
    double rap=supm1*1.0;
    rap=rap/mistot;
    
    return rap*100;
}
// Inserire qui sotto la soluzione all'esercizio
int main(int argc,char * argv[])
{
   std::fstream inputm1,inputm2;

    inputm1.open(argv[1],std::ios::in);
    inputm2.open(argv[2],std::ios::in);
    // MR: manca controllo su apertura file!

    int mistot=0;
    int supm1=0;
    int m1,m2;
      inputm1>>m1;
      inputm2>>m2;
      mistot++;
        if(m1==NULL||m2==NULL)
        {
           
            std::cout<<"Il numero delle misurazioni e' uguale a zero, per cui non posso calcolare la percentuale";
        }
        else
        {
            if(m2>m1)
            {
                supm1++;
                
            }
            while(!inputm1.eof())
            {
               inputm1>>m1;
                inputm2>>m2; // MR: cosa succede se il primo file ha piu' elementi del secondo?? Manca controllo!
                if(m2>m1)
                {
                    supm1++;
                }
                 
                 mistot++;
            }
            // MR: divisione per 0 se mistot == 0!
            // MR: output non conforme a quanto richiesto!
            std::cout<<percentuale(supm1,mistot)<<"%";
            
       
       
       
    
        }

    
    
    
    
     
        
     
    
}

