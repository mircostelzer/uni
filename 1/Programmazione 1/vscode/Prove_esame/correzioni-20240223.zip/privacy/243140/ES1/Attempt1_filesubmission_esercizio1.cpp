#include <iostream>
#include <fstream>

// Inserire qui sotto la soluzione all'esercizio

using namespace std;


int Percentuale(int tempMaggiori, int tot);


int main(int argc, char * argv[]){

    if (argc != 3){
        cerr << "Correct Usage: ./a.out <temperatura1.txt> <temperatura2.txt>" << endl;
        exit(1);
    }

    fstream input1, input2;

    input1.open(argv[1], ios::in);
    input2.open(argv[2], ios::in);

    if(input1.fail() || input2.fail()){
        cerr << "Error While Opening Files" << endl;
        exit(1);
    }

    int i = 0;
    int conta = 0;
    int temp1, temp2; // MR: non specificato fossero interi!
    

    while(input1 >> temp1){
        input2 >> temp2; // MR: cosa succede se file2 ha meno righe di file1? Va in EOF e non controlla!

        if (temp1 > temp2){
            conta++;
        }
        i++;
    }

    int perc = Percentuale(conta, i);

    if (perc != -1){
        cout << "La percentuale di misurazioni in cui la temperatura del motore1" << endl << "ha superato quella del motore2 e' del " << perc << "%." << endl;
    }

    else {
        cout << "Il numero delle misurazioni e' uguale a zero," << endl << "per cui non posso calcolare la percentuale" << endl;
    }

    input1.close();
    input2.close();
    return 0;
}


int Percentuale(int tempMaggiori, int tot){
    int perc = -1;

    if (tot > 0){
        perc = (tempMaggiori * 100) / tot;
    }

    return perc;
}