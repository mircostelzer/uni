#include <iostream>
#include <fstream>

using namespace std;

// MR: doveva chiamarsi Percentuale e non percentuale!
// MR: doveva prendere due interi nn array!
int percentuale(double t1[],double t2[],int totale);

int main(int argc,char* argv[]){
    if(argc!=3){
        cout<<"Usage: esercizio1 <input1> <input2>"<<endl;
        return 1;
    }
    fstream input1;
    input1.open(argv[1], ios::in);
    double temp1[100],temp2[100]; // MR: non era specificato dimensione massima del file!
    int lunghezza=0,perc;
    while(!input1.fail()&&!input1.eof()){
        input1>>temp1[lunghezza]; // MR: cosa succede se file 2 ha meno elementi del file 1?? Manca controllo!
        lunghezza++;
    }
    input1.close();
    fstream input2;
    input2.open(argv[2], ios::in);
    lunghezza=0;
    while(!input2.fail()&&!input2.eof()){
        input2>>temp2[lunghezza];
        lunghezza++;
    }
    input2.close();
    if(lunghezza==0){
        cout<<"Il numero delle misurazioni e' uguale a zero, per cui non posso calcolare la percentuale"<<endl;
    }
    else{
        perc=percentuale(temp1,temp2,lunghezza);
        cout<<"La percentuale di misurazioni in cui la temperatura del motore2 ha superato quella del motore1 e' del "<<perc<<"%"<<endl;
    }
    return 0;
}

int percentuale(double t1[],double t2[],int totale){
    int conta=0,p;
    totale=totale-1;
    for(int i=0;i<totale;i++){
        if(t2[i]>t1[i]){
            cout<<"il maggiore e' t2"<<endl;
            conta++;
        }
        else{
            cout<<"il maggiore e' t1"<<endl;
        }
    }
    p=(100*conta)/totale;
    return p;
}