#include <iostream>
#include <fstream>

// Inserire qui sotto la soluzione all'esercizio
using namespace std;

// MR: return value should be double, not int!
int Percentuale(int numeroVolte, int totMisurazioni);

int main(int argc, char *argv[])
{

    if (argc != 3)
    {
        cout << "Usage: ./a.out <input_file_temp1> <input_file_temp2>" << endl;
        exit(0);
    }
    fstream fileTmp1;
    fstream fileTmp2;
    fileTmp1.open(argv[1], ios::in);
    fileTmp2.open(argv[2], ios::in);

    if (fileTmp1.fail())
    {
        cout << "errore nell'apertura del file";
    }
    else if (fileTmp2.fail())
    {
        cout << "errore nell'apertura del file";
    }
    else
    {

        int valMot1 = 0; // MR: non specificato che sono interi!
        int valMot2 = 0;
        int volteMot2SuperaMot1 = 0;
        int countMisurazioni = 0;

        while (fileTmp1 >> valMot1 && fileTmp2 >> valMot2)
        {
            if (valMot2 > valMot1)
            {
                volteMot2SuperaMot1++;
            }
            countMisurazioni++;
        }

        int percentuale = Percentuale(volteMot2SuperaMot1, countMisurazioni);
        if (percentuale == -1)
        {
            cout << " Il numero delle misurazioni e' uguale a zero, per cui non posso calcolare la percentuale" << endl;
        }
        else
        {
            cout << "La percentuale di misurazioni in cui la temperatura del motore1 ha superato quella del motore2 e' del " << percentuale << "%." << endl;
        }
    }
    fileTmp1.close();
    fileTmp2.close();
    return 0;
}

int Percentuale(int numeroVolte, int totMisurazioni)
{
    if (totMisurazioni <= 0)
    {
        return -1;
    }
    // MR: ritorna 0 se numeroVolte * 100 < totMisurazioni invece che valore reale!
    return (numeroVolte * 100) / totMisurazioni;
}