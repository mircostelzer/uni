#include <iostream>
#include <fstream>

// Inserire qui sotto la soluzione all'esercizio

using namespace std;

// MR: doveva ritornare double/float non int!
int Percentuale (int n1, int n2) {
    int risultato = ((n1/n2)*100);
    return risultato;
}

int main(int argc, char * argv[]) {

    if (argc != 3) {
        cout << "Usage: ./a.out <temperatura1.txt> <temperatura2.txt>" << endl;
        exit(1);
    }

    fstream input;
    input.open(argv[1], ios::in);
    // MR: qui sovrascrive quanto assegnato sopra...
    input.open(argv[2], ios::in);
    // MR: output che cosa corrisponde?
    output.open();

    if (input.fail()) {
        cout << "Errore nell'apertura dei file" << endl;
        input.close();
        exit(1);
    }

// MR: non capisco queste operazioni...
    input >> argv[1] >> argv[2];
    int dim1 = atoi(argv[1]); // MR: atoi definita in cstdlib e non consentita!
    int dim2 = atoi(argv[2]);

    int dueMaggioreUno = 0;
    for (i=0 ; i<dim2 ; i++) {
            if (argv[2][i] < argv[1][i]) { // MR: confronto tra char e non tra interi!
                dueMaggioreUno += 1;
            }
        }
    
    // MR: manca controllo su divisione per zero!
    ris = Percentuale(dueMaggioreUno , dim2);

    output << "La percentuale di misurazioni in cui la temperatura del motore1 ha superato quella del motore2 e' del" << ris << "%";
    if (argv[1] == NULL || argv[2] == 0) {
        output << "Il numero delle misurazioni e' uguale a zero,
  per cui non posso calcolare la percentuale";
    }

    input.close();
    output.close();
     

}