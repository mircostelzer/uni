#include<iostream>
#include<fstream>

using namespace std;

// Dichiaraizone funzione percentuale
double Percentuale(int superamenti, int totali);

int main(int argc, char * argv []) {

    // Controllo numero argomenti
    if (argc != 3) {
        cout << "Eroore, utilizzare il formato: a.out temperatura1.txt temperatura2.txt" << endl;
        exit(1);
    }

    // Aprtura stream
    fstream input1, input2;
    input1.open(argv[1], ios::in);
    input2.open(argv[2], ios::in);

    if (input1.fail() || input2.fail()) {
        cout << "Non e` stato possibile aprire uno o entrambi gli stream di input." << endl;
        exit(1);
    }

    // Variabili di conteggio
    int letture_totali = 0;
    int contatore_superamenti = 0;

    //varibaili temperature mototi
    double tempMotore1, tempMotore2;


    //Lettura da file e conteggio
        while (input1 >> tempMotore1 && input2 >> tempMotore2) {
            letture_totali++;
            if (tempMotore1 > tempMotore2) {
                contatore_superamenti++;
            }
        }

    //Calcolo percentuale e stampa
        if (letture_totali > 0) {
            double percentuale = Percentuale(contatore_superamenti, letture_totali);
            cout << "La percentuale di misurazioni in cui la temperatura di motore1 ha superato quella di motore2 è del: " << percentuale << "%" << endl;
        } else {
            cout << "Il numero delle misurazioni e' uguale a zero, per cui non posso calcolare la percentuale." << endl;
        }

    //Chiusura stream
    input1.close();
    input2.close();

return 0;
}

//Funzione percentuale
double Percentuale(int contatore_superamenti, int letture_totali) {
    return (double(contatore_superamenti) / letture_totali) * 100.0;
}




    