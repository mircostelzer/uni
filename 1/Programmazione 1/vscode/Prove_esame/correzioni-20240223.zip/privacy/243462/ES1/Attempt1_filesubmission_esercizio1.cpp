#include <iostream>
#include <fstream>

using namespace std;

// Inserire qui sotto la soluzione all'esercizio
int Percentuale(double num_1_maggiore_2, double mis_tot);
int main(int argc, char* argv[]){

    if(argc!=3){
        cout<<"usage: ./a.out input1 input2"<<endl;
        return -1;
    }

    fstream input1;
    input1.open(argv[1],ios::in);
    if(input1.fail()==true){
        cout<<"errore nell'apertura del primo file"<<endl;
        return -1;
    }
    fstream input2;
    input2.open(argv[2],ios::in);
    if(input2.fail()==true){
        cout<<"errore nell'apertura del secondo file"<<endl;
        return -1;
    }

    double mis_tot=0;
    double num_1_maggiore_2=0;

    int m1,m2; // MR: non era specificato che le temperature fossero interi!

    while(input1>>m1 && input2>>m2){
        mis_tot++;
        if(m1>m2){
            num_1_maggiore_2++;
        }
    }
    if(mis_tot==0){
        cout<<"Il numero delle misurazioni e' uguale a zero, per cui non posso calcolare la percentuale"<<endl;
    }else{
        int perc=Percentuale(num_1_maggiore_2, mis_tot);
        cout<<"La percentuale di misurazioni in cui la temperatura del motore1 ha superato quella del motore2 e' del "<<perc<<"%"<<endl;
    }
    input1.close();
    input2.close();

}

int Percentuale(double num_1_maggiore_2, double mis_tot){
    double perc=(num_1_maggiore_2/mis_tot)*100;
    return perc;
}