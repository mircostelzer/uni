#include <iostream>
#include <fstream>

// Inserire qui sotto la soluzione all'esercizio

char *strcpy(char *, char * );
int strlen(char []);

int atoi(char []);

// MR: Era richiesto che Percentuale ritornasse un double, non un void!
void Percentuale(int , int );

int main(int argc, char *argv[]) {

    // Controllo argomenti
    if (argc!=3) { std::cout << "Utilizzo: ./a.out temperatura1.txt temperatura2.txt" << std::endl; exit(1); }

    // Definisco gli stream
    std::fstream input_1, input_2;

    // Apri gli stream
    input_1.open(argv[1], std::ios::in);

    // Controllo apertura degli stream
    if (input_1.fail()) { std::cout << "Errore apertura file 1!" << std::endl; return 1; }

    char buffer[10];

    int numeri_elementi = 0;
    while (input_1>>buffer) numeri_elementi++;
    input_1.close();

    input_1.open(argv[1], std::ios::in);
    // MR: manca controllo che apertura abbia avuto successo!
    
    // MR: sta allocando un array statico sullo stack, non necessario, e come detto a lezione non da fare!
    char numeri_1[numeri_elementi][3+1];// MR: Non era specificato che i numeri fossero itneri e che avessero al massimo 3 cifre!

    int numeri_counter = 0;
    
    // Comincio a leggere i due file
    while (input_1>>buffer) { //  MR: cosa succede se ci sono piu' di 10 caratteri?
        strcpy(numeri_1[numeri_counter],buffer);
        numeri_counter++;
    }

    char numeri_2[numeri_elementi][3+1];

    input_2.open(argv[2], std::ios::in);
    if (input_2.fail()) { std::cout << "Errore apertura file 2!" << std::endl; return 1; }
    // MR: manca chiusura di input_1

    numeri_counter = 0;

    while (input_2>>buffer) { // MR: cosa succede se il secondo file contiene piu' elementi del primo??
        strcpy(numeri_2[numeri_counter],buffer);
        numeri_counter++;
    }

    int numero_m2_superato_m1 = 0;
    int numer_tot_misurazioni = 0;

    for (int i=0; i<numeri_elementi; i++) {
        if (atoi(numeri_2[i]) > atoi(numeri_1[i])) numero_m2_superato_m1++;
        numer_tot_misurazioni++;
    }

    std::cout << "numero_m2_superato_m1: " << numero_m2_superato_m1 << std::endl;
    std::cout << "numer_tot_misurazioni: " << numer_tot_misurazioni << std::endl;

    Percentuale(numero_m2_superato_m1,numer_tot_misurazioni);

    // Chiudo gli stream
    input_1.close();
    input_2.close();

    return 0;
}

char *strcpy(char *dest, char *source) {
    char * original_dest = dest;
    while (*source != '\0') {
        *dest = *source;
        dest++;
        source++;
    }
    *dest = '\0';
    return original_dest;
}

int strlen(char word[]) {
    int counter=0;
    while(word[counter] != '\0') counter++;
    return counter;
}

int atoi(char num[]) {
    int res = 0, sign = 1, n = strlen(num);
    for(int i=0; i<n; i++) {
        if (num[i] == '-') sign = -1;
        else if (num[i] >= '0' && num[i] <= '9') res = res * 10 + num[i] - '0';
        else if (res != 0) break;
    }
    return res * sign;
}

void Percentuale(int motore_2_superato_motore_1, int tot_misurazioni) {
    // MR: cosa succede se tot_misurazioni e' 0?
    // MR: l' output non gestendo il caso 0, non e' conforme con quanto richiesto nel testo dell'esercizio!
    float percentuale = (motore_2_superato_motore_1*100 / tot_misurazioni*100)/100;
    std::cout << "La percentuale di misurazioni in cui la temperatura del motore1 ha superato quella del motore2 e' del ";
    std::cout << percentuale << "%" << std::endl;
}