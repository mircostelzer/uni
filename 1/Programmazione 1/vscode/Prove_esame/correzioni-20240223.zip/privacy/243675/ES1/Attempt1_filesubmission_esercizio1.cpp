#include <iostream>
#include <fstream>
using namespace std;

// MR: doveva chiamarsi Percentuale non percentuale!
double percentuale(int, int);

int main(int argc, char ** argv){
    if(argc != 3){
        cout << "Using: a.out <file1> <file2>";
        return 1;
    }
    fstream in1, in2;
    in1.open(argv[1], ios::in);
    in2.open(argv[2], ios::in);
    if (!in1 ||!in2){
        cout << "Impossibile aprire il file" << endl;
        return 2;
    }
    int n1, n2; // MR: non specificato che sono interi!
    int count2 = 0, c= 0;
    while(in1 >> n1){ // MR: cosa succede se il primo file ha piu' elementi del secondo?? Manca controllo!
        in2 >> n2;
        c++;
        if (n2 > n1)
            count2++;
    }
    if (c == 0){
        cout << "Il numero delle misurazioni e' uguale a zero," << endl;
        cout << "per cui non posso calcolare la percentuale" << endl;
    } else {
        int p = percentuale(count2, c);
        cout << "La percentuale di misurazioni in cui la temperatura del motore2" << endl;
        cout << "ha superato quella del motore1 e' del " << p << "%." << endl;
    }
    in1.close();
    in2.close();
    return 0;
}

double percentuale(int mot, int tot){
    double perc;
    perc = (double)(100 / tot) * mot;
    return perc;
}
