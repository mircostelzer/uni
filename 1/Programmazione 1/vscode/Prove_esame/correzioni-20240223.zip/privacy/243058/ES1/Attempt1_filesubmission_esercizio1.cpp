#include <iostream>
#include <fstream>

// Inserire qui sotto la soluzione all'esercizio
using namespace std;

float Percentuale(int total_count, int temp1_count);

int main(int argc, char ** argv) {
    if (argc < 3) {
        cout << "Usage: " << argv[0] << "</path/to/input1> </path/to/input2>" << endl;
        exit(1);
    }

    fstream temp1, temp2;
    temp1.open(argv[1], ios_base::in);
    temp2.open(argv[2], ios_base::in);
    if (temp1.fail() || temp2.fail()) {
        cout << "Error: couldn't open files" << endl;
        exit(2);
    }

    int total_count = 0;
    int temp1_count = 0, temp2_count = 0;
    double temp1_buffer, temp2_buffer;
    while(temp1 >> temp1_buffer && temp2 >> temp2_buffer) {
        if (temp1_buffer > temp2_buffer)
            temp1_count++;
        total_count++;
    }

    float perc = Percentuale(total_count, temp1_count);

    if (perc == -1)
        cout << "Il numero delle misurazioni e' uguale a zero, per cui non posso calcolare la percentuale" << endl;
    else
        cout << "La percentuale di misurazioni in cui la temperatura del motore1 ha superato quella del motore2 e' del " << perc << "%." << endl;
    
    temp1.close();
    temp2.close();
}

float Percentuale(int total_count, int temp1_count) {
    float result;
    if (total_count > 0)
        result = (100 * temp1_count) / total_count;
    else
        result = -1;
    return result;
}
