#include <iostream>
#include <cstdlib>

// Non modificare questa parte sotto del codice
typedef struct Stack {
    int data;
    struct Stack * next;
} Stack;

struct Stack * initStack() {
    return nullptr;
}

bool isEmpty(struct Stack * s) {
    return (s == nullptr);
}

void push(struct Stack * &s, int value) {
    struct Stack * newElement = new Stack;
    newElement->data = value;
    newElement->next = s;
    s = newElement;
}

int top(struct Stack * s) {
    if (isEmpty(s)) {
        std::cerr << "Error: stack is empty" << std::endl;
        exit(1);
    }
    return s->data;
}

int pop(struct Stack * &s) {
    if (isEmpty(s)) {
        std::cerr << "Error: stack is empty" << std::endl;
        exit(1);
    }
    int value = s->data;
    struct Stack * temp = s;
    s = s->next;
    delete temp;
    return value;
}

void deleteStack(struct Stack * &s) {
    while (!isEmpty(s)) {
        pop(s);
    }
}

void printStack(struct Stack * s, const char * message = "Stack: ") {
    if (isEmpty(s)) {
        std::cout << "Stack is empty" << std::endl;
    } else {
        std::cout << message;
        struct Stack * temp = s;
        while (temp != nullptr) {
            std::cout << temp->data << " ";
            temp = temp->next;
        }
        std::cout << std::endl;
    }
}
// Non modificare questa parte sopra del codice

// Inserire qui sotto la dichiarazione della funzione stackOperator
Stack * stackOperator(struct Stack *);
// Inserire qui sopra la dichiarazione della funzione stackOperator

int main() {
    struct Stack *s, *result;
    unsigned int seed = (unsigned int)time(NULL);
    // seed = 60000
    seed = 1697033220;
    srand(seed);

    s = initStack();
    for (int i = 0; i < 5; i++) {
        if (i != 2) push(s, 5-i);
    }
    printStack(s, "Original before: ");
    result = stackOperator(s);
    printStack(result, "Result StackOperator: ");
    printStack(s, "Original after: ");
    deleteStack(s);
    deleteStack(result);

    s = initStack();
    for (int i = 0; i < 10; i++) {
        push(s, rand() % 100);
    }
    printStack(s, "Original before: ");
    result = stackOperator(s);
    printStack(result, "Result StackOperator: ");
    printStack(s, "Original after: ");
    deleteStack(s);
    deleteStack(result);

    return 0;
}

// Inserire qui sotto la definizione della funzione stackOperator
Stack * stackOperator(struct Stack * s){
    Stack * r = new Stack(); // MR: qui alloca un nodo
    r = initStack(); // MR: qui lo sovrascrive creando memory leak!
    int first = top(s);
    int ris = 0,topS,topR,first_topR;
    
    while(!isEmpty(s)){
        topS = top(s);
        std::cout << topS << std::endl;
        pop(s);

        ris = -topS;
        if(!isEmpty(r)){
            first_topR = top(r);
            topR = top(r);


            while(topR!=first ){
                ris += (topR>0? -topR : topR); 
                std::cout << ris;
                pop(r);
                push(s,topR);
                topR=top(r);
            }

            while(top(s)!=first_topR ){
                push(r,top(s));
                pop(s);
            }
        }
        
        
        push(r,topS);
        push(r,ris);
        printStack(s);
    }
    // MR: sembra andare in loop infinito!
    printStack(r);
    return r;
}
// Inserire qui sopra la definizione della funzione stackOperator
