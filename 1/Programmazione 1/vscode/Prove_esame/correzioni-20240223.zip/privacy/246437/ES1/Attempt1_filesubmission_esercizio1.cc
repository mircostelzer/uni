#include <iostream>
#include <fstream>
using namespace std;

float Percentuale(float,float);

int main(int argc ,char * argv[] ){

    fstream f_motore1,f_motore2;

     if(argc != 3){
        cout << "Usage: ./a.out <file_motore1>  <file_motore2>"<<endl;
        return -1;
    }

    f_motore1.open(argv[1],ios::in);

    f_motore2.open(argv[2],ios::in);

    if(f_motore1.fail()||f_motore2.fail()){
        cout << "erroe in apertura del file" << endl;
        return -2;
    }
    
    int buf_m1, buf_m2; // MR: non specificato che temperature sono interi!
    float tot_misurazioni=0.0, motore1_supera=0.0;
    while(f_motore1>>buf_m1){
        f_motore2 >> buf_m2; // MR: cosa succede se il secondo file ha meno righe del primo? Manca controllo su EOF!
        tot_misurazioni++;
        // cout << buf_m1 << endl;
        if(buf_m1 > buf_m2) motore1_supera++;
    }
    if(tot_mis==0){ // MR: non definito e causa errore di compilazione!
        cout << "i file sono vuoti" << endl;
        return -1 // MR: manca ; e quindi non compila!
    }
    cout << "tot_mis: " << tot_misurazioni << endl;
    cout << "motore1_sup: " << motore1_supera << endl;

    cout << "La percentuale di misurazioni in cui la temperatura del motore1 ha superato quella del motore2 e del " << Percentuale(tot_misurazioni,motore1_supera) << "%" << endl;

    f_motore1.close();
    f_motore2.close();
    return 0;
}

float Percentuale(float tot,float sup){

    float ret=(sup/tot)*100;
    return ret;

}
