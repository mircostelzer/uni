#include <iostream>
#include <fstream>

using namespace std;

int Percentuale(int superato, int misurazioni);

int main(int argc, char * argv[]) {

    if(argc != 3) {
        cerr << "Usage: " << argv[0] << " <temperature1> <temperature2>" << endl;
        exit(1);
    }

    fstream t1, t2;
    t1.open(argv[1], ios::in);
    t2.open(argv[2], ios::in);

    if(t1.fail() || t2.fail()){
        cerr << "ERROR: cannot open files" << endl;
        exit(1);
    }

    char motore1[32];
    char motore2[32];
    int n_misurazioni = 0;
    int n_superiore_di = 0;
    while(t1 >> motore1 && t2 >> motore2){
        // MR: atoi e' definito in cstdlib e quindi non consentito
        // MR: non specificato che t1 e t2 fossero interi!
        int m1 = atoi(motore1);
        int m2 = atoi(motore2);
        if(m1 > m2) n_superiore_di++;
        n_misurazioni++;
    }

    if(n_misurazioni == 0) cout << "Il numero delle misurazioni e' uguale a zero, per cui non posso calcolare la percentuale" << endl;
    else{
        cout << "La percentuale di misurazioni in cui la temperatura del motore1 ha superato quella del motore2 e' del ";
        cout << Percentuale(n_superiore_di, n_misurazioni) << "%" << endl;
    }

    t1.close();
    t2.close();

    return 0;
}

int Percentuale(int superato, int misurazioni){
    return (superato * 100) / misurazioni;
}