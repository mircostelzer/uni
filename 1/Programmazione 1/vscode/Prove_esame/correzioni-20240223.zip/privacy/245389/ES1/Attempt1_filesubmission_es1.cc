#include <iostream>
#include <fstream>
using namespace std;
// Inserire qui sotto la soluzione all'esercizio
double percentuale(int c1, int d){
    double res=(c1*100)/d;
    return res;
}
int main(int argc, char*argv[]){
    if(argc!=3){
        cout<<"errore nel numero di argomenti"<<endl;
        exit(1);
    }

    fstream temp1;
    fstream temp2;
    temp1.open(argv[1], ios::in);
    temp2.open(argv[2], ios::in);
    if(temp1.fail()||temp2.fail()){
       cout<<"errore nell'apertura di almeno uno dei file"<<endl;
       exit(1);
    }
int cont1=0;
int dim=0;
int num1=0; // MR: non specificato che la temperatura e' un intero!
int num2=0;
while(temp1>>num1&&temp2>>num2){
    dim++;
    if(num1>num2){
        cont1++;
    }
}
if(dim==0){
    cout<<"Il numero delle misurazioni e' uguale a zero,per cui non posso calcolare la percentuale"<<endl;
}
else{
double perc=percentuale(cont1, dim);
cout<<"La percentuale di misurazioni in cui la temperatura del motore1 ha superato quella del motore2 e' del"<<perc<<"%"<<endl;
}

temp1.close();
temp2.close();
return 0;
}