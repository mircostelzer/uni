#include <iostream>
#include <fstream>

using namespace std;

// MR: il testo richiedeva che la funzione Percentuale deve ricevere due double e ritornare un double!
// MR: Quindi non e' conforme con quanto richiesto nel testo dell'esercizio!
void percentuale(char buffer1[], char buffer2[], int &misurazioni1, int &cont, int &output) {
    //cout << "controllo " << buffer1 << ">" << buffer2  << " al cont: " << cont << endl;

    int ris = output;
    int temp1 = 0;
    int temp2 = 0;

    // MR: non era specificato che fossero interi!!
    // converto elementi buffer in interi
    for (int i = 0; buffer1[i] != '\0'; i++) {
        temp1 = temp1 * 10 + (buffer1[i] - '0');
    }

    for (int i = 0; buffer2[i] != '\0'; i++) {
        temp2 = temp2 * 10 + (buffer2[i] - '0');
    }

    if (temp1 > temp2) {
        //cout << "true" << endl;
        misurazioni1++;
        ris = output;
    }

    output = (misurazioni1 * 100) / cont; 
    cont++;

    //cout << "output: " << output << endl;
}

int main(int argc, char * argv [])
{

  // Controllo se il numero degli argomenti è corretto
  if (argc != 3)
  {
    cout << "Usage: esercizio1 temperatura1.txt temperatura2.txt" << endl;
    exit(1);
  }

  // Creo i miei stream
  fstream inputtemp1, inputtemp2;
  inputtemp1.open(argv[1], ios::in);
  inputtemp2.open(argv[2], ios::in);
  

  // Controllo se riesco ad aprire il file di input
  if (inputtemp1.fail() || inputtemp2.fail())
  {
    cout << "Non sono riuscito ad aprire uno dei file "
         << argv[1]  << " " << argv[2] << endl;
    inputtemp1.close();
    inputtemp2.close();
    exit(1);
  }


  char buffer1[255];
  char buffer2[255];

  int misurazioni=0;
  int cont=1;
  int output = 0;

  while(inputtemp1 >> buffer1 && inputtemp2 >> buffer2)
  {
    percentuale(buffer1, buffer2, misurazioni, cont, output);
    
  }

  if(cont>1) {
    cout << "La percentuale di misurazioni in cui la temperatura del motore1 ha superato quella del motore2 e' del " << output << "%" << endl;
  } else {
    cout << "Il numero delle misurazioni e uguale a zero, per cui non posso calcolare la percentuale" << endl;
  }
  

  // Chiudo gli stream
    inputtemp1.close();
    inputtemp2.close();

  return 0;
}