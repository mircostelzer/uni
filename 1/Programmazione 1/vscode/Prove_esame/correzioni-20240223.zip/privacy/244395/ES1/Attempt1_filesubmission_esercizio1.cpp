#include <iostream>
#include <fstream>
using namespace std;

// MR: doveva chiamarsi Percentuale!!!
float percentuale(float occorrenze, float misurazioni){
    return (occorrenze/misurazioni)*100;
}
int main(int argc, char** argv){
    if (argc < 3) {
        cout << "Usage: " << argv[0] << " <filename> <filename>" << endl;
        return 1;
    }
    fstream tmp1(argv[1], fstream::in);
    fstream tmp2(argv[2], fstream::in);
    if(!tmp1.is_open()){
        cout << "file non trovato" << endl;
        return 0;
    }
    if(!tmp2.is_open()){
        cout << "file non trovato" << endl;
        return 0;
    }
    char tmp1row[10];
    char tmp2row[10];
    int result1 = 0;
    int result2 = 0;
    float contarighe = 0;
    float counter=0;
    while(!tmp1.eof() && !tmp1.fail()){
        tmp1.getline(tmp1row, sizeof(tmp1row)); // MR: getline fa parte di string e non consentito
        tmp2.getline(tmp2row, sizeof(tmp2row));
        result1 = atoi(tmp1row); // mr: atoi e' definito in cstdlib e quindi non consentito
        result2 = atoi(tmp2row);
            if(result1 > result2){
                counter++;
            }
            contarighe++;
    }
    if(contarighe > 0){
        cout<<"la percentuale di volte che la temperatura1 ha superato la temperatura2 è:" << percentuale(counter, contarighe) <<"%";
    }
    else{
        cout<<"Il numero delle misurazioni e' uguale a zero, per cui non posso calcolare la percentuale";
    }
    tmp1.close();
    tmp2.close();
    
    return 0;
}