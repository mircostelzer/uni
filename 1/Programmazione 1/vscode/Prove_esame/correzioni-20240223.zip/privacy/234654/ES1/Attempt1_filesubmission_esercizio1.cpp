#include <iostream>
#include <fstream>
using namespace std;

// MR: doveva ritornare un flota e non un void! e NON doveva fare stampa interna!
// MR: doveva chiamarsi Percentuale e non percentuale!
void percentuale(int maggiore, int total){

    float perc;

    perc = ((float)maggiore / (float)total) * 100;

    cout << "La percentuale di misurazioni in cui la temperatura del motore1 \nha superato quella del motore2 e' del " << perc << "%." << endl;
}

int main(int argc, char* argv[]){

    if(argc != 3){

        cerr << "Error. Usage: ./esercizio1.out temperatura1.txt temperatura2.txt" << endl;
        exit(1);
    }


    fstream input1, input2;

    input1.open(argv[1], ios::in);

    if(input1.fail()){

        cerr << "Error with the first input file" << endl;
        input1.close();
        exit(1);
    }

    input2.open(argv[2], ios::in);

    if(input2.fail()){

        cerr << "Error with the second input file" << endl;
        input2.close();
        exit(1);
    }

    char a1[255 + 1];
    char a2[255 + 1];

    int maggiore = 0;
    int total = 0;

    while(input1 >> a1 && input2 >> a2){

        float n1 = atof(a1); // MR: atof definita in cstdlib e non consentita!
        float n2 = atof(a2);

        if(n2 > n1){

            maggiore++;
        }

        total++;
    }

    if(total >= 1) percentuale(maggiore, total);
    else cout << "Il numero delle misurazioni e' uguale a zero, \nper cui non posso calcolare la percentuale" << endl;
    

    input1.close();
    input2.close();

    return 0;

}