#include<iostream>
#include<fstream>
using namespace std;

float Percentuale(float volte,float dim);

int main(int argc, char * argv []) {

  // Controllo che gli argomenti ci siano tutti
  if (argc != 3) {
    cout << "Using temperatura1.txt temperatura2.txt" << endl;
    exit(1);
  }

  // Apro gli stream di lettura e scrittura
  fstream input1, input2;
  input1.open(argv[1], ios::in);
  input2.open(argv[2], ios::in);

  // Controllo che gli stream siano stati aperti correttamente
  if (input1.fail() || input2.fail()) {
    cout << "Errore nell'apertura degli stream!" << endl;
    exit(1);
  }
  int dim =0;
  int volte =0;
  float val1,val2;

  while (!input1.eof()||!input2.eof()) // MR: eof detectato solo dopo lettura, quindi legge una linea in piu' e falsa il risultato
  {
    input1>>val1;
    input2>>val2;
    if(val2>val1)
    {
      volte+=1;
    }
    dim+=1;
  }
  if(dim==1)
  {
    cout<<"Il numero delle misurazioni e' uguale a zero, per cui non posso calcolare la percentuale"<<endl;
  }
  else
  {
    int perc = Percentuale(volte,dim);
    cout<<"La percentuale di misurazioni in cui la temperatura del motore2 ha superato quella del motore1 e' del "<< perc<<"%"<<endl;
  }


  input1.close();
  input2.close();

  return 0;
}


float Percentuale(float volte,float dim)
{
  return volte/dim*100;
}
