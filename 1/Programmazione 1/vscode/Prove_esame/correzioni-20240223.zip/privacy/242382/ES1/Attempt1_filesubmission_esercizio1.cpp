#include <iostream>
#include <fstream>
using namespace std;

// Inserire qui sotto la soluzione all'esercizio
// MR: Percentuale deve ritornare un float/double non un int!
int Percentuale(int cont, int tot);
int main(int argc, char* argv[]){

    fstream input1, input2;
    //controlli
    if(argc != 3){
        cout<<"usage: ./a.out input1 input2"<<endl;
        return 1;
    }
    input1.open(argv[1], ios::in);
    input2.open(argv[2], ios::in);
    if(input1.fail()){
        cout<<"errore nell'apertura del file 1"<<endl;
        return 1;
    }
    if(input2.fail()){
        cout<<"errore nell'apertura del file 2"<<endl;
        return 1;
    }
    int temp1=0, temp2=0, cont=0, tot=0, res; // MR: non specificato che fossero interi!
    //lettura file
    while(input1>>temp1){
        input2>>temp2; // MR: cosa succede se primo file ha piu' elementi del secondo?? Manca controllo!
        if(temp2>temp1){
            cont++;
        }
        tot++;
    }
    //elaborazione risultato
    if(tot == 0){
        // MR: non sta stampando quanto richiesto!
        cout<<"il numero delle misurazioni e' uguale a zero"<<endl;
        return 1;
    }
    res=Percentuale(cont, tot);
    cout<<"La percentuale di misurazioni in cui la temperatura del motore2 ha superato quella del motore 1 e' "<< res<< "%"<< endl;

    input1.close();
    input2.close();
    return 0;
}
int Percentuale(int cont, int tot){
    int res;
    // MR: ritorna 0 se 100 * cont < tot, essendo divisione tra interi invece che tra float/double
    res = (100 * cont) / tot;
    return res;
}


