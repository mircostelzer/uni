#include <iostream>
#include <fstream>
using namespace std;


double Percentuale(double sup, double n);

int main(int argc, char *argv[])
{
    if (argc != 3)
    {
        cout << "Errore: Numero errato di argomenti. <./a.out> <input_file> <output_file> \n";
        cout<<"Il numero delle misurazioni e' uguale a zero, per cui non posso calcolare la percentuale\n";
        exit(1);
    }
    fstream inFile1, inFile2;
    inFile1.open(argv[1], ios::in);
    inFile2.open(argv[2], ios::in);
    if (inFile1.fail())
    {
        cout << "Errore: Apertura del file " << argv[1] << " \n";
        exit(1);
    }
    if (inFile2.fail())
    {
        cout << "Errore: Apertura del file " << argv[2] << " \n";
        exit(1);
    }
    // lettura stringhe, suppongo che il motore raggiunga al massimo 999 C
    // MR: Assunzione NON concessa, era specificato?
    char buffer1[3]; // MR: dove specificato che ci fossero al massimo due cifre per temperatura?
    char buffer2[3];
    double n = 0.0;
    double sup = 0.0;
    while (inFile1 >> buffer1 && inFile2 >> buffer2) // MR: cosa succede se ci sono piu' di due cifre, eccede dimensioni degli array!
    {
        int t1 = atoi(buffer1); // MR: definita in cstdlib! Non consentita!
        int t2 = atoi(buffer2);
        if(t2 > t1){
            sup++;
        }
        n++;
    }
    if(n == 0){
        cout<<"Il numero delle misurazioni e' uguale a zero, per cui non posso calcolare la percentuale\n";
    }else{
        double per = Percentuale(sup,n);
        cout<<"La percentuale di misurazioni in cui la temperatura del motore1 ha superato quella del motore2 e' del "<< per<<" %"<<endl;
    }
    inFile1.close();
    inFile2.close();
    return 0;
}


double Percentuale(double sup, double n){
    double res;
    res = sup/n;
    res = res * 100;
    return res;
}
