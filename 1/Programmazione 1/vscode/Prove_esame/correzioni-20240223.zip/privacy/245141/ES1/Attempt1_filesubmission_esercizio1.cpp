using namespace std;
#include <iostream>
#include <fstream>

// MR: doveva ritornare un double/float non un int!
int Percentuale(int, int);

// Inserire qui sotto la soluzione all'esercizio
int main(int argc, char *argv[]){
    if(argc == 3){
        int n, t; // MR: manca inizializzazione di n, quindi numeri casuali!
        float a, b;
        fstream tem1(argv[1], fstream::in);
        fstream tem2(argv[2], fstream::in);
        // MR: manca controllo apertura dei files

        for(int i=0; !tem1.eof() && !tem2.eof(); i++){ // MR: legge una linea di troppo che altera i risultati preche' eof solo dopo lettura!
            tem1 >> a;
            tem2 >> b;
            if(b > a)
                n++;
            t=i;
        }
        // MR: manca controllo che t != 0
        int p = Percentuale(n, t);
        if(p != 0)
            cout << "La percentuale di misurazioni in cui la temperatura del motore2 ha superato quella del motore1 e' del " << p << "%" << endl;
        else
            cout << "Il numero delle misurazioni e' uguale a zero, per cui non posso calcolare la percentuale" << endl;
    }
}

int Percentuale(int n, int t){
    return n*100/t;
}