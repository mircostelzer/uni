#include <iostream>
#include <cstdlib>
#include <fstream>

using namespace std;

float Percentuale(int h, int c);

int main(int argc, char const *argv[]) {

   // Controllo che gli argomenti ci siano tutti
  if (argc != 3) {
    cout << "Usage: exercise1.out <input> <output>" << endl;
    exit(1);
  }

  // Apro gli stream di lettura e scrittura
  fstream input, input2;
  input.open(argv[1], ios::in);
  input2.open(argv[2], ios::in);

  // Controllo che gli stream siano stati aperti correttamente
  if (input.fail() || input2.fail()) {
    cout << "Errore nell'apertura degli stream!" << endl;
  }


    char t1[100];
    char t2[100];

    int tp1, tp2;
    int counter=0;
    int high=0;

    while ( input >> t1) {
            input2 >> t2; // MR: cosa succede se il primo file contiene piu' elementi del primo?? Manca controllo!

        tp1=std::stoi(t1); // MR: definito in string e non consentito
        tp2=std::stoi(t2);

        counter++;
        if(tp2>tp1){high++;}

       
    }

        if(counter>0){
           cout <<" La percentuale di misurazioni in cui la temperatura del motore2 ha superato quella del motore2 e' del " <<Percentuale(high, counter)*100<<"%" << endl;
        }
        else{ cout << "Il numero delle misurazioni e' uguale a zero,  per cui non posso calcolare la percentuale" << endl;}
    input.close();
    input2.close();

   
    return 0;
}

float Percentuale(int h, int c){

    return (float)h/c;

}
