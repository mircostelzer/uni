#include <iostream>
#include <fstream>

// Inserire qui sotto la soluzione all'esercizio

using namespace std;

// MR: doveva ritornare un double/float non un int!
int Percentuale(int m2_magg_m1, int n_mis){
    return m2_magg_m1*100/n_mis;
}

int main(int argc, char **argv){
    if(argc!=3){
        cout << "Usage: ./esercizio1 <input1> <input2>" << endl;
        exit(1);
    }
    fstream motore1, motore2;
    motore1.open(argv[1], ios::in);
    motore2.open(argv[2], ios::in);
    if(motore1.fail() || motore2.fail()){
        cout << "Errore nell'apertura dei file" << endl;
        exit(1);
    }
    int temp1, temp2, n_mis=0, m2_magg_m1=0; // MR: non specificato che fossero interi
    for(; motore1 >> temp1 && motore2 >> temp2; n_mis++){
        if(temp2>temp1){
            m2_magg_m1++;
        }
    }
    if(n_mis>0){
        cout << "La percentuale di misurazioni in cui la temperatura del motore2 ha superato quella del motore1 è del " << Percentuale(m2_magg_m1, n_mis) << "%" << endl;
    } else {
        cout << "Il numero delle misurazioni è uguale a zero, per cui non posso calcolare la percentuale" << endl;
    }
    motore1.close();
    motore2.close();

    return 0;
}