#include <iostream>
#include <fstream>

using namespace std;

// MR: doveva ritornare un float o un double!
int Percentuale(int, int);

int main(int argc, char* argv[]){
    // Controlla parametri
    if(argc != 3){
        cerr<<"Usage: "<<argv[0]<<" <file1> <file2>";
        exit(0);
    }

    // Dichiarazioni e inizializzazioni iniziali
    fstream input1, input2;

    const char* input_file_1 = argv[1];
    const char* input_file_2 = argv[2];

    input1.open(input_file_1, ios::in);
    if (input1.fail()) {
        cerr<<"Unable to read '"<<input_file_1<<"'";
        exit(0);
    }

    input2.open(input_file_2, ios::in);
    if (input1.fail()) {
        cerr<<"Unable to read '"<<input_file_2<<"'";
        exit(0);
    }

    // Scorre contemporaneamente i due file e incrementa lines ed exceed come necessario
    float t1, t2;
    int exceed=0;
    int lines=0;

    for (;input1 >> t1 && input2 >> t2; lines++){
        if(t2<t1){ // MR: controllo invertito! E' di variante 1!
            exceed++;
        }
    }

    // Stampa risultato finale
    if(lines > 0)
        cout << "La percentuale di misurazioni in cui la temperatura del motore1\nha superato quella del motore2 e' del "<<Percentuale(exceed, lines)<<"%.";
    else
        cout << "Il numero delle misurazioni e' uguale a zero,\nper cui non posso calcolare la percentuale";

    input1.close();
    input2.close();

    return 0;
}

int Percentuale(int excesses, int total){
    return (excesses*100)/total;
}