#include <iostream>
#include <fstream>
using namespace std;
// MR: doveva chiamarsi Percentuale non percentuale!
float percentuale(int count, int totn);
int main(int argc, char * argv []) {

  // Controllo che gli argomenti ci siano tutti
  if (argc != 3) {
    cout << "il numero delle misurazsione è uguale a zero," << endl;
    cout<<"per cui non posso calcolare la percentuale"<<endl;
    exit(1);
  }
  fstream temperatura1,temperatura2;
  temperatura1.open(argv[1],ios::in);
  temperatura2.open(argv[2],ios::in);
  if (temperatura1.fail() || temperatura2.fail()) {
    // MR: questo un caso, ma se apertura fallisce. Se non ci sono elementi cosa succede?
   cout << "il numero delle misurazione è uguale a zero," << endl;
   cout<<"per cui non posso calcolare la percentuale"<<endl;
   exit(1);
  }
  int buffer; // MR: non specificato che sono interi!
  int buffer2;
  int count=0;
  int totn=0;
  while(temperatura1>>buffer && temperatura2>>buffer2){
    if(buffer<buffer2){
        count++;
    }
    totn++;
  }
  float totale;
  totale=percentuale(count,totn);
  // MR: manca controllo che totn != 0!!! Quindi in questo caso va in division by 0!
  // MR: non stampa il messaggio corretto nel caso i file siano vuoti!
  cout<<"la percentuale di misurazioni in cui la temperatura del motore2"<<endl;
  cout<<"ha superato quella del motore1 e' del "<<totale<<" %."<<endl;
  temperatura1.close();
  temperatura2.close();
}
float percentuale(int count, int totn){
    if(totn==0){
    cout << "il numero delle misurazione è uguale a zero," << endl;
    cout<<"per cui non posso calcolare la percentuale"<<endl;
    exit(1);
    }
    float totale=100;
    totale=totale*count;
    totale=totale/totn;
    return totale;
}