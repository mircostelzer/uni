#include <iostream>
#include <fstream>
using namespace std;

// MR: la funzione si doveva chiamare Percentuale!
int calcola (float casi, float totale) {
    return ((casi/totale) * 100);
}

// Inserire qui sotto la soluzione all'esercizio
int main(int argc, char *argv[])
{
    fstream fin1, fin2;
    fin1.open (argv[1], ios::in);
    if (fin1.fail()) {
        cout << "error in opening file 1" << endl;
        return 0;
    }
    fin2.open (argv[2], ios::in);
    if (fin2.fail ()) {
        cout << "error in opening file 2" << endl;
        fin1.close ();
        return 0;
    }


    int totale = 0;
    int caso = 0;
    float n1, n2;
    while (fin1 >> n1) {
        fin2 >> n2; // MR: cosa succede se il secondo file ha meno righe del primo? Va in EOF e non controlla!
        totale ++;
        if (n1 > n2)
            caso ++;
    }
    if (totale > 0) {
        cout << "La percentuale di misurazioni in cui la temperatura del motore1 ha superato quella del motore2 e' del ella del motore2 e' del ";
        cout << calcola (caso, totale) << "%." << endl;
    }
    else
        cout << "Il numero delle misurazioni e' uguale a zero, per cui non posso calcolare la percentuale" << endl;

    fin1.close ();
    fin2.close ();
    return 0;
}
