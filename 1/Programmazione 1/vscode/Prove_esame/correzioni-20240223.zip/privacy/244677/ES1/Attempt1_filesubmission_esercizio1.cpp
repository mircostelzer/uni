#include <iostream>
#include <fstream>
using namespace std;

int Percentuale( double super , int numero  ){

    return super/numero*100; 

}


int main(int argc , char *  argv[]){

    if(argc!=3){
        exit(1);
    }

    fstream motore1 , motore2 ; 

    motore1.open(argv[1],ios::in);
    motore2.open(argv[2],ios::in);

    if(motore1.fail() || motore2.fail()){
        exit(2);
    }
    int superamento = 0 ; 
    double numero1 , numero2 ; 
    int misurazioni = 0 ; 
    while (motore1>>numero1 && motore2>>numero2){

        if(numero1>numero2){
            superamento++;
        }
        misurazioni++;
    }
    
    if(misurazioni==0){
        cout<<"Il numero delle misurazioni e' uguale a zero,\nper cui non posso calcolare la percentuale"<<endl;
    }else{
        int percent = Percentuale(superamento  , misurazioni); 
        cout<<"La percentuale di misurazioni in cui la temperatura del motore1\nha superato quella del motore2 e' del "<<percent<<"%"<<endl;
    }

    motore1.close();
    motore2.close(); 
    return 0 ;  
}