#include <iostream>
#include <cstdlib>

// Non modificare questa parte sotto del codice
typedef struct Stack {
    int data;
    struct Stack * next;
} Stack;

struct Stack * initStack() {
    return nullptr;
}

bool isEmpty(struct Stack * s) {
    return (s == nullptr);
}

void push(struct Stack * &s, int value) {
    struct Stack * newElement = new Stack;
    newElement->data = value;
    newElement->next = s;
    s = newElement;
}

int top(struct Stack * s) {
    if (isEmpty(s)) {
        std::cerr << "Error: stack is empty" << std::endl;
        exit(1);
    }
    return s->data;
}

int pop(struct Stack * &s) {
    if (isEmpty(s)) {
        std::cerr << "Error: stack is empty" << std::endl;
        exit(1);
    }
    int value = s->data;
    struct Stack * temp = s;
    s = s->next;
    delete temp;
    return value;
}

void deleteStack(struct Stack * &s) {
    while (!isEmpty(s)) {
        pop(s);
    }
}

void printStack(struct Stack * s, const char * message = "Stack: ") {
    if (isEmpty(s)) {
        std::cout << "Stack is empty" << std::endl;
    } else {
        std::cout << message;
        struct Stack * temp = s;
        while (temp != nullptr) {
            std::cout << temp->data << " ";
            temp = temp->next;
        }
        std::cout << std::endl;
    }
    
}
// Non modificare questa parte sopra del codice

// Inserire qui sotto la dichiarazione della funzione stackOperator
Stack * stackOperator(Stack * s);
// Inserire qui sopra la dichiarazione della funzione stackOperator

int main() {
    struct Stack *s, *result;
    unsigned int seed = (unsigned int)time(NULL);
    // seed = 60000
    seed = 1697033220;
    srand(seed);

    s = initStack();
    for (int i = 0; i < 5; i++) {
        if (i != 2) push(s, 5-i);
    }
    printStack(s, "Original before: ");
    result = stackOperator(s);
    printStack(result, "Result StackOperator: ");
    printStack(s, "Original after: ");
    deleteStack(s);
    deleteStack(result);

    s = initStack();
    for (int i = 0; i < 10; i++) {
        push(s, rand() % 100);
    }
    printStack(s, "Original before: ");
    result = stackOperator(s);
    
    printStack(result, "Result StackOperator: ");
    printStack(s, "Original after: ");
    deleteStack(s);
    deleteStack(result);

    return 0;
}

// Inserire qui sotto la definizione della funzione stackOperator
Stack * stackOperator(Stack * s){
    // MR: essendo s assato per valore, operando con pop su s si deallocano i nodi, e si distrugge tutto lo stack, e quindi nel main la lista originaria viene distrutta e non e' piu' utilizzabile e fa accesso quindi a memoria spuria non del programma.

    Stack * r = initStack();
    
    
    int sum =0; 
    int numTot =0;
    

    
    while (!isEmpty(s)){
        sum+=top(s);
        numTot++;
        push(r , pop(s));
    }
    

    while (!isEmpty(r)){
        
        push(s , pop(r));
    } 
    
    push(r , sum);          // push dentro la prima sommatotale
    
    int numTemp= numTot;            
    int i = 0 ; 
    int numeroInserito = 0 ; 
    
    while(numeroInserito<numTot){
        // MR: qui entra in loop infinito non completamente chiaro perche'        while (numTemp > 0)
        {
            push(r , pop(s));
            numTemp--;
            i++;
            if(numTemp ==1){
                int risultato = top(s); 
                while (i!=0)
                {
                    push(s , pop(r));
                    i--;
                }
                push(r, risultato);
                push(r , sum-risultato);
                sum -=risultato; 
                
                numeroInserito++ ; 
                numTemp = numTot-numeroInserito ; 
            }
        }
    }
    
    return r ; 

}
// Inserire qui sopra la definizione della funzione stackOperator
