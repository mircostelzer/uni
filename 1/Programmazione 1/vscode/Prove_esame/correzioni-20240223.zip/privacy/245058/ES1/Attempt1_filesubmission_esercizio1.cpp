#include <iostream>
#include <fstream>

using namespace std;

int Percentuale(int misurazioni, int maggiore){
    return (maggiore*100)/misurazioni;
}


int main(int argc, char *argv[]){
    if(argc != 3){
        cout<<"Il numero delle misurazioni e' uguale a 0, per cui non posso calcolare la percentuale";
        exit(0);
    }

    fstream input1, input2;
    input1.open(argv[1], ios::in);
    input2.open(argv[2], ios::in);

    if(input1.fail() || input2.fail()){
        cout<<"Il numero delle misurazioni e' uguale a 0, per cui non posso calcolare la percentuale";
        exit(0);
    }

    int contatore = 0;
    int maggiore = 0;

    char motore1[8];
    char motore2[8];
    int valore1, valore2;

    while(input1>>motore1 && input2>>motore2){
        // MR: atoi definito in cstdlib e quindi non consentito
        valore1 = atoi(motore1);
        valore2 = atoi(motore2);

        if(valore1 > valore2){
            maggiore++;
        }

        contatore++;
    }

    int p = Percentuale(contatore, maggiore);

    if(contatore == 0){
        cout<<"Il numero delle misurazioni e' uguale a 0, per cui non posso calcolare la percentuale";
    }
    else{
        cout<<"La percentuale di misurazioni in cui la temperatura del motore1 ha superato quella del motore2 è il "<<p<<"%.";
    }




    input1.close();
    input2.close();
    return 0;
}
