#include <iostream>
#include <fstream>

using namespace std;

double Percentuale(int conta, int totale) {
    return (double)conta / totale * 100;
}

int main(int argc, char* argv[]) {
    if (argc != 3) {
        cerr << "Usage: " << argv[0] << " <file temperatura 1> <file temperatura 2>\n";
        return 1;
    }

    ifstream file1(argv[1]);
    ifstream file2(argv[2]);

    if (!file1.is_open() || !file2.is_open()) {
        cerr << "Errore nell'apertura dei file\n";
        return 1;
    }

    double temp1, temp2;
    int conta = 0, totale = 0;

    while (file1 >> temp1 && file2 >> temp2) {
        totale++;
        if (temp2 > temp1) {
            conta++;
        }
    }

    file1.close();
    file2.close();

    if (totale == 0) {
        cout << "Il numero delle misurazioni e' uguale a zero, per cui non posso calcolare la percentuale\n";
    } else {
        cout << "La percentuale di misurazioni in cui la temperatura del motore2 ha superato quella del motore1 e' del " << Percentuale(conta, totale) << "%.\n";
    }

    return 0;
}