#include <iostream>
#include <fstream>
using namespace std;

// MR: doveva chiamarsi Percentuale e non percentuale!
double percentuale(double, double);

int main(int argc, char *argv[]){
    if (argc != 4){
        cerr << "Usage: file.out <temp1.txt> <temp2.txt> <output.txt>" << endl;
        exit(1);
    }
    fstream mot1, mot2, output;
    mot1.open(argv[1], ios::in);
    mot2.open(argv[2], ios::in);
    // MR: non so dove ha visto che output doveva essere fatto su file!
    output.open(argv[3], ios::out);
    double count = 0, sup = 0;
    double t1, t2;
    if (output.fail()){
        cerr << "Problema nell'apertura del file di output." << endl;
    }
    else if (mot1.fail() || mot2.fail()){ // MR: questo controllo fatto solo se file di output aperto correttamente!
        output << "Il numero delle misurazioni e' uguale a zero," << endl << "per cui non posso calcolare la percentuale.";
        cerr << "Problema nell'apertura dei file di input." << endl;
        output.close();
    }
    else {
        while (mot1 >> t1 && mot2 >> t2){
            count++;
            if (t2 > t1) sup++;   
        }
        double perc = percentuale(count, sup);
        if (count > 0){
            output << "La percentuale di misurazioni in cui la temperatura del motore2" << endl << "ha superato quella del motore1 e' del " << perc << "%.";
        }
        else{
            output << "Il numero delle misurazioni e' uguale a zero," << endl << "per cui non posso calcolare la percentuale.";
        }
        mot1.close();
        mot2.close();
        output.close();
    }
    return 0;
}

double percentuale(double count, double sup){
    return (sup / count) * 100;
}