#include <iostream>
#include <cstddef>

using namespace std;

// Inserire qui la dichiarazione di get_elements

void get_elements(const char s[], const int ds,
                  char * & dest1, int & d1,
                  char * & dest2, int & d2);

void print(const char a[], const int s, const char * prefix) {
  cout << prefix;
  for (int i = 0; i < s; i++) {
    cout << a[i] << " ";
  }
  cout << endl;
}

void read_elements(char s[], const int ms, int & s_s) {
  char r = '\0';
  for (s_s = 0; ((s_s < ms) && (r != '\n')); ) {
    r = cin.get();
    if ((r != '\n') && (r != ' ')) s[s_s++] = r;
  }
}

int main() {
  const int maxdim = 10;

  char * d1;
  int d1_s = 0;

  char * d2;
  int d2_s = 0;

  const int ms = maxdim;
  char s[ms];
  int s_s = 0;

  read_elements(s, ms, s_s);
  print(s, s_s, "Source = ");

  get_elements(s, s_s, d1, d1_s, d2, d2_s);

  print(d1, d1_s, "D1     = ");
  print(d2, d2_s, "D2     = ");

  delete [] d1;
  delete [] d2;
}

// Inserire qui la definizione di get_elements e di eventuali altre
// funzioni ausiliarie

void get_elements(const char s[], const int size,
                  char * & dest1, int & d1,
                  char * & dest2, int & d2) {
  if (size <= 0) {
    dest1 = new char [d1];
    dest2 = new char [d2];
    d1 = 0; d2 = 0;
  } else {
    if (s[size-1] >= 'a' && s[size-1] <= 'z') {
      d1++;
      get_elements(s, size-1, dest1, d1, dest2, d2);
      dest1[d1] = 'A' - (s[size-1] - 'z');
      d1++;
    } else if (s[size-1] >= '0' && s[size-1] <= '9') {
      d2++;
      get_elements(s, size-1, dest1, d1, dest2, d2);
      dest2[d2] = '9' - (s[size-1] - '0');
      d2++;
    } else {
      get_elements(s, size-1, dest1, d1, dest2, d2);
    }
  }
}
