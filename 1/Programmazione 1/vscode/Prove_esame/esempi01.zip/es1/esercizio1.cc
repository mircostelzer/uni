#include<iostream>
#include<fstream>
#include<cstring>
#include<cmath>
using namespace std;


// E' possibile avere delle funzioni di appoggio per la codifica delle parole in numeri e viceversa.
// Ad esempio:
// int encode(char * decoded);
// void decode(int coded, char * decoded);


int main(int argc, char * argv []) {

  // inserire qui il codice

  return 0;
}
