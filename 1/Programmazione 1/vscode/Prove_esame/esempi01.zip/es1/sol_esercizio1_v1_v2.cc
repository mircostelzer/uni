#include<iostream>
#include<fstream>
#include<cstring>
#include<cmath>
using namespace std;


// E' possibile avere delle funzioni di appoggio per la codifica delle parole in numeri e viceversa.
// Ad esempio:
// int encode(char * decoded);
// void decode(int coded, char * decoded);

int decode(const char *);
void encode(int, char *);

int main(int argc, char * argv []) {
  
  // inserire qui il codice
  if (argc != 3) {
    cout << "Numero errato argomenti" << endl;
    exit(1);
  }

  fstream in, out;
  in.open(argv[1], ios::in);
  if (in.fail()) {
    cout << "Errore apertura file input: " << argv[1] << endl;
    exit(1);
  }
  out.open(argv[2], ios::out);
  if (out.fail()) {
    in.close();
    cout << "Errore apertura file output: " << argv[2] << endl;
    exit(1);
  }
  int key;
  bool cond = false;
  do {
    cond = false;
    cin >> key;
    if (cin.fail()) {
      exit(1);
    }
    if (key > 9999999) {
      cout << "Numero troppo grande\n";
      cond = true;
    }
  } while (cond);

  char buffer[80];

  while (in >> buffer) {
    buffer[4] = '\0';

    int value = decode(buffer);
    value += key;
    encode(value, buffer);
    out << buffer << " ";
  }
  in.close();
  out.close();
  return 0;
}

int decode(const char * buffer) {
  int res = 0;
  int len = strlen(buffer);
  for (int i = 0; i < len; i++)
  {
    int n;
    if (buffer[i] >= '0' && buffer[i] <= '9') {
      n = buffer[i] - '0';
    } else {
      n = buffer[i] - 'a' + 10;
    }
    n = pow(36, len - 1 - i) * n;
    res += n;
  }
  return res;
}

void encode(int num, char * buffer) {
  int i = 0;
  while( num != 0) {
    int m = num % 36;
    num = (num - m) / 36;
    if (m < 10) {
      buffer[i] = '0' + m;
    } else {
      buffer[i] = 'a' + m - 10;
    }
    i++;
    buffer[i] = '\0';
  }
  for (int j = 0; j < i / 2; j++) {
    char t = buffer[j];
    buffer[j] = buffer[i - j - 1];
    buffer[i - j - 1] = t;
  }
}