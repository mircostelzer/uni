extern int size1 = 100;

extern int x;

extern void print_ciao();
