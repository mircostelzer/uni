using namespace std;
#include <iostream>

int size = 100;

int x;
// static int x; // non visibile nemmeno con "extern"

void print_ciao() {
  cout << "Ciao\n";
}


